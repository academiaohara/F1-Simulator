/* Motor de carrera: fisica de potencia/velocidad, grupos, IA de equipos y eventos. */
#include "sim.h"
#include <math.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#define MASS 74.0f
#define BODY 66.0f
#define RHO 1.15f
#define G0 9.81f
#define CDA_ROAD 0.30f
#define CDA_TT 0.23f

static float clampf(float x, float a, float b) { return x < a ? a : (x > b ? b : x); }
static float srnd(Sim *s) { s->rng = s->rng * 1664525u + 1013904223u; return (float)((s->rng >> 8) & 0xFFFFFF) / 16777216.0f; }
static float srange(Sim *s, float a, float b) { return a + (b - a) * srnd(s); }

const char *climb_cat_name(int cat) {
    static const char *n[] = { "HC", "C1", "C2", "C3", "C4" };
    return n[cat < 0 ? 0 : (cat > 4 ? 4 : cat)];
}

/* ---------------------------------------------------------------- fisica */
static float power_for_speed(float v, float grade, float cda, float crr) {
    return v * (MASS * G0 * (grade + crr) + 0.5f * RHO * cda * v * v);
}
static float speed_for_power(float P, float grade, float cda, float crr) {
    if (P < 1.0f) P = 1.0f;
    float lo = 0.0f, hi = 30.0f;
    for (int i = 0; i < 14; i++) {
        float mid = 0.5f * (lo + hi);
        if (power_for_speed(mid, grade, cda, crr) < P) lo = mid; else hi = mid;
    }
    return 0.5f * (lo + hi);
}

float sim_alt_at(const Sim *s, float x) {
    float k = x / 500.0f;
    if (k < 0) k = 0;
    int i = (int)k; if (i >= s->n_alt - 1) return (float)s->alt[s->n_alt - 1];
    float f = k - i;
    return s->alt[i] * (1 - f) + s->alt[i + 1] * f;
}
float sim_grade_at(const Sim *s, float x) {
    float k = x / 500.0f;
    int i = (int)k; if (i < 0) i = 0; if (i >= s->n_alt - 1) i = s->n_alt - 2;
    float f = k - i; if (f < 0) f = 0; if (f > 1) f = 1;
    float g0 = s->gr[i], g1 = s->gr[i + 1 < s->n_alt ? i + 1 : i];
    return g0 * (1 - f) + g1 * f;
}
static int surf_at(const Sim *s, float x) { int i = (int)(x / 500.0f); if (i < 0) i = 0; if (i >= s->n_alt) i = s->n_alt - 1; return s->surf[i]; }

void stage_climbs(const StageDef *st, Climb *out, int *nout) {
    const short *alt = PT_ALT + st->pt0;
    int n = st->npt, cnt = 0;
    int i = 0;
    while (i < n - 2 && cnt < MAX_CLIMBS) {
        /* buscar inicio: minimo local */
        int start = i, peak = i;
        int cur = i;
        float best = alt[i];
        while (cur < n - 1) {
            cur++;
            if (alt[cur] > best) { best = (float)alt[cur]; peak = cur; }
            if (best - alt[cur] > 22) break;
            if (alt[cur] < alt[start] && peak == start) start = cur;
        }
        float asc = (float)(alt[peak] - alt[start]);
        float len = (peak - start) * 500.0f;
        if (len >= 1500 && asc >= 60 && asc / len >= 0.028f) {
            float grade = asc / len * 100.0f;
            float score = len * grade;
            int cat = -1;
            if (score >= 80000) cat = 0; else if (score >= 64000) cat = 1; else if (score >= 32000) cat = 2;
            else if (score >= 16000) cat = 3; else if (score >= 10000) cat = 4;
            if (cat >= 0) {
                /* ajustar al maximo de pendiente: empezar donde empieza la subida sostenida */
                Climb *c = &out[cnt++];
                c->km0 = start * 0.5f; c->km1 = peak * 0.5f; c->len = len; c->grade = grade;
                c->top_alt = (float)alt[peak]; c->cat = (unsigned char)cat; c->taken = 0;
            }
        }
        if (peak > start) i = peak; else i = start + 1;
        if (i <= start) i = start + 1;
    }
    *nout = cnt;
}

int sim_climb_at(const Sim *s, float pos) {
    for (int i = 0; i < s->nclimbs; i++) if (pos >= s->climbs[i].km0 * 1000 && pos <= s->climbs[i].km1 * 1000) return i;
    return -1;
}

/* ---------------------------------------------------------------- eventos */
void sim_event(Sim *s, int kind, const char *fmt, ...) {
    if (!s->interactive) return;
    if (s->nev >= EV_MAX) { memmove(s->ev, s->ev + 1, sizeof(Event) * (EV_MAX - 1)); s->nev = EV_MAX - 1; }
    Event *e = &s->ev[s->nev++];
    e->t_sec = (int)s->t; e->kind = (unsigned char)kind;
    va_list ap; va_start(ap, fmt); vsnprintf(e->text, sizeof e->text, fmt, ap); va_end(ap);
}

/* ---------------------------------------------------------------- capacidad del corredor */
static float skill_for(const SimRider *r, float grade, int surf, int tt) {
    const unsigned char *a = r->a;
    float s;
    if (tt) {
        s = (float)a[A_CRI];
        if (grade > 0.045f) { float w = clampf((grade - 0.045f) / 0.05f, 0, 0.6f); s = s * (1 - w) + a[A_MONTANA] * w; }
        return s;
    }
    if (grade >= 0.065f) s = 0.60f * a[A_MONTANA] + 0.22f * a[A_MEDIA] + 0.18f * a[A_COLINAS];
    else if (grade >= 0.04f) s = 0.38f * a[A_MONTANA] + 0.38f * a[A_MEDIA] + 0.24f * a[A_COLINAS];
    else if (grade >= 0.018f) s = 0.50f * a[A_MEDIA] + 0.28f * a[A_LLANO] + 0.22f * a[A_COLINAS];
    else s = (float)a[A_LLANO];
    if (surf == 1) s = 0.45f * s + 0.55f * a[A_PAVES];
    else if (surf == 2) s = 0.6f * s + 0.4f * a[A_PAVES];
    return s;
}
static float cap_w(const SimRider *r, float grade, int surf, int tt) {
    float s = skill_for(r, grade, surf, tt);
    float wkg = 5.4f + (s - 70.0f) * 0.0667f;
    float ef = r->energy >= 30 ? 1.0f : 0.52f + 0.48f * sqrtf(r->energy / 30.0f);
    float w = wkg * BODY * r->perf * ef;
    if (tt) w *= 1.04f;
    return w;
}

/* ---------------------------------------------------------------- configuracion */
static int cmp_pos_desc(const void *a, const void *b);
static Sim *g_sort_sim;
static int cmp_pos_desc(const void *a, const void *b) {
    float pa = g_sort_sim->r[*(const int *)a].pos, pb = g_sort_sim->r[*(const int *)b].pos;
    return pa < pb ? 1 : (pa > pb ? -1 : 0);
}

static int cmp_team_pos(const void *a, const void *b) {
    const SimRider *x = &g_sort_sim->r[*(const int *)a], *y = &g_sort_sim->r[*(const int *)b];
    if (x->tslot != y->tslot) return x->tslot < y->tslot ? -1 : 1;
    return x->pos < y->pos ? 1 : (x->pos > y->pos ? -1 : 0);
}

static void build_groups(Sim *s) {
    int k = 0;
    for (int i = 0; i < s->n; i++) if (s->r[i].status == 0) s->order[k++] = i;
    s->nact = k;
    g_sort_sim = s;
    qsort(s->order, k, sizeof(int), s->ttt ? cmp_team_pos : cmp_pos_desc);
    s->ngroups = 0;
    int i = 0;
    while (i < k) {
        Group *g = &s->grp[s->ngroups];
        memset(g, 0, sizeof *g);
        g->first = i;
        int j = i;
        float lim = (s->ttt) ? 0 : 60.0f;
        while (j + 1 < k) {
            SimRider *a = &s->r[s->order[j]], *b = &s->r[s->order[j + 1]];
            if (s->tt) { if (!s->ttt) break; if (a->tslot != b->tslot) break; }
            else if (a->pos - b->pos > lim) break;
            j++;
        }
        g->n = j - i + 1;
        g->front = s->r[s->order[i]].pos; g->back = s->r[s->order[j]].pos;
        float vs = 0;
        for (int q = i; q <= j; q++) {
            SimRider *r = &s->r[s->order[q]];
            r->group = (short)s->ngroups; vs += r->v;
            if (r->human) g->mine++;
            if (r->is_break) g->has_break_riders++;
        }
        g->v = vs / g->n;
        s->ngroups++;
        i = j + 1;
    }
    float lead = s->ngroups ? s->grp[0].front : 0;
    s->leader_pos = lead;
    int best = 0, bn = 0;
    for (int gi = 0; gi < s->ngroups; gi++) {
        Group *g = &s->grp[gi];
        float v = g->v > 3 ? g->v : 10.0f;
        g->gap = (gi == 0) ? 0 : (lead - g->front) / v;
        if (g->n > bn) { bn = g->n; best = gi; }
    }
    s->main_group = best;
}

int sim_rider_group(const Sim *s, int si) { return s->r[si].group; }
float sim_gap_to_leader(const Sim *s, int si) {
    const SimRider *r = &s->r[si];
    if (r->status != 0 || r->group < 0 || r->group >= s->ngroups) return 0;
    return s->grp[r->group].gap;
}
int sim_leader_idx(const Sim *s) { return s->nact ? s->order[0] : -1; }

const char *sim_status_name(const SimRider *r) {
    if (r->status == 1) return "ABANDONA";
    if (r->status == 3) return "FUERA";
    if (r->status == 2) return "META";
    if (r->stun > 0) return r->bonk == 2 ? "CAÍDA" : "INCID.";
    if (r->feed_t > 0) return "BIDONES";
    if (r->energy < 12) return "PÁJARA";
    switch (r->order) {
        case ORD_ATACAR: return "ATACA";
        case ORD_ESCAPADA: return "ESCAPADA";
        case ORD_TIRAR: return "TIRA";
        case ORD_PROTEGER: return "PROTEGE";
        case ORD_RECUPERAR: return "AHORRA";
        case ORD_AVITUALLAR: return "BIDONES";
    }
    if (r->is_break) return "ESCAPADO";
    if (r->chase) return "PERSIGUE";
    if (r->ai_pull) return "TIRA";
    return "EN GRUPO";
}

void sim_set_order(Sim *s, int si, int order, int intens) {
    SimRider *r = &s->r[si];
    if (r->status != 0) return;
    r->order = (unsigned char)order; r->intens = (unsigned char)intens;
    if (order == ORD_ATACAR) { r->atk_t = 0; }
    if (order == ORD_AVITUALLAR) { r->feed_t = 22.0f; }
    if (order == ORD_ESCAPADA) { r->brk_t = 240; }
    if (order == ORD_ATACAR && s->interactive) sim_event(s, 3, "¡Ataque de %s!", rider_name(r->rider));
}
void sim_set_strat(Sim *s, int strat) { if (s->human_team_slot >= 0) s->tstrat[s->human_team_slot] = (unsigned char)strat; }
void sim_launch_sprint(Sim *s) {
    s->human_sprint = 1;
    s->human_sprint_at = s->L - s->leader_pos;
}

/* quien manda en cada equipo */
static void team_picks(Sim *s) {
    for (int t = 0; t < s->nteams; t++) {
        int bl = -1, bs = -1; int bsl = -1, bss = -1;
        for (int i = 0; i < s->n; i++) {
            SimRider *r = &s->r[i];
            if (r->tslot != t || r->status != 0) continue;
            if (r->role == ROLE_LIDER && bl < 0) bl = i;
            if (r->role == ROLE_ESPRINTER && bs < 0) bs = i;
        }
        if (bl < 0 || bs < 0) {
            for (int i = 0; i < s->n; i++) {
                SimRider *r = &s->r[i];
                if (r->tslot != t || r->status != 0) continue;
                int gs = r->a[A_MONTANA] + r->a[A_FONDO] + r->a[A_CRI];
                int ss = r->a[A_ESPRINT] * 2 + r->a[A_ACEL];
                if (gs > bsl && bl < 0) { bsl = gs; }
                if (ss > bss && bs < 0) { bss = ss; }
            }
        }
        s->tleader[t] = (short)bl; s->tsprinter[t] = (short)bs;
    }
}

void sim_setup(Sim *s, int stage_idx, RaceRun *run, int interactive) {
    memset(s, 0, sizeof *s);
    s->stage_idx = stage_idx;
    s->st = &STAGES[stage_idx];
    s->race = &RACES[s->st->race];
    s->tier = s->race->tier;
    s->L = s->st->dist_km * 1000.0f;
    s->tt = (s->st->kind == K_CRI || s->st->kind == K_CRE);
    s->ttt = (s->st->kind == K_CRE);
    s->interactive = interactive;
    s->rng = (unsigned)(stage_idx * 2654435761u + (unsigned)G.year * 977u + (unsigned)G.day * 31u + 12345u);
    s->alt = PT_ALT + s->st->pt0; s->n_alt = s->st->npt;
    s->dt = 3.0f;
    s->human_team_slot = -1;
    for (int i = 0; i < s->n_alt; i++) {
        int a = i > 0 ? i - 1 : 0, b = i < s->n_alt - 1 ? i + 1 : i;
        float g = (b > a) ? (s->alt[b] - s->alt[a]) / ((b - a) * 500.0f) : 0;
        s->gr[i] = clampf(g, -0.20f, 0.22f);
        s->surf[i] = 0;
    }
    for (int k = 0; k < s->st->nsurf; k++) {
        const SurfDef *sd = &SURFS[s->st->surf0 + k];
        for (int i = sd->km0_10 / 5; i <= sd->km1_10 / 5 && i < s->n_alt; i++) s->surf[i] = sd->type;
    }
    stage_climbs(s->st, s->climbs, &s->nclimbs);
    /* sprint intermedio y avituallamiento */
    s->feed_km = s->L * 0.58f / 1000.0f;
    s->isprint_km = s->L * 0.48f / 1000.0f;
    for (int i = 0; i < s->nclimbs; i++) if (fabsf(s->isprint_km - s->climbs[i].km1) < 6 || (s->isprint_km > s->climbs[i].km0 && s->isprint_km < s->climbs[i].km1)) s->isprint_km = s->climbs[i].km0 - 3;
    if (s->isprint_km < 8) s->isprint_km = 8;
    if (s->tt || s->L < 80000) s->isprint_done = 1;
    if (s->tt) s->feed_done = 1;
    /* meteorologia */
    float w = srnd(s);
    s->rain = w < 0.12f ? 1.0f : 0.0f;
    s->heat = (w >= 0.12f && w < 0.22f) ? 1.0f : 0.0f;
    s->wind = (w >= 0.22f && w < 0.30f) ? 1.0f : 0.0f;
    if (G.day < 80 || G.day > 330) s->heat = 0;
    if (s->st->kind == K_CRE || s->st->kind == K_CRI) s->wind = 0;

    s->nteams = run->nteams;
    for (int t = 0; t < run->nteams; t++) s->tteam[t] = run->team[t];
    s->n = 0;
    float leader_gc = 1e9f;
    for (int i = 0; i < run->nr; i++) if (!run->r[i].abandoned && run->r[i].gc < leader_gc) leader_gc = run->r[i].gc;
    if (leader_gc > 1e8f) leader_gc = 0;
    for (int i = 0; i < run->nr && s->n < SIM_MAX; i++) {
        RunRider *rr = &run->r[i];
        if (rr->abandoned) continue;
        Rider *rd = &G.riders[rr->rider];
        if (rd->inj_days > 0 && !rr->human) continue;
        SimRider *r = &s->r[s->n];
        memset(r, 0, sizeof *r);
        r->run_idx = (short)i; r->rider = rr->rider; r->team = rd->team; r->tslot = rr->tslot;
        r->role = rr->role; r->human = rr->human; r->order = rr->order; r->intens = rr->intens;
        memcpy(r->a, rd->a, A_COUNT);
        float cond = clampf(rd->form - rd->fatigue * 0.55f, 0, 100);
        r->perf = 0.915f + 0.125f * (cond / 100.0f);
        if (interactive) r->perf *= 1.0f;
        r->energy = clampf(100.0f - rd->fatigue * 0.22f, 55, 100);
        r->wpmax = 11.0f + r->a[A_ACEL] * 0.13f + r->a[A_ESPRINT] * 0.05f;
        r->wp = 100.0f;
        r->gc_pre = rr->gc - leader_gc;
        r->pos = -srange(s, 0, 28);
        r->place = 0; r->group = -1; r->target = -1;
        if (rr->human && s->human_team_slot < 0) s->human_team_slot = rr->tslot;
        s->n++;
    }
    for (int t = 0; t < run->nteams; t++) s->tstrat[t] = run->strat[t];
    team_picks(s);
    /* inicio contrarreloj */
    if (s->tt) {
        int ord[SIM_MAX]; for (int i = 0; i < s->n; i++) ord[i] = i;
        /* de peor a mejor clasificado general: salen los ultimos primero */
        for (int i = 0; i < s->n; i++) for (int j = i + 1; j < s->n; j++) {
            if (s->r[ord[j]].gc_pre > s->r[ord[i]].gc_pre) { int tmp = ord[i]; ord[i] = ord[j]; ord[j] = tmp; }
        }
        if (s->ttt) {
            for (int i = 0; i < s->n; i++) s->r[i].start_off = s->r[i].tslot * 150.0f;
            int rank = 0;
            /* equipos mejor clasificados salen ultimos */
            (void)rank;
            for (int i = 0; i < s->n; i++) s->r[i].pos = -srange(s, 0, 6);
        } else {
            for (int k = 0; k < s->n; k++) { s->r[ord[k]].start_off = k * 90.0f; s->r[ord[k]].pos = 0; }
        }
    }
    /* intentos de escapada */
    if (!s->tt) {
        int natt = (s->st->kind == K_MONTANA) ? 5 : (s->st->kind == K_LLANA ? 4 : 5);
        float km = 2.0f;
        for (int i = 0; i < natt && i < 6; i++) { km += srange(s, 4, 16); s->attempt_km[i] = km * 1000.0f; }
        s->nattempt = natt;
        if (s->L < 60000) { for (int i = 0; i < natt; i++) s->attempt_km[i] = s->L * (0.05f + 0.1f * i); }
    }
    s->think_t = 9.0f;
    s->break_group_gap = 0;
    s->stage_winner = -1;
    sim_event(s, 0, "¡Se da la salida en %s!", s->st->from);
}

/* ---------------------------------------------------------------- IA del pelotón */

static int is_sprint_stage(const Sim *s) { return s->st->kind == K_LLANA || (s->st->kind == K_CLASICA && s->st->dplus < 1900); }

static void ai_break_attempt(Sim *s) {
    /* elegir candidatos del grupo principal */
    Group *g = &s->grp[s->main_group];
    int cand[SIM_MAX]; float w[SIM_MAX]; int nc = 0; float tot = 0;
    for (int q = g->first; q < g->first + g->n; q++) {
        int i = s->order[q]; SimRider *r = &s->r[i];
        if (r->human && r->order != ORD_ESCAPADA) continue;
        if (r->is_break || r->stun > 0) continue;
        if (r->role == ROLE_LIDER || r->role == ROLE_ESPRINTER) continue;
        if (s->tstrat[r->tslot] == STR_CONSERVAR) continue;
        float sc = r->a[A_ESCAPADA] * 0.5f + r->a[A_FONDO] * 0.2f + r->a[A_LLANO] * 0.15f + r->a[A_ACEL] * 0.15f - 30.0f;
        if (sc < 5) sc = 5;
        float mult = 1.0f;
        if (r->role == ROLE_ESCAPADISTA) mult = 4.0f;
        else if (r->role == ROLE_RODADOR) mult = 1.2f;
        else if (r->role == ROLE_LANZADOR) mult = 0.3f;
        if (s->tstrat[r->tslot] == STR_ESCAPADA) mult *= 2.0f;
        if (s->tstrat[r->tslot] == STR_CONTROL || s->tstrat[r->tslot] == STR_GENERAL) mult *= 0.4f;
        cand[nc] = i; w[nc] = sc * mult; tot += w[nc]; nc++;
    }
    if (nc < 3) return;
    int k = 2 + (int)(srnd(s) * 5.5f);
    if (k > nc) k = nc;
    int picked = 0;
    int names[3]; int nn = 0;
    int bid = (s->brk_counter++ % 7) + 1;
    float first_w = 0;
    for (int tries = 0; tries < 40 && picked < k; tries++) {
        float x = srnd(s) * tot, acc = 0; int sel = -1;
        for (int c = 0; c < nc; c++) { acc += w[c]; if (acc >= x && w[c] > 0) { sel = c; break; } }
        if (sel < 0) continue;
        SimRider *r = &s->r[cand[sel]];
        if (r->is_break) continue;
        r->is_break = 1; r->brk_t = srange(s, 150, 260); r->ai_r = 1.10f; r->brk_id = (unsigned char)bid;
        tot -= w[sel]; w[sel] = 0;
        if (nn < 3) names[nn++] = cand[sel];
        (void)first_w;
        picked++;
    }
    if (picked >= 2) {
        char nm[128] = "";
        for (int i = 0; i < nn; i++) { strncat(nm, rider_name(s->r[names[i]].rider), 30); if (i < nn - 1) strcat(nm, ", "); }
        sim_event(s, 1, "Ataque de %d corredores: %s...", picked, nm);
    } else {
        for (int c = 0; c < nc; c++) s->r[cand[c]].is_break = s->r[cand[c]].is_break;
    }
}

static void ai_think(Sim *s) {
    if (s->nact == 0) return;
    float rem_leader = s->L - s->leader_pos;
    Group *mg = &s->grp[s->main_group];
    /* reiniciar flags de tirones */
    for (int i = 0; i < s->n; i++) { SimRider *r = &s->r[i]; if (r->status == 0) { r->ai_pull = 0; r->shelter = 0; } }

    /* escapadas programadas */
    if (s->next_attempt < s->nattempt && mg->front >= s->attempt_km[s->next_attempt] && mg->n > 12) {
        ai_break_attempt(s);
        s->next_attempt++;
    }
    /* gestionar escapadas: fin del impulso inicial */
    for (int i = 0; i < s->n; i++) {
        SimRider *r = &s->r[i];
        if (r->status != 0 || !r->is_break) continue;
        r->brk_t -= s->think_t;
        if (r->brk_t <= 0) {
            Group *g = &s->grp[r->group];
            if (g->n >= s->nact * 0.7f || g->gap < 1.0f) { r->is_break = 0; r->ai_r = 0; }  /* se rinden: siguen en el pelotón */
            else { r->brk_t = 99999; r->ai_r = 0.79f; }
        }
    }
    /* gap con grupos por delante */
    int mgi = s->main_group;
    int ahead = -1;
    if (mgi > 0) ahead = mgi - 1;
    float gap = 0, v_b = 0, gc_threat = 1e9f;
    if (ahead >= 0) {
        Group *ga = &s->grp[ahead];
        gap = (ga->front - mg->front) / (mg->v > 3 ? mg->v : 10.0f);
        v_b = ga->v;
        for (int q = ga->first; q < ga->first + ga->n; q++) {
            SimRider *r = &s->r[s->order[q]];
            if (r->gc_pre < gc_threat) gc_threat = r->gc_pre;
        }
    }
    float rem_km = rem_leader / 1000.0f;
    float nowgrade = sim_grade_at(s, mg->front);
    int ci = sim_climb_at(s, mg->front);

    /* control del pelotón: equipos con interés en cazar */
    if (!s->tt && ahead >= 0 && mg->n >= 8 && rem_km > 3.0f) {
        float lead_gc_here = 1e9f;
        for (int q = mg->first; q < mg->first + mg->n; q++) { SimRider *r = &s->r[s->order[q]]; if (r->gc_pre < lead_gc_here) lead_gc_here = r->gc_pre; }
        float threat_gap = gc_threat - lead_gc_here;
        float bn_sum = 0; int need_teams = 0; int interested[MAX_RACE_T] = {0};
        int sprint_stage = is_sprint_stage(s);
        float target_sprint = clampf(rem_km * 0.9f, 3, 150);
        for (int t = 0; t < s->nteams; t++) {
            int present = 0;
            for (int q = mg->first; q < mg->first + mg->n; q++) if (s->r[s->order[q]].tslot == t) present++;
            if (!present) continue;
            int want = 0;
            int strat = s->tstrat[t];
            if (strat == STR_ESPRINT && gap > target_sprint) want = 1;
            if ((strat == STR_GENERAL || strat == STR_CONTROL) && s->race->nstages > 1 && threat_gap < 420 && gap > clampf(rem_km * 2.0f, 40, 200)) want = 1;
            if ((strat == STR_GENERAL || strat == STR_CONTROL) && s->race->nstages == 1 && gap > clampf(rem_km * 3.5f, 20, 300)) want = 1;
            if (strat == STR_CONTROL && gap > 60) want = 1;
            if (strat == STR_AUTO && sprint_stage && gap > target_sprint * 1.4f) want = 1;
            if (gap > 600 + rem_km * 2) want = 1;  /* todo el mundo se asusta */
            if (want) { interested[t] = 1; need_teams++; }
        }
        if (need_teams > 0) {
            float excess = gap - clampf(rem_km * (sprint_stage ? 0.8f : 1.6f), 3, 150);
            float t_left = (rem_leader - 1200.0f) / (v_b > 8 ? v_b : 11.0f);
            float rate = t_left > 40 ? clampf(gap / t_left * 1.3f, 0.015f, 0.25f) : 0.25f;
            if (excess > 60) rate = fmaxf(rate, clampf(excess / 600.0f, 0.02f, 0.20f));
            float v_need = (v_b > 5 ? v_b : 11.0f) * (1.0f + rate);
            float cda = CDA_ROAD * 0.74f;
            float P_need = power_for_speed(v_need, nowgrade, cda, 0.004f);
            for (int t = 0; t < s->nteams; t++) {
                if (!interested[t]) continue;
                /* elegir hasta 3 tiradores del equipo en el grupo */
                int sel[3] = { -1, -1, -1 }; float sc[3] = { -1, -1, -1 };
                int npull = 2 + (excess > 120 ? 1 : 0);
                for (int q = mg->first; q < mg->first + mg->n; q++) {
                    int i = s->order[q]; SimRider *r = &s->r[i];
                    if (r->tslot != t || r->human) continue;
                    if (r->role == ROLE_LIDER || r->role == ROLE_ESPRINTER) continue;
                    float v = r->a[A_LLANO] + (r->role == ROLE_RODADOR ? 8 : 0) + r->energy * 0.2f;
                    for (int k = 0; k < npull && k < 3; k++) if (v > sc[k]) { for (int m = 2; m > k; m--) { sel[m] = sel[m - 1]; sc[m] = sc[m - 1]; } sel[k] = i; sc[k] = v; break; }
                }
                int cnt = 0; for (int k = 0; k < 3; k++) if (sel[k] >= 0) cnt++;
                bn_sum += cnt;
                for (int k = 0; k < 3; k++) if (sel[k] >= 0) {
                    SimRider *r = &s->r[sel[k]];
                    float cap = cap_w(r, nowgrade, 0, 0);
                    float relay = 1.0f + 0.045f * (cnt - 1);
                    float rr = clampf(P_need / (cap * relay * (need_teams > 1 ? 1.15f : 1.0f)), 0.62f, 1.12f);
                    r->ai_pull = 1; r->ai_r = rr;
                }
            }
        }
    }

    /* subidas: tirones de los gregarios de los equipos de general */
    if (!s->tt && ci >= 0 && mg->n >= 6) {
        Climb *c = &s->climbs[ci];
        float into = (mg->front - c->km0 * 1000.0f) / (c->len > 1 ? c->len : 1);
        int is_final = (rem_leader < 30000) || (c->km1 * 1000.0f > s->L - 3000);
        float base = c->cat == 0 ? 0.90f : (c->cat == 1 ? 0.86f : (c->cat == 2 ? 0.80f : 0.72f));
        if (!is_final && rem_leader > 60000 && c->cat > 1) base -= 0.1f;
        if (c->cat <= 2 && into > 0.05f) {
            for (int t = 0; t < s->nteams; t++) {
                int strat = s->tstrat[t];
                if (strat != STR_GENERAL && strat != STR_CONTROL) continue;
                int lead_in = s->tleader[t] >= 0 && s->r[s->tleader[t]].status == 0 && s->r[s->tleader[t]].group == s->main_group;
                if (!lead_in) continue;
                /* top-2 escaladores del equipo tiran */
                int done = 0;
                for (int q = mg->first; q < mg->first + mg->n && done < 3; q++) {
                    SimRider *r = &s->r[s->order[q]];
                    if (r->tslot != t || r->role == ROLE_LIDER || r->role == ROLE_ESPRINTER || r->human) continue;
                    if (r->a[A_MONTANA] < 60 || r->energy < 22) continue;
                    if (r->role == ROLE_GREGARIO || done < 1) { r->ai_pull = 1; r->ai_r = base + (done == 0 ? 0.0f : 0.03f); done++; }
                }
            }
        }
    }

    /* ataques de líderes y oportunistas */
    if (!s->tt && s->t > 600) {
        for (int q = 0; q < s->nact; q++) {
            int i = s->order[q]; SimRider *r = &s->r[i];
            if (r->human && r->order != ORD_AUTO) continue;
            if (r->human) continue;           /* el jugador ataca a mano */
            if (r->order == ORD_ATACAR || r->is_break || r->stun > 0 || r->feed_t > 0) continue;
            if (r->energy < 35 || r->wp < 70) continue;
            Group *g = &s->grp[r->group];
            float rem = s->L - r->pos;
            float grade = sim_grade_at(s, r->pos);
            float p = 0;
            int cli = sim_climb_at(s, r->pos);
            int strat = s->tstrat[r->tslot];
            if (r->role == ROLE_LIDER && (strat == STR_GENERAL || strat == STR_AUTO)) {
                if (cli >= 0) {
                    Climb *c = &s->climbs[cli];
                    float left = c->km1 * 1000.0f - r->pos;
                    int final_climb = rem < 12000 || (c->km1 * 1000.0f > s->L - 2500);
                    if (final_climb && left < 7500 && left > 700 && c->cat <= 2) p = 0.012f + 0.0012f * (r->a[A_ACEL] - 60) / 10.0f * 10.0f;
                    else if (c->cat <= 1 && left < 4000 && left > 1000 && rem < 60000) p = 0.004f;
                    if (r->gc_pre > 60 && p > 0) p *= 1.8f;
                } else if (s->st->kind == K_CLASICA && rem < 25000 && grade > 0.04f) p = 0.01f;
                else if (s->st->kind != K_LLANA && rem < 18000 && grade > 0.055f) p = 0.006f;
            } else if (r->role != ROLE_ESPRINTER && r->role != ROLE_LANZADOR) {
                if (s->st->kind == K_CLASICA && rem < 45000 && rem > 6000 && (grade > 0.04f || r->a[A_ACEL] > 78)) p = 0.0035f + (r->a[A_COLINAS] - 60) * 0.00012f;
                if (s->st->kind == K_MEDIA && rem < 32000 && rem > 4000 && grade > 0.05f) p = 0.003f + (r->a[A_COLINAS] - 60) * 0.0001f;
                if (cli >= 0 && s->climbs[cli].cat <= 2 && rem < 40000 && rem > 3000 && g->n > 5 && strat != STR_CONSERVAR) p = 0.0025f + (r->a[A_MONTANA] - 62) * 0.0001f;
                if (!is_sprint_stage(s) || s->st->dplus > 1000) {} else if (rem < 14000 && rem > 3500) p = 0.0012f;
                if (strat == STR_ESCAPADA) p *= 1.8f;
                if (strat == STR_CONSERVAR) p *= 0.2f;
            }
            if (p > 0 && srnd(s) < p * s->think_t) {
                r->order = ORD_ATACAR; r->intens = (r->role == ROLE_LIDER) ? 1 : 0; r->atk_t = 0; r->ai_r = 0;
                if (g->n > 1) sim_event(s, 1, "¡Ataque de %s (%s)!", rider_name(r->rider), TEAMS[r->team].abbr);
                /* respuesta de los rivales de general */
                for (int q2 = g->first; q2 < g->first + g->n; q2++) {
                    SimRider *o = &s->r[s->order[q2]];
                    if (o == r || o->human || o->order == ORD_ATACAR || o->tslot == r->tslot) continue;
                    if (o->role != ROLE_LIDER) continue;
                    if (o->energy < 30 || o->wp < 40) continue;
                    float dgc = fabsf(o->gc_pre - r->gc_pre);
                    float resp = (dgc < 150 || s->race->nstages == 1) ? 0.75f : 0.2f;
                    if (srnd(s) < resp) { o->order = ORD_ATACAR; o->intens = 0; o->target = (short)i; o->atk_t = -8; }
                }
            }
        }
    }

    /* tren de lanzamiento para el esprint */
    if (!s->tt && rem_km < 5.0f && rem_km > 0.3f) {
        for (int t = 0; t < s->nteams; t++) {
            int spr = s->tsprinter[t];
            if (spr < 0 || s->r[spr].status != 0 || s->r[spr].group != s->main_group) {
                /* sin esprinter, pero el lanzador puede ayudar al esprinter de su equipo en otro grupo: se ignora */
                if (spr < 0 || s->r[spr].status != 0) continue;
            }
            int strat = s->tstrat[t];
            if (strat != STR_ESPRINT && strat != STR_AUTO) continue;
            SimRider *sp = &s->r[spr];
            if (sp->group < 0 || s->grp[sp->group].n < 4) continue;
            Group *g = &s->grp[sp->group];
            /* lanzadores de este equipo en el grupo, por orden de fondo */
            int got = 0;
            for (int q = g->first; q < g->first + g->n && got < 3; q++) {
                SimRider *r = &s->r[s->order[q]];
                if (r->tslot != t || r == sp || r->role == ROLE_LIDER) continue;
                if (r->human && r->order != ORD_AUTO) continue;
                if (r->role != ROLE_LANZADOR && r->role != ROLE_RODADOR && got >= 1) continue;
                /* turno por distancia: el primero lanza a 4.2-2.7 km, el segundo 2.7-1.4, el tercero 1.4-0.5 */
                float a_from = 4.6f - 1.5f * got, a_to = 3.1f - 1.5f * got;
                if (rem_km < a_from && rem_km > a_to - 0.1f) {
                    r->ai_pull = 1; r->ai_r = 1.0f + 0.04f * got;
                }
                got++;
            }
            if (rem_km < 1.6f) sp->shelter = 1;
        }
    }

    /* vuelta a escena de seguidores: perseguir si fuera de grupo y sin orden */
    for (int i = 0; i < s->n; i++) {
        SimRider *r = &s->r[i];
        if (r->status != 0) continue;
        if (r->chase) {
            Group *g = &s->grp[r->group];
            if (g->n >= 8 || r->energy < 12) r->chase = 0;
        }
    }
}

/* ---------------------------------------------------------------- paso de simulación */
static void rider_finish(Sim *s, SimRider *r, float over) {
    float v = r->v > 1 ? r->v : 10.0f;
    r->finish_t = s->t - over / v;
    r->status = 2;
    r->place = ++s->finished;
    if (s->tt) r->finish_t -= r->start_off;
    if (r->place == 1) s->stage_winner = (int)(r - s->r);
}

static void incident_check(Sim *s, SimRider *r, float grade, int surf, Group *g) {
    float dt = s->dt;
    float base = 0.9e-6f;
    float speed_f = r->v > 16 ? 1.0f + (r->v - 16) * 0.35f : 1.0f;
    float k = base * speed_f;
    if (grade < -0.035f) k *= 5.0f;
    if (surf == 1) k *= 2.8f; else if (surf == 2) k *= 1.8f;
    if (s->rain > 0) k *= 2.6f;
    float rem = s->L - r->pos;
    if (rem < 3000 && g->n > 25) k *= 3.5f;
    if (rem < 400 && g->n > 20) k *= 3.0f;
    if (g->n < 8) k *= 0.4f;
    if (s->tt) k *= 0.3f;
    if (r->a[A_DESCENSO] < 55 && grade < -0.03f) k *= 1.5f;
    if (srnd(s) < k * dt) {
        r->stun = srange(s, 25, 120); r->bonk = 2; r->v = 0;
        s->crashes++;
        if (srnd(s) < 0.22f) { r->crash_inj = 1; r->stun = 9999; r->status = 1; s->abandons++;
            if (r->human) sim_event(s, 2, "¡%s se cae y ABANDONA!", rider_name(r->rider));
            else if (s->interactive) sim_event(s, 2, "Abandona por caída %s (%s)", rider_name(r->rider), TEAMS[r->team].abbr);
        } else {
            r->chase = 1;
            if (r->human) sim_event(s, 2, "¡Caída de %s! Pierde %d s.", rider_name(r->rider), (int)r->stun);
            else if (g->n > 1 && r->role == ROLE_LIDER) sim_event(s, 2, "¡Caída de %s (%s)!", rider_name(r->rider), TEAMS[r->team].abbr);
        }
        return;
    }
    float km = 2.2e-6f * (s->rain > 0 ? 1.5f : 1.0f) * (surf == 1 ? 3.0f : 1.0f) * (1.0f - 0.04f * G.teams[r->team].staff[STAFF_MECANICO]);
    if (srnd(s) < km * dt) {
        float fix = srange(s, 14, 38);
        /* un protector del mismo equipo cede la rueda */
        int helper = -1;
        if (r->role == ROLE_LIDER || r->role == ROLE_ESPRINTER) {
            for (int q = g->first; q < g->first + g->n; q++) {
                SimRider *o = &s->r[s->order[q]];
                if (o != r && o->tslot == r->tslot && o->order == ORD_PROTEGER && o->stun <= 0) { helper = s->order[q]; break; }
            }
        }
        if (helper >= 0) { fix = srange(s, 6, 11); s->r[helper].stun = fix + 20; s->r[helper].bonk = 1; s->r[helper].chase = 1;
            if (r->human) sim_event(s, 2, "Pinchazo de %s: %s le cede la rueda.", rider_name(r->rider), rider_name(s->r[helper].rider)); }
        else if (r->human) sim_event(s, 2, "Pinchazo de %s (%d s parado).", rider_name(r->rider), (int)fix);
        else if (r->role == ROLE_LIDER && g->n > 1) sim_event(s, 2, "Pinchazo de %s (%s).", rider_name(r->rider), TEAMS[r->team].abbr);
        r->stun = fix; r->bonk = 1; r->v = 0; r->chase = 1;
    }
}

static void award_kom(Sim *s, int ci, int si) {
    if (s->kom_cnt[ci] >= 8) return;
    for (int k = 0; k < s->kom_cnt[ci]; k++) if (s->kom_order[ci][k] == si) return;
    s->kom_order[ci][s->kom_cnt[ci]++] = si;
    Climb *c = &s->climbs[ci];
    static const int table[5][8] = { {20,15,12,10,8,6,4,2}, {10,8,6,4,2,1,0,0}, {5,3,2,1,0,0,0,0}, {2,1,0,0,0,0,0,0}, {1,0,0,0,0,0,0,0} };
    int k = s->kom_cnt[ci] - 1;
    int pts = table[c->cat > 4 ? 4 : c->cat][k];
    if (c->km1 * 1000.0f > s->L - 500) pts *= 2;
    s->r[si].kom_pts += pts;
    if (k == 0 && s->interactive) {
        SimRider *r = &s->r[si];
        sim_event(s, r->human ? 3 : 0, "Cima de %s (km %.0f): 1.º %s", climb_cat_name(c->cat), c->km1, rider_name(r->rider));
    }
}

void sim_step(Sim *s) {
    if (s->done) return;
    float dt = s->dt;
    float rem_lead = s->L - s->leader_pos;
    if (!s->tt && rem_lead < 3000 && s->nact > 0) dt = 1.0f;
    s->dt = dt;
    build_groups(s);
    s->think_t = 6.0f;
    s->think_acc += dt;
    if (!s->tt && s->think_acc >= 6.0f) { s->think_acc = 0; ai_think(s); }

    /* pasada 1: capacidades y pelotones */
    float gcap_sum[SIM_MAX] = {0}, gcap_sq[SIM_MAX] = {0}; int gcap_n[SIM_MAX] = {0};
    float gmaxdesc[SIM_MAX] = {0}; float gdesc_sum[SIM_MAX] = {0};
    static float capw[SIM_MAX];
    for (int q = 0; q < s->nact; q++) {
        int i = s->order[q]; SimRider *r = &s->r[i];
        float grade = sim_grade_at(s, r->pos < 0 ? 0 : r->pos);
        int surf = surf_at(s, r->pos < 0 ? 0 : r->pos);
        capw[i] = cap_w(r, grade, surf, s->tt);
        int g = r->group;
        if (r->stun <= 0 && !r->chase) { gcap_sum[g] += capw[i]; gcap_sq[g] += capw[i] * capw[i]; gcap_n[g]++; }
        gdesc_sum[g] += r->a[A_DESCENSO];
    }

    float vb[8]; for (int k = 0; k < 8; k++) vb[k] = 1e9f;
    for (int q = 0; q < s->nact; q++) {
        SimRider *r = &s->r[s->order[q]];
        if (!r->is_break || r->order != ORD_AUTO || r->brk_t > 90000 || r->stun > 0 || !r->brk_id) continue;
        float grade = sim_grade_at(s, r->pos < 0 ? 0 : r->pos);
        float v = speed_for_power(r->ai_r * capw[s->order[q]], grade, CDA_ROAD * 0.82f, 0.0042f);
        if (v < vb[r->brk_id]) vb[r->brk_id] = v;
    }
    float t = s->t;
    for (int gi = 0; gi < s->ngroups; gi++) {
        Group *g = &s->grp[gi];
        float pos_f = g->front;
        float grade = sim_grade_at(s, pos_f < 0 ? 0 : pos_f);
        int surf = surf_at(s, pos_f < 0 ? 0 : pos_f);
        float crr = (surf == 1 ? 0.0075f : (surf == 2 ? 0.011f : 0.0042f)) + (s->rain > 0 ? 0.0012f : 0);
        float n = gcap_n[gi] > 0 ? (float)gcap_n[gi] : 1.0f;
        float mean = gcap_sum[gi] / n;
        float var = gcap_sq[gi] / n - mean * mean; if (var < 0) var = 0;
        float cap_ref = mean + 0.55f * sqrtf(var);
        if (gcap_n[gi] == 0) cap_ref = 300;
        float rem = s->L - pos_f;
        /* fracción natural */
        float f;
        int ci = sim_climb_at(s, pos_f);
        if (ci >= 0 && grade > 0.025f) { int cat = s->climbs[ci].cat; f = cat == 0 ? 0.84f : (cat == 1 ? 0.80f : (cat == 2 ? 0.74f : (cat == 3 ? 0.66f : 0.6f))); }
        else if (grade > 0.03f) f = 0.62f + grade * 2.0f;
        else f = s->st->kind == K_MONTANA ? 0.44f : 0.47f;
        if (rem < 12000 && !s->tt) f *= 1.0f + 0.22f * (1.0f - rem / 12000.0f);
        if (g->n < 6) f *= 1.06f;          /* grupitos colaboran mejor */
        float cda_draft = CDA_ROAD * (g->n > 1 ? 0.56f : 1.0f) * (s->wind > 0 ? 1.15f : 1.0f);
        float v_nat = speed_for_power(f * cap_ref, grade, cda_draft, crr);
        float v_g = v_nat;
        if (s->tt) v_g = 0;
        /* tirones */
        float v_pull_best = 0; int pullers = 0;
        for (int q = g->first; q < g->first + g->n; q++) {
            int i = s->order[q]; SimRider *r = &s->r[i];
            if (r->stun > 0) continue;
            float rr = 0;
            if (r->order == ORD_TIRAR) rr = r->intens == 0 ? 0.82f : (r->intens == 1 ? 0.93f : 1.03f);
            else if (r->ai_pull && r->order == ORD_AUTO) rr = r->ai_r;
            else if (r->is_break && r->order == ORD_AUTO && r->brk_t > 90000) rr = r->ai_r > 0 ? r->ai_r : 0.88f;
            else if (r->order == ORD_ESCAPADA && g->n > 1 && r->wp < 50) rr = 0.88f;
            if (rr > 0) {
                float P = rr * capw[i];
                float cda = CDA_ROAD * (g->n > 1 ? (r->is_break ? 0.68f : (r->ai_pull ? 0.74f : 0.88f)) : 1.0f);
                float v = speed_for_power(P, grade, cda, crr);
                if (v > v_pull_best) v_pull_best = v;
                pullers++;
            }
        }
        if (v_pull_best > v_g) v_g = v_pull_best * (pullers > 1 ? 1.0f + 0.01f * (pullers > 4 ? 4 : pullers) : 1.0f);
        /* descensos: limite por habilidad media del grupo */
        float desc_avg = gdesc_sum[gi] / g->n;
        float vcap = 16.0f + (desc_avg - 50.0f) * 0.12f + 2.0f * clampf((0.02f + grade) * -20.0f, -2, 3);
        if (s->rain > 0) vcap *= 0.88f;
        if (grade < -0.015f && v_g > vcap) v_g = vcap;
        if (v_g < 2.0f && !s->tt) v_g = 2.0f;
        (void)t;

        if (s->ttt) v_g = speed_for_power(cap_ref * 0.95f, grade, CDA_TT * (g->n > 1 ? 0.62f : 1.0f), crr);

        /* pasada 2: cada corredor */
        for (int q = g->first; q < g->first + g->n; q++) {
            int i = s->order[q]; SimRider *r = &s->r[i];
            float cap = capw[i];
            float P = 0, v = 0, cda;
            float ratio;
            if (s->tt && s->t < r->start_off) { r->v = 0; continue; }
            if (r->stun > 0) {
                r->stun -= dt; r->v = 0; r->p_now = 0;
                if (r->stun <= 0) { r->stun = 0; r->bonk = 0; }
                continue;
            }
            int solo = 0; float rr = 1.0f;
            if (s->tt) {
                solo = 1;
                float pace = r->human ? (r->intens == 0 ? 0.90f : (r->intens == 1 ? 0.97f : 1.04f)) : 0.975f;
                if (r->order == ORD_TIRAR && r->human) pace = 1.0f;
                rr = pace;
                if (s->ttt) solo = 0;     /* en la CRE el grupo es el equipo */
            } else if (r->chase && r->order == ORD_AUTO) { solo = 1; rr = r->wp > 20 ? 1.25f : 1.04f; }
            else if (r->order == ORD_ATACAR) {
                solo = 1;
                float lvl[3] = { 1.20f, 1.33f, 1.55f };
                rr = lvl[r->intens > 2 ? 2 : r->intens];
                r->atk_t += dt;
                if (r->wp < 6) { rr = 0.98f; if (r->atk_t > 3) r->atk_t += 0; }
                if (r->atk_t < 0) { rr = 1.12f; }     /* respuesta: acelera para pillar la rueda */
                if (r->target >= 0 && s->r[r->target].status == 0) {
                    float dpos = s->r[r->target].pos - r->pos;
                    if (dpos < 15 && r->atk_t > 12) { r->order = ORD_AUTO; r->target = -1; }
                }
                if (r->wp < 3 && r->atk_t > 20) { if (!r->human) r->order = ORD_AUTO; }
                if (r->energy < 8) { rr = 0.8f; }
            } else if (r->order == ORD_ESCAPADA || (r->is_break && r->order == ORD_AUTO && r->brk_t < 90000)) {
                solo = 1;
                rr = r->order == ORD_ESCAPADA ? (r->intens == 0 ? 1.10f : (r->intens == 1 ? 1.18f : 1.28f)) : r->ai_r;
                if (r->order == ORD_ESCAPADA) { r->brk_t -= dt; if (r->brk_t < 0 || r->wp < 22) { rr = 0.92f; } }
                if (r->wp < 12 && rr > 1.0f) rr = 0.95f;
                if (g->n > 1 && rr <= 0.95f) solo = 0;   /* ya en grupo: rueda y turnos */
            } else if (r->order == ORD_PROTEGER) {
                int L = s->tleader[r->tslot];
                if (L >= 0 && s->r[L].status == 0 && L != (int)(r - s->r)) {
                    float dpos = s->r[L].pos - r->pos;
                    if (dpos > 40) { solo = 1; rr = 1.04f; }
                    else if (dpos < -40) { solo = 1; rr = 0.25f; }
                    else { s->r[L].shelter = 1; }
                }
            } else if (r->order == ORD_RECUPERAR) {
                if (r->v > 0) { float Pn = power_for_speed(v_g, grade, CDA_ROAD * 0.56f, crr); if (Pn > cap * 0.68f) { solo = 1; rr = 0.66f; } }
            } else if (r->feed_t > 0) {
                r->feed_t -= dt; solo = 1; rr = 0.5f;
                if (r->feed_t <= 0) {
                    /* entrega bidones a los compañeros del grupo */
                    int cnt = 0;
                    float gain = 7.0f + G.teams[r->team].staff[STAFF_NUTRI] * 1.0f;
                    for (int q2 = g->first; q2 < g->first + g->n; q2++) { SimRider *o = &s->r[s->order[q2]]; if (o->tslot == r->tslot) { o->energy = clampf(o->energy + gain, 0, 100); cnt++; } }
                    r->energy = clampf(r->energy + gain, 0, 100);
                    r->order = ORD_AUTO; r->chase = 1;
                    if (r->human) sim_event(s, 3, "%s reparte bidones a %d compañeros.", rider_name(r->rider), cnt);
                }
            }
            if (r->order == ORD_AUTO && r->feed_t > 0) { r->feed_t -= dt; solo = 1; rr = 0.5f; }
            /* atletas fuera de combate por energia */
            if (!solo) {
                float cdaF = CDA_ROAD * (g->n > 1 ? (r->shelter ? 0.50f : 0.56f) : 1.0f) * (s->wind > 0 ? 1.15f : 1.0f);
                if (s->ttt) cdaF = CDA_TT * (g->n > 1 ? 0.62f : 1.0f);
                float Pn = power_for_speed(v_g, grade, cdaF, crr);
                if (Pn < 0) Pn = 0;
                ratio = Pn / cap;
                float allow = 1.0f + 0.30f * (r->wp / 100.0f);       /* puede asomarse sobre el umbral gastando W' */
                if (r->order == ORD_RECUPERAR) allow = 0.9f;
                if (ratio <= allow && !(ratio > 1.0f && r->wp < 4)) { v = v_g; P = Pn; }
                else {
                    P = cap * (r->wp < 4 ? 1.0f : 1.0f);
                    v = speed_for_power(P, grade, cdaF, crr);
                    if (v > v_g) v = v_g;
                }
                /* el limite de descenso individual */
                float vcap_i = 16.0f + (r->a[A_DESCENSO] - 50.0f) * 0.12f + 2.0f * clampf((0.02f + grade) * -20.0f, -2, 3);
                if (s->rain > 0) vcap_i *= 0.88f;
                if (grade < -0.015f && v > vcap_i) v = vcap_i;
                if (v < v_g * 0.97f) { /* pierde contacto */ }
            } else {
                cda = (s->tt ? CDA_TT : CDA_ROAD) * (s->wind > 0 ? 1.1f : 1.0f);
                if (r->chase) cda *= 0.78f;
                P = rr * cap;
                v = speed_for_power(P, grade, cda, crr);
                if (r->is_break && r->order == ORD_AUTO && r->brk_id && vb[r->brk_id] < 1e8f) { v = vb[r->brk_id]; P = power_for_speed(v, grade, CDA_ROAD * 0.82f, crr); if (P > cap * 1.3f) P = cap * 1.3f; }
                float vcap_i = 16.0f + (r->a[A_DESCENSO] - 50.0f) * 0.12f + 2.0f * clampf((0.02f + grade) * -20.0f, -2, 3);
                if (s->rain > 0) vcap_i *= 0.88f;
                if (grade < -0.015f && v > vcap_i) v = vcap_i;
                if (rr < 0.4f) v = speed_for_power(rr * cap, grade, CDA_ROAD, crr);
                ratio = rr;
            }
            ratio = cap > 1 ? P / cap : 0;
            /* final: esprint */
            float remr = s->L - r->pos;
            if (!s->tt && remr < 420 && remr > -10) {
                if (!r->sprinted) {
                    r->sprinted = 1;
                    float sp = (r->a[A_ESPRINT] * 0.62f + r->a[A_ACEL] * 0.38f);
                    r->sp_gain = clampf((sp - 58.0f) * 0.0034f + 0.012f, 0.005f, 0.14f) * srange(s, 0.88f, 1.12f);
                    r->sp_gain *= clampf(r->energy / 55.0f, 0.4f, 1.0f);
                    r->sp_at = srange(s, 140, 270);
                    if (r->human && r->role != ROLE_ESPRINTER) r->sp_at = srange(s, 140, 230);
                    if (r->shelter) r->sp_gain += 0.012f;
                    if (r->human && (r->role == ROLE_ESPRINTER || r->role == ROLE_LIDER)) r->sp_at = 99999;   /* espera orden del jugador */
                }
                if (r->human && r->sp_at > 9000 && s->human_sprint) {
                    float timing = remr; float ideal = 200.0f;
                    float err = fabsf(s->human_sprint_at - ideal);
                    r->sp_at = remr + 1;
                    r->sp_gain *= clampf(1.06f - err / 900.0f, 0.88f, 1.06f);
                }
                if (r->human && r->sp_at > 9000 && remr < 130) r->sp_at = remr + 1;   /* si no pulsa, sale tarde */
                if (remr < r->sp_at) {
                    float k = 1.0f + r->sp_gain;
                    v *= k;
                    if (r->wp > 0) r->wp -= dt * 8.0f;
                }
            }
            if (r->human && r->order == ORD_AUTO && r->order == ORD_AUTO) {}
            /* consumos */
            float rcost = clampf(ratio, 0.0f, 2.0f);
            if (cap < 1) rcost = 0;
            float tend = 4400.0f + (r->a[A_FONDO] - 50) * 95.0f + (r->a[A_RESIST] - 50) * 40.0f;
            float burn = 100.0f * rcost * rcost * rcost / tend;
            burn *= (1.0f + 0.22f * s->heat);
            r->energy -= burn * dt;
            if (ratio < 0.88f) r->energy += (0.0042f + G.teams[r->team].staff[STAFF_NUTRI] * 0.0003f) * dt;
            if (r->energy > 100) r->energy = 100;
            if (r->energy < 0) r->energy = 0;
            if (ratio > 1.0f) {
                r->wp -= (P - cap) * dt / (r->wpmax * 1000.0f) * 100.0f;
                if (r->wp < 0) r->wp = 0;
            } else {
                r->wp += (cap - P) * dt / (r->wpmax * 1000.0f) * 100.0f * 0.45f * (0.7f + r->a[A_RECUP] / 140.0f);
                if (r->wp > 100) r->wp = 100;
            }
            r->r_now = ratio; r->p_now = P;
            /* v */
            r->v = v;
            r->pos += v * dt;
        }
    }

    /* eventos: avituallamiento, sprint, cimas, meta, incidentes */
    for (int q = 0; q < s->nact; q++) {
        int i = s->order[q]; SimRider *r = &s->r[i];
        if (r->status != 0) continue;
        Group *g = &s->grp[r->group];
        float grade = sim_grade_at(s, r->pos < 0 ? 0 : r->pos);
        if (!s->tt || s->t >= r->start_off) incident_check(s, r, grade, surf_at(s, r->pos < 0 ? 0 : r->pos), g);
        if (r->status != 0) continue;
        /* zona de avituallamiento */
        if (!s->feed_done && r->pos > s->feed_km * 1000.0f) {
            r->energy = clampf(r->energy + 11.0f + G.teams[r->team].staff[STAFF_NUTRI] * 1.2f, 0, 100);
        }
        /* sprint intermedio */
        if (!s->isprint_done && r->pos >= s->isprint_km * 1000.0f && s->isp_cnt < 8) {
            int dup = 0; for (int k = 0; k < s->isp_cnt; k++) if (s->isp_order[k] == i) dup = 1;
            if (!dup) {
                s->isp_order[s->isp_cnt++] = i;
                static const int tab[8] = { 20, 17, 15, 13, 11, 10, 9, 8 };
                r->pts += tab[s->isp_cnt - 1];
                if (s->isp_cnt == 1) sim_event(s, r->human ? 3 : 0, "Sprint intermedio: 1.º %s (%s)", rider_name(r->rider), TEAMS[r->team].abbr);
            }
        }
        /* cimas */
        for (int ci = 0; ci < s->nclimbs; ci++) {
            Climb *c = &s->climbs[ci];
            if (r->pos >= c->km1 * 1000.0f && r->pos < c->km1 * 1000.0f + 300) award_kom(s, ci, i);
        }
        /* meta */
        if (r->pos >= s->L) rider_finish(s, r, r->pos - s->L);
    }
    if (s->t > 0 && !s->isprint_done && s->leader_pos > s->isprint_km * 1000.0f + 400) s->isprint_done = 1;
    if (!s->feed_done && s->leader_pos > s->feed_km * 1000.0f + 3000) { s->feed_done = 1; }
    s->t += dt;
    /* terminar */
    int open = 0;
    for (int i = 0; i < s->n; i++) if (s->r[i].status == 0) open++;
    if (open == 0 || s->t > 60000.0f) {
        for (int i = 0; i < s->n; i++) if (s->r[i].status == 0) s->r[i].status = 1;
        s->done = 1;
    }
    /* limite de tiempo para los que llegan muy tarde: si el ganador ya llego hace mucho */
    if (s->finished > 0 && !s->tt) {
        float win_t = 1e9f;
        for (int i = 0; i < s->n; i++) if (s->r[i].status == 2 && s->r[i].finish_t < win_t) win_t = s->r[i].finish_t;
        if (s->t > win_t * 1.35f + 600) {
            for (int i = 0; i < s->n; i++) if (s->r[i].status == 0) { s->r[i].status = 3; s->r[i].finish_t = 1e8f; }
        }
    }
}

void sim_run_all(Sim *s) {
    int guard = 0;
    while (!s->done && guard++ < 200000) sim_step(s);
}

/* ---------------------------------------------------------------- resultados */
static int cmp_finish(const void *a, const void *b) {
    const SimRider *x = *(SimRider *const *)a, *y = *(SimRider *const *)b;
    if (x->status == 2 && y->status != 2) return -1;
    if (x->status != 2 && y->status == 2) return 1;
    if (x->finish_t < y->finish_t) return -1;
    if (x->finish_t > y->finish_t) return 1;
    return 0;
}

void sim_finalize(Sim *s, RaceRun *run) {
    SimRider *list[SIM_MAX]; int n = 0;
    for (int i = 0; i < s->n; i++) list[n++] = &s->r[i];
    qsort(list, n, sizeof(SimRider *), cmp_finish);
    /* tiempos oficiales */
    float assigned_prev = 0, real_prev = 0;
    int ttt_cnt[MAX_RACE_T] = {0};
    float ttt_time[MAX_RACE_T];
    for (int k = 0; k < MAX_RACE_T; k++) ttt_time[k] = 0;
    if (s->ttt) {
        for (int k = 0; k < n; k++) {
            SimRider *r = list[k]; if (r->status != 2) continue;
            ttt_cnt[r->tslot]++;
            if (ttt_cnt[r->tslot] <= 5) ttt_time[r->tslot] = r->finish_t;
        }
    }
    int placed = 0;
    float lim_pct = s->st->kind == K_MONTANA ? 0.20f : (s->st->kind == K_MEDIA ? 0.15f : 0.12f);
    float win_t = (n > 0 && list[0]->status == 2) ? list[0]->finish_t : 0;
    for (int k = 0; k < n; k++) {
        SimRider *r = list[k];
        RunRider *rr = &run->r[r->run_idx];
        rr->order = ORD_AUTO;
        if (r->status == 2 && !s->tt && win_t > 0 && r->finish_t > win_t * (1 + lim_pct)) r->status = 3;
        if (r->status == 1 || r->status == 3) { rr->abandoned = 1; rr->stage_pos = 0; continue; }
        float tm = r->finish_t;
        if (s->ttt) { if (ttt_time[r->tslot] > 0) tm = ttt_time[r->tslot]; }
        else if (!s->tt && placed > 0 && tm - real_prev < 1.0f) tm = assigned_prev;
        real_prev = r->finish_t; assigned_prev = tm;
        placed++;
        rr->stage_pos = (short)placed;
        rr->stage_time = tm;
        rr->gc += tm;
        if (r->place == 1 || placed == 1) {}
    }
    /* bonificaciones y puntos de etapa */
    int tabp[3] = { 10, 6, 4 };
    int pts_flat[15] = { 50, 30, 20, 18, 16, 14, 12, 10, 8, 7, 6, 5, 4, 3, 2 };
    int pts_oth[15] = { 30, 25, 22, 19, 17, 15, 13, 11, 9, 7, 6, 5, 4, 3, 2 };
    int stage_race = s->race->nstages > 1;
    int rank = 0;
    for (int k = 0; k < n && rank < 15; k++) {
        SimRider *r = list[k]; if (r->status != 2) continue;
        RunRider *rr = &run->r[r->run_idx];
        if (stage_race) {
            if (!s->tt && rank < 3 && s->tier <= TIER_WT) rr->gc -= tabp[rank];
            rr->pts += (s->st->kind == K_LLANA ? pts_flat : pts_oth)[s->tt ? 14 : rank] * (s->tt ? 0 : 1);
        }
        rank++;
    }
    for (int k = 0; k < n; k++) {
        SimRider *r = list[k]; RunRider *rr = &run->r[r->run_idx];
        rr->pts += r->pts; rr->kom += r->kom_pts;
    }
    /* guardar ganador de etapa */
    int top = 0;
    for (int k = 0; k < n && top < 24; k++) { if (list[k]->status != 2) continue; run->last_winner[top++] = list[k]->rider; }
    for (; top < 24; top++) run->last_winner[top] = -1;
    /* efecto en corredores */
    for (int k = 0; k < n; k++) {
        SimRider *r = list[k]; Rider *rd = &G.riders[r->rider];
        float used = 100.0f - r->energy;
        int hours = (int)(s->t / 3600.0f);
        (void)hours;
        float extra = used * 0.10f + (s->t / 3600.0f) * 1.1f;
        if (r->status == 2 && s->tt) extra *= 0.6f;
        float rec = G.teams[rd->team].staff[STAFF_MEDICO] * 0.25f;
        rd->fatigue = (unsigned char)clampf(rd->fatigue + extra - rec, 0, 100);
        rd->form = (unsigned char)clampf(rd->form + 0.6f, 0, 100);
        rd->race_days++;
        if (r->crash_inj) {
            rd->inj_days = (short)(7 + (int)(srnd(s) * 70));
            rd->fatigue = (unsigned char)clampf(rd->fatigue + 15, 0, 100);
        } else if (r->bonk == 2 && srnd(s) < 0.4f) {
            rd->inj_days = (short)(2 + (int)(srnd(s) * 12));
        }
    }
}

/* ---------------------------------------------------------------- roles */
void assign_roles(const short *riders, int n, int kind, unsigned char *roles) {
    int used[32] = {0};
    for (int i = 0; i < n; i++) roles[i] = ROLE_LIBRE;
    int mountain = (kind == K_MONTANA || kind == K_MEDIA);
    int classic = (kind == K_CLASICA);
    /* lider */
    int best = -1, bv = -1;
    for (int i = 0; i < n; i++) {
        Rider *r = &G.riders[riders[i]];
        int v = classic ? rider_classic_score(r) : (mountain ? rider_gc_score(r) : rider_sprint_score(r));
        if (v > bv) { bv = v; best = i; }
    }
    if (best >= 0) { roles[best] = (classic || mountain) ? ROLE_LIDER : ROLE_ESPRINTER; used[best] = 1; }
    /* esprinter (si hay lider de general) */
    if (mountain || classic) {
        int bs = -1; bv = 0;
        for (int i = 0; i < n; i++) {
            if (used[i]) continue;
            int v = rider_sprint_score(&G.riders[riders[i]]);
            if (v > bv) { bv = v; bs = i; }
        }
        if (bs >= 0 && bv >= 71) { roles[bs] = ROLE_ESPRINTER; used[bs] = 1; }
    } else {
        /* en etapas llanas el lider de general tambien: el mejor escalador */
        int bg = -1; bv = 0;
        for (int i = 0; i < n; i++) { if (used[i]) continue; int v = rider_gc_score(&G.riders[riders[i]]); if (v > bv) { bv = v; bg = i; } }
        if (bg >= 0) { roles[bg] = ROLE_LIDER; used[bg] = 1; }
    }
    /* lanzadores */
    for (int k = 0; k < 2; k++) {
        int bi = -1; bv = -1;
        for (int i = 0; i < n; i++) { if (used[i]) continue; Rider *r = &G.riders[riders[i]]; int v = r->a[A_LLANO] + r->a[A_ESPRINT] / 2 + r->a[A_ACEL] / 3; if (v > bv) { bv = v; bi = i; } }
        if (bi >= 0) { roles[bi] = ROLE_LANZADOR; used[bi] = 1; }
    }
    /* escapadista */
    {
        int bi = -1; bv = -1;
        for (int i = 0; i < n; i++) { if (used[i]) continue; int v = rider_break_score(&G.riders[riders[i]]); if (v > bv) { bv = v; bi = i; } }
        if (bi >= 0) { roles[bi] = ROLE_ESCAPADISTA; used[bi] = 1; }
    }
    for (int i = 0; i < n; i++) {
        if (used[i]) continue;
        Rider *r = &G.riders[riders[i]];
        roles[i] = (mountain && rider_climb_score(r) >= rider_flat_score(r) - 3) ? ROLE_GREGARIO : ROLE_RODADOR;
        if (!mountain && r->a[A_LLANO] < r->a[A_MONTANA]) roles[i] = ROLE_GREGARIO;
    }
}
