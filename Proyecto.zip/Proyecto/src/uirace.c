/* Pantallas de carrera: preparacion, carrera en vivo y resultados. */
#include "ui_int.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

void hub_after_race(void);

static Sim sim;
static RaceRun *run;
static int race_i, stage_idx;
static int speed = 1;
static float acc;
static int sel_s = 0;
static int hs[8], nh;
static int intens = 1;
static float anim;
static int last_nev = 0;
static int finalized = 0;
static int sprint_prompt = 0;

static const float RATE[5] = { 0, 12, 36, 90, 220 };
static const char *STR_DESC[STR_COUNT] = {
    "La IA decide según el perfil y los roles de cada corredor.",
    "Tus gregarios tiran del pelotón para neutralizar escapadas.",
    "Tu equipo prepara el esprint: lanzadores al frente y el esprínter a rueda.",
    "Protege a tu líder en la montaña; los gregarios marcan el ritmo.",
    "Se busca la etapa en una escapada lejana; sin tirar en el pelotón.",
    "Sin riesgos: se ahorra energía y no se ayuda a cazar."
};

/* ---------------------------------------------------------------- perfil y mapa */
static float prof_alt(const StageDef *st, float f) {
    float k = f * (st->npt - 1); int i = (int)k; if (i >= st->npt - 1) return (float)PT_ALT[st->pt0 + st->npt - 1];
    float t = k - i; return PT_ALT[st->pt0 + i] * (1 - t) + PT_ALT[st->pt0 + i + 1] * t;
}
static Col grade_col(float g) {
    if (g < -0.02f) return RGB(70, 110, 160);
    if (g < 0.02f) return RGB(76, 150, 96);
    if (g < 0.05f) return RGB(168, 176, 76);
    if (g < 0.08f) return RGB(226, 144, 52);
    return RGB(226, 72, 64);
}

void draw_profile(int x, int y, int w, int h, const StageDef *st, const Sim *s, int show_groups) {
    if (h > 40 || w > 200) {}
    win(x, y, w, h, show_groups ? "Perfil de la etapa" : "Perfil");
    int x0 = x + 3, x1 = x + w - 3, y0 = y + 20, y1 = y + h - 9;
    if (y1 - y0 < 10) { y0 = y + 14; }
    rect(x + 2, y + 11, w - 4, h - 13, RGB(14, 18, 40));
    float mn = 1e9f, mx = -1e9f;
    for (int i = 0; i < st->npt; i++) { float a = (float)PT_ALT[st->pt0 + i]; if (a < mn) mn = a; if (a > mx) mx = a; }
    if (mx - mn < 80) { float c = (mx + mn) / 2; mn = c - 40; mx = c + 40; }
    int W = x1 - x0;
    int topy[700];
    for (int px = 0; px <= W; px++) {
        float f = (float)px / W;
        float a = prof_alt(st, f), a2 = prof_alt(st, f + 1.0f / W + 0.002f);
        float g = (a2 - a) / (st->dist_km * 1000.0f / W * 1.0f);
        int ty = y1 - (int)((a - mn) / (mx - mn) * (y1 - y0));
        if (px < 700) topy[px] = ty;
        Col c = grade_col(g);
        rect(x0 + px, ty, 1, y1 - ty + 1, col_dark(c, 70));
        rect(x0 + px, ty, 1, 2, c);
    }
    (void)0;
    /* puertos */
    Climb cl[MAX_CLIMBS]; int nc = 0; stage_climbs(st, cl, &nc);
    for (int i = 0; i < nc; i++) {
        int px = (int)(cl[i].km1 * 1000.0f / (st->dist_km * 1000.0f) * W);
        int ty = topy[px < 700 ? px : 699];
        char t[8]; snprintf(t, sizeof t, "%s", cl[i].cat == 0 ? "HC" : (cl[i].cat == 1 ? "1" : (cl[i].cat == 2 ? "2" : (cl[i].cat == 3 ? "3" : "4"))));
        if (ty - 9 > y + 12) text_c(x0 + px, ty - 9, t, cl[i].cat <= 1 ? C_RED : C_YEL);
    }
    /* meta */
    rect(x1 - 1, y0 - 6, 1, y1 - y0 + 6, C_WHT);
    rect(x1 - 6, y0 - 6, 5, 3, C_WHT); rect(x1 - 5, y0 - 5, 2, 2, C_BLK);
    /* km */
    for (int km = 0; km < st->dist_km; km += (st->dist_km > 120 ? 50 : 20)) {
        int px = (int)(km / st->dist_km * W);
        if (km) { rect(x0 + px, y1 + 1, 1, 2, C_DIM); if (h > 50) textf(x0 + px - 6, y1 + 2, C_DIM, "%d", km); }
    }
    if (s && show_groups) {
        /* avituallamiento, sprint */
        int fx = (int)(s->feed_km * 1000.0f / s->L * W);
        text_c(x0 + fx, y1 - 8, "B", C_CYN);
        if (!s->isprint_done || s->leader_pos < s->isprint_km * 1000.0f + 400) { int sx = (int)(s->isprint_km * 1000.0f / s->L * W); text_c(x0 + sx, y1 - 8, "S", C_GRN); }
        for (int g = s->ngroups - 1; g >= 0; g--) {
            const Group *gp = &s->grp[g];
            float pos = gp->front < 0 ? 0 : gp->front;
            int px = (int)(pos / s->L * W);
            int ty = topy[px < 700 ? px : 699];
            Col c = (g == s->main_group) ? C_WHT : (gp->has_break_riders ? C_CYN : C_ORG);
            int selg = s->r[sel_s].status == 0 && s->r[sel_s].group == g;
            rect(x0 + px - 1, ty - 4, 3, 3, c);
            if (gp->mine) { rect(x0 + px - 2, ty - 8, 5, 4, C_YEL); box(x0 + px - 3, ty - 9, 7, 6, C_BLK); }
            if (selg) box(x0 + px - 3, ty - 6, 7, 7, C_WHT);
        }
    }
}

void draw_map(int x, int y, int w, int h, const StageDef *st, const Sim *s) {
    win(x, y, w, h, "Mapa");
    float la0 = 1e9f, la1 = -1e9f, lo0 = 1e9f, lo1 = -1e9f;
    for (int i = 0; i < st->npt; i++) {
        float la = PT_LAT[st->pt0 + i], lo = PT_LON[st->pt0 + i];
        if (la < la0) la0 = la; if (la > la1) la1 = la; if (lo < lo0) lo0 = lo; if (lo > lo1) lo1 = lo;
    }
    float ck = cosf((la0 + la1) * 0.5f * 3.14159f / 180.0f);
    float dx = (lo1 - lo0) * ck, dy = la1 - la0;
    if (dx < 0.01f) dx = 0.01f; if (dy < 0.01f) dy = 0.01f;
    int aw = w - 10, ah = h - 20;
    float sc = fminf(aw / dx, ah / dy);
    int ox = x + 5 + (int)((aw - dx * sc) / 2), oy = y + 15 + (int)((ah - dy * sc) / 2);
    rect(x + 2, y + 11, w - 4, h - 13, RGB(22, 36, 44));
    for (int i = 0; i < w - 4; i += 8) rect(x + 2 + i, y + 11, 1, h - 13, RGB(26, 42, 52));
    int px0 = 0, py0 = 0;
    for (int i = 0; i < st->npt; i++) {
        float la = PT_LAT[st->pt0 + i], lo = PT_LON[st->pt0 + i];
        int mx = ox + (int)((lo - lo0) * ck * sc), my = oy + (int)((la1 - la) * sc);
        if (i) { line(px0, py0, mx, my, RGB(170, 190, 230)); }
        px0 = mx; py0 = my;
    }
    float la = PT_LAT[st->pt0], lo = PT_LON[st->pt0];
    disc(ox + (int)((lo - lo0) * ck * sc), oy + (int)((la1 - la) * sc), 2, C_GRN);
    la = PT_LAT[st->pt0 + st->npt - 1]; lo = PT_LON[st->pt0 + st->npt - 1];
    int fx = ox + (int)((lo - lo0) * ck * sc), fy = oy + (int)((la1 - la) * sc);
    rect(fx - 2, fy - 2, 5, 5, C_RED); rect(fx, fy - 2, 2, 2, C_WHT);
    if (s) for (int g = s->ngroups - 1; g >= 0; g--) {
        const Group *gp = &s->grp[g];
        float f = (gp->front < 0 ? 0 : gp->front) / s->L; if (f > 1) f = 1;
        int i = (int)(f * (st->npt - 1));
        float la2 = PT_LAT[st->pt0 + i], lo2 = PT_LON[st->pt0 + i];
        int mx = ox + (int)((lo2 - lo0) * ck * sc), my = oy + (int)((la1 - la2) * sc);
        Col c = (g == s->main_group) ? C_WHT : (gp->has_break_riders ? C_CYN : C_ORG);
        disc(mx, my, 2, c);
        if (gp->mine) { box(mx - 3, my - 3, 7, 7, C_YEL); }
    }
    if (st->est_map) text(x + 5, y + h - 9, "trazado estimado", C_DIM);
}

/* ---------------------------------------------------------------- preparacion */
static int human_slot(void) { for (int i = 0; i < run->nr; i++) if (run->r[i].human) return run->r[i].tslot; return -1; }

void race_enter(void) {
    int list[8]; int n = today_races(list, 8);
    if (!n) return;
    int best = list[0];
    for (int i = 1; i < n; i++) if (RACES[list[i]].tier < RACES[best].tier) best = list[i];
    race_i = best;
    RaceEntry *e = &G.entry[race_i];
    char why[80];
    if (e->squad_n == 0 || !squad_valid(race_i, why, sizeof why)) {
        RaceRun *ex = game_race_run(race_i, 0);
        if (!ex) squad_auto(race_i);
    }
    run = game_race_run(race_i, 1);
    if (!run) { toast("No se pudo crear la carrera."); return; }
    stage_idx = run->stage;
    if (human_slot() < 0) {
        /* el jugador no esta en la carrera (sin equipo): simular */
        game_prepare_stage(run);
        static Sim tmp; sim_setup(&tmp, stage_idx, run, 0); sim_run_all(&tmp); game_finish_interactive(&tmp, run);
        hub_after_race();
        return;
    }
    sim_setup(&sim, stage_idx, run, 1);
    g_scr = SC_PREP; finalized = 0;
}

void race_debug_start(int interactive);
static void start_race(int interactive) {
    game_prepare_stage(run);
    if (!interactive) {
        sim_setup(&sim, stage_idx, run, 0);
        sim_run_all(&sim);
        game_finish_interactive(&sim, run);
        finalized = 1; g_scr = SC_RESULT; return;
    }
    sim_setup(&sim, stage_idx, run, 1);
    nh = 0; for (int i = 0; i < sim.n && nh < 8; i++) if (sim.r[i].human) hs[nh++] = i;
    sel_s = nh ? hs[0] : 0;
    speed = 0; acc = 0; last_nev = 0; finalized = 0; sprint_prompt = 0;
    g_scr = SC_RACE;
}

void prep_draw(void) {
    clear(C_BG);
    const StageDef *st = &STAGES[stage_idx]; const RaceDef *rd = &RACES[race_i];
    rect(0, 0, SW, 17, C_PANEL2);
    chip(6, 5, G.player);
    char t[160]; snprintf(t, sizeof t, "%s — Etapa %d/%d: %s → %s", rd->name, st->num, rd->nstages, st->from, st->to);
    text(18, 5, t, C_YEL);
    textf(520, 5, C_TEXT, "%s", day_long(G.day));
    draw_profile(2, 20, 420, 118, st, NULL, 0);
    draw_map(426, 20, 212, 118, st, NULL);
    win(2, 142, 206, 200, "La etapa");
    textf(8, 156, C_TEXT, "Tipo: %s", kind_name(st->kind));
    textf(8, 167, C_TEXT, "Distancia: %.1f km", st->dist_km);
    textf(8, 178, C_TEXT, "Desnivel +: %d m", st->dplus);
    textf(8, 189, C_TEXT, "Tiempo: %s", sim.rain > 0 ? "LLUVIA (más caídas)" : (sim.heat > 0 ? "CALOR (más desgaste)" : (sim.wind > 0 ? "VIENTO" : "Despejado")));
    textf(8, 200, sim.rain > 0 ? C_ORG : C_DIM, "%s", st->est_profile ? "Perfil estimado" : "Perfil GPX real");
    text(8, 214, "Puertos:", C_YEL);
    for (int i = 0; i < sim.nclimbs && i < 9; i++) {
        Climb *c = &sim.climbs[i];
        textf(8, 225 + i * 11, C_TEXT, "km %3.0f  %-3s %.1fkm %.1f%%", c->km1, climb_cat_name(c->cat), c->len / 1000.0f, c->grade);
    }
    if (!sim.nclimbs) text(8, 226, "Sin puertos puntuables.", C_DIM);

    win(212, 142, 226, 200, "Tu equipo en la etapa");
    int slot = human_slot(); int row = 0;
    for (int i = 0; i < run->nr; i++) {
        RunRider *rr = &run->r[i]; if (!rr->human || rr->abandoned) continue;
        Rider *r = &G.riders[rr->rider]; int y = 156 + row * 14;
        text_fit(218, y + 2, 82, r->name, C_TEXT);
        if (btn(300, y, 58, 11, role_name(rr->role), C_PANEL3)) {
            rr->role = (unsigned char)((rr->role + 1) % ROLE_COUNT);
            for (int k = 0; k < G.entry[race_i].squad_n; k++) if (G.entry[race_i].squad[k] == rr->rider) G.entry[race_i].squad_role[k] = rr->role;
        }
        bar(362, y + 2, 30, 6, r->form, C_GRN); bar(396, y + 2, 30, 6, r->fatigue, r->fatigue > 70 ? C_RED : C_ORG);
        row++;
    }
    text(218, 156 + row * 14 + 4, "Clic en el rol para cambiarlo.", C_DIM);
    text(362, 146 + 0, "Forma", C_DIM); text(396, 146, "Fatiga", C_DIM);

    win(442, 142, 196, 200, "Táctica de equipo");
    unsigned char *stg = &run->strat[slot < 0 ? 0 : slot];
    if (btn(448, 156, 184, 14, strat_name(*stg), RGB(80, 100, 170))) { *stg = (unsigned char)((*stg + 1) % STR_COUNT); G.entry[race_i].strat = *stg; }
    text_wrap(448, 176, 184, STR_DESC[*stg], C_DIM, 5);
    text_wrap(448, 226, 184, st->kind == K_MONTANA ? "Consejo: protege a tu líder, ataca en la última subida." : (st->kind == K_LLANA ? "Consejo: control + lanzadores para el esprint." : (st->kind >= K_CRI && st->kind <= K_CRE ? "Contrarreloj: dosifica el esfuerzo." : "Etapa variada: busca la escapada o el ataque final.")), C_TEXT, 4);
    if (btn(448, 276, 184, 20, "SALIR A CARRERA", RGB(60, 130, 70))) start_race(1);
    if (btn(448, 300, 184, 14, "Simular etapa (automática)", RGB(70, 90, 140))) start_race(0);
    if (btn(448, 318, 184, 14, "Volver al menú de gestión", RGB(120, 60, 60))) g_scr = SC_HUB;
}

/* ---------------------------------------------------------------- escena lateral */
static float terrain_y(const Sim *s, float pos, float cam, float alt_c, int base, float pxm) {
    float a = sim_alt_at(s, pos < 0 ? 0 : pos);
    return base - (a - alt_c) * pxm * 2.6f + (pos - cam) * 0.0f;
}

static void draw_scene(int x, int y, int w, int h) {
    SimRider *fr = &sim.r[sel_s];
    int gi = fr->status == 0 ? fr->group : 0;
    if (gi < 0 || gi >= sim.ngroups) gi = 0;
    Group *g = sim.ngroups ? &sim.grp[gi] : NULL;
    char title[64]; snprintf(title, sizeof title, "Cámara: %s", g ? (gi == 0 ? "Cabeza de carrera" : (gi == sim.main_group ? "Pelotón" : "Grupo")) : "-");
    win(x, y, w, h, title);
    int ix = x + 2, iy = y + 11, iw = w - 4, ih = h - 13;
    set_clip(ix, iy, iw, ih);
    float cam = g ? g->front : 0;
    float pxm = 1.1f;
    int base = iy + ih - 26;
    float alt_c = sim_alt_at(&sim, cam < 0 ? 0 : cam);
    /* cielo */
    Col top = sim.rain > 0 ? RGB(70, 76, 96) : (sim.heat > 0 ? RGB(120, 120, 200) : RGB(60, 110, 200));
    Col hor = sim.rain > 0 ? RGB(150, 156, 170) : (sim.heat > 0 ? RGB(255, 200, 130) : RGB(180, 220, 250));
    for (int j = 0; j < ih; j++) rect(ix, iy + j, iw, 1, col_mix(top, hor, j * 256 / ih));
    /* sol/nubes */
    if (sim.rain <= 0) disc(ix + iw - 40, iy + 18, 7, RGB(255, 244, 190));
    for (int c = 0; c < 4; c++) { int cx = ix + (int)(fmodf(c * 120 + 300 - cam * 0.02f, iw + 80)) - 40; if (cx < ix - 30) cx += iw + 80; rect(cx, iy + 10 + c * 5, 30, 4, RGB(236, 240, 250)); rect(cx + 6, iy + 7 + c * 5, 18, 4, RGB(246, 248, 255)); }
    /* montanas lejanas (paralaje) */
    for (int lay = 0; lay < 2; lay++) {
        Col mc = lay == 0 ? RGB(112, 120, 170) : RGB(76, 92, 120);
        float par = lay == 0 ? 0.08f : 0.25f;
        for (int px = 0; px < iw; px++) {
            float wp = cam * par + px * (lay == 0 ? 0.9f : 1.6f);
            float hh = 14 + lay * 8 + 12 * sinf(wp * 0.02f) + 6 * sinf(wp * 0.057f + lay) + (alt_c * 0.012f);
            int top_y = base - 20 - (int)hh - lay * 6;
            rect(ix + px, top_y, 1, iy + ih - top_y, mc);
        }
    }
    /* terreno y carretera */
    int cx = ix + iw * 56 / 100;
    int prev_y = 0;
    for (int px = 0; px < iw; px++) {
        float wp = cam + (px + ix - cx) / pxm;
        int ty = (int)terrain_y(&sim, wp, cam, alt_c, base, pxm);
        Col grass = sim.heat > 0 ? RGB(150, 140, 70) : RGB(60, 130, 70);
        rect(ix + px, ty + 4, 1, iy + ih - ty - 3, col_dark(grass, 30));
        rect(ix + px, ty + 6, 1, 6, RGB(60, 60, 72));          /* asfalto */
        rect(ix + px, ty + 4, 1, 2, grass);
        rect(ix + px, ty + 5, 1, 1, RGB(190, 190, 200));      /* arcen */
        int surf = 0; (void)surf;
        if ((((int)(wp / 6.0f)) & 3) == 0) rect(ix + px, ty + 9, 1, 1, RGB(230, 220, 120));
        /* postes y espectadores */
        if (((int)wp % 120) == 0) rect(ix + px, ty - 6, 1, 10, RGB(220, 220, 230));
        prev_y = ty;
    }
    (void)prev_y;
    /* km marcador, meta */
    float to_fin = sim.L - cam;
    if (to_fin < 400 && to_fin > -50) {
        int fxp = cx + (int)(to_fin * pxm);
        int ty = (int)terrain_y(&sim, sim.L, cam, alt_c, base, pxm);
        rect(fxp, ty - 26, 2, 30, C_WHT); rect(fxp + 40 > ix + iw ? fxp : fxp, ty - 28, 1, 1, C_WHT);
        for (int k = 0; k < 8; k++) rect(fxp - 6 + k * 3, ty - 30, 3, 4, (k & 1) ? C_BLK : C_WHT);
        rect(fxp - 8, ty - 26, 26, 2, C_RED);
        text_c(fxp + 5, ty - 40, "META", C_YEL);
    }
    /* ciclistas del grupo seleccionado */
    if (g) {
        int shown[14]; int ns = 0;
        for (int q = g->first; q < g->first + g->n && ns < 14; q++) {
            int i = sim.order[q];
            if (sim.r[i].human) shown[ns++] = i;
        }
        int hum = ns;
        for (int q = g->first; q < g->first + g->n && ns < 9; q++) {
            int i = sim.order[q]; if (sim.r[i].human) continue;
            shown[ns++] = i;
        }
        (void)hum;
        /* ordenar por posicion en el grupo (shown ya esta por orden aproximado) */
        for (int a = 0; a < ns; a++) for (int b = a + 1; b < ns; b++) if (sim.r[shown[b]].pos > sim.r[shown[a]].pos) { int t = shown[a]; shown[a] = shown[b]; shown[b] = t; }
        int frame = (int)(anim * 9);
        for (int k = ns - 1; k >= 0; k--) {
            SimRider *r = &sim.r[shown[k]];
            int sxp = cx - k * 17 + (k & 1) * 4;
            float wp = cam + (sxp - cx) / pxm;
            int ty = (int)terrain_y(&sim, wp, cam, alt_c, base, pxm) + 11 + ((k % 3) - 1) * 2;
            Col c1 = team_c1(r->team), c2 = team_c2(r->team);
            int fr_i = (r->v > 0.5f) ? frame + k : 0;
            draw_cyclist(sxp, ty, c1, c2, fr_i, 2, r->human);
            if (shown[k] == sel_s) { text_c(sxp, ty - 36, "\x04", C_YEL); rect(sxp - 1, ty - 28, 3, 1, C_YEL); }
            else if (r->human) text_c(sxp, ty - 34, "\x01", C_YEL);
            if (r->human && k < 6) { char nb[20]; snprintf(nb, sizeof nb, "%.9s", r->human ? rider_name(r->rider) : ""); (void)nb; }
        }
        if (g->n > ns) textf(ix + iw / 2 - 20, iy + 3, C_WHT, "+%d más", g->n - ns);
        /* lluvia */
        if (sim.rain > 0) for (int i = 0; i < 60; i++) { int rx = ix + (int)((i * 37 + (int)(anim * 300)) % iw), ry = iy + (int)((i * 53 + (int)(anim * 420)) % ih); line(rx, ry, rx - 2, ry + 4, RGB(190, 200, 230)); }
        /* HUD de la escena */
        float grade = sim_grade_at(&sim, cam < 0 ? 0 : cam);
        int cl = sim_climb_at(&sim, cam);
        textf(ix + 4, iy + 3, C_WHT, "%.0f km/h", g->v * 3.6f);
        textf(ix + 4, iy + 12, grade > 0.05f ? C_RED : (grade > 0.02f ? C_ORG : C_WHT), "%+.1f%%", grade * 100);
        textf(ix + iw - 70, iy + 3, C_WHT, "%.0f m", alt_c);
        if (cl >= 0) textf(ix + iw - 70, iy + 12, C_YEL, "Puerto %s", climb_cat_name(sim.climbs[cl].cat));
    }
    reset_clip();
    /* indicadores de grupos cercanos */
    if (g) {
        if (gi > 0) { Group *a = &sim.grp[gi - 1]; char t[48]; float gp = (a->front - g->front) / (g->v > 3 ? g->v : 10); snprintf(t, sizeof t, "▲ delante %d:%02d (%d)", (int)gp / 60, (int)gp % 60, a->n); rect(ix + iw - 118, iy + ih - 12, 116, 10, C_BLK); text(ix + iw - 116, iy + ih - 11, t, C_CYN); }
        if (gi + 1 < sim.ngroups) { Group *b = &sim.grp[gi + 1]; char t[48]; float gp = (g->front - b->front) / (b->v > 3 ? b->v : 10); snprintf(t, sizeof t, "▼ detrás %d:%02d (%d)", (int)gp / 60, (int)gp % 60, b->n); rect(ix + 2, iy + ih - 12, 116, 10, C_BLK); text(ix + 4, iy + ih - 11, t, C_ORG); }
    }
}

/* ---------------------------------------------------------------- carrera en vivo */
static const char *grp_name(int gi) {
    static char b[24];
    Group *g = &sim.grp[gi];
    if (sim.tt) { snprintf(b, sizeof b, "%s", ""); return b; }
    if (gi == sim.main_group) return "PELOTÓN";
    if (g->has_break_riders && gi < sim.main_group) return "ESCAPADA";
    if (gi < sim.main_group) return "Persigue";
    if (g->n >= 12) return "Gruppetto";
    return "Rezagado";
}

static void order_key(int vk) {
    SimRider *r = &sim.r[sel_s];
    switch (vk) {
        case 'A': sim_set_order(&sim, sel_s, ORD_ATACAR, intens); break;
        case 'E': sim_set_order(&sim, sel_s, ORD_ESCAPADA, intens); break;
        case 'T': sim_set_order(&sim, sel_s, ORD_TIRAR, intens); break;
        case 'P': sim_set_order(&sim, sel_s, ORD_PROTEGER, intens); break;
        case 'B': sim_set_order(&sim, sel_s, ORD_AVITUALLAR, intens); break;
        case 'R': sim_set_order(&sim, sel_s, ORD_RECUPERAR, intens); break;
        case 'X': r->order = ORD_AUTO; r->ai_pull = 0; if (r->is_break) r->is_break = 0; break;
    }
}

void race_draw(float dt) {
    anim += dt;
    clear(C_BG);
    const StageDef *st = sim.st; const RaceDef *rd = sim.race;
    /* ---- avance de la simulacion ---- */
    float rem = sim.L - sim.leader_pos;
    if (!sim.done) {
        if (speed > 1 && rem < 5000 && !sim.tt) speed = 1;
        if (!sim.tt && rem < 900 && speed > 1) speed = 1;
        if (speed > 0) {
            acc += RATE[speed] * dt;
            int guard = 0;
            while (acc >= sim.dt && !sim.done && guard++ < 300) { acc -= sim.dt; sim_step(&sim); }
        }
        if (sim.nev > last_nev || (sim.nev == EV_MAX && last_nev != sim.nev)) {
            for (int i = (last_nev > sim.nev ? 0 : last_nev); i < sim.nev; i++) if (sim.ev[i].kind >= 2 || sim.ev[i].kind == 3) { if (speed > 2) speed = 2; }
            last_nev = sim.nev;
        }
    }
    if (sim.done && !finalized) { game_finish_interactive(&sim, run); finalized = 1; g_scr = SC_RESULT; return; }
    sprint_prompt = (!sim.tt && rem < 750 && rem > 40 && !sim.human_sprint);
    /* ---- entrada ---- */
    int shifted = 0; (void)shifted;
    for (int i = 0; i < IN.nk; i++) {
        int k = IN.keys[i];
        if (k == VK_UP_) { int p = 0; for (int h = 0; h < nh; h++) if (hs[h] == sel_s) p = h; sel_s = hs[(p + nh - 1) % nh]; }
        else if (k == VK_DOWN_) { int p = 0; for (int h = 0; h < nh; h++) if (hs[h] == sel_s) p = h; sel_s = hs[(p + 1) % nh]; }
        else if (k == VK_RIGHT_) { if (speed < 4) speed++; }
        else if (k == VK_LEFT_) { if (speed > 0) speed--; }
        else if (k == VK_SPACE_) { if (sprint_prompt) { sim_launch_sprint(&sim); speed = 1; sim_event(&sim, 3, "¡Lanzas el esprint a %.0f m!", rem); } else speed = speed ? 0 : 1; }
        else if (k == '1') intens = 0; else if (k == '2') intens = 1; else if (k == '3') intens = 2;
        else if (k == 'Z') { int sl = sim.human_team_slot; if (sl >= 0) sim.tstrat[sl] = (unsigned char)((sim.tstrat[sl] + 1) % STR_COUNT); }
        else order_key(k);
    }
    /* ---- barra superior ---- */
    rect(0, 0, SW, 16, C_PANEL2); rect(0, 16, SW, 1, C_LINE_D);
    chip(4, 4, G.player);
    char hd[150]; snprintf(hd, sizeof hd, "%s · Etapa %d: %s → %s · %s", rd->name, st->num, st->from, st->to, kind_name(st->kind));
    text_fit(14, 4, 330, hd, C_YEL);
    int el = (int)sim.t; textf(350, 4, C_TEXT, "%d:%02d:%02d", el / 3600, (el / 60) % 60, el % 60);
    textf(404, 4, C_CYN, "%.1f / %.1f km", fmaxf(0, sim.leader_pos) / 1000.0f, sim.L / 1000.0f);
    static const char *sl[5] = { "||", ">", ">>", ">>>", ">>>>" };
    for (int s = 0; s < 5; s++) if (btn(500 + s * 28, 2, 27, 12, sl[s], s == speed ? RGB(90, 130, 200) : C_PANEL3)) speed = s;
    /* ---- ventanas ---- */
    draw_scene(2, 18, 330, 100);
    draw_map(334, 18, 140, 100, st, &sim);
    /* grupos */
    win(476, 18, 162, 100, "Grupos en carrera");
    int shown_g = 0;
    for (int gi = 0; gi < sim.ngroups && shown_g < 8; gi++) {
        Group *g = &sim.grp[gi];
        if (g->n < 1) continue;
        if (sim.tt && !g->mine && gi > 5) continue;
        int y = 31 + shown_g * 10;
        Col c = (gi == sim.main_group) ? C_WHT : (g->has_break_riders ? C_CYN : C_ORG);
        int sel = sim.r[sel_s].status == 0 && sim.r[sel_s].group == gi;
        if (sel) rect(478, y - 1, 158, 10, C_PANEL3);
        if (hit(478, y - 1, 158, 10) && IN.click) {
            int found = -1; for (int h = 0; h < nh; h++) if (sim.r[hs[h]].status == 0 && sim.r[hs[h]].group == gi) { found = hs[h]; break; }
            if (found >= 0) sel_s = found;
        }
        rect(480, y + 1, 4, 5, c);
        if (sim.tt) textf(487, y, C_TEXT, "%.9s", rider_name(sim.r[sim.order[g->first]].rider));
        else text_fit(487, y, 58, grp_name(gi), C_TEXT);
        textf(548, y, C_TEXT, "%d", g->n);
        if (gi == 0) text(580, y, "cab", C_DIM); else textf(572, y, C_DIM, "+%d:%02d", (int)g->gap / 60, (int)g->gap % 60);
        if (g->mine) textf(620, y, C_YEL, "\x08%d", g->mine);
        shown_g++;
    }
    draw_profile(2, 120, 472, 70, st, &sim, 1);
    /* noticias */
    win(476, 120, 162, 70, "Radio carrera");
    {
        int lines = 0;
        for (int i = 0; i < 6 && lines < 6; i++) {
            int idx = sim.nev - 1 - i; if (idx < 0) break;
            Event *e = &sim.ev[idx];
            Col c = e->kind == 3 ? C_YEL : (e->kind == 2 ? C_RED : (e->kind == 1 ? C_CYN : C_TEXT));
            char t[120]; snprintf(t, sizeof t, "%d:%02d:%02d %s", e->t_sec / 3600, (e->t_sec / 60) % 60, e->t_sec % 60, e->text);
            lines += text_wrap(480, 133 + lines * 9, 156, t, c, 6 - lines);
        }
    }
    /* ---- tu equipo ---- */
    win(2, 192, 472, 150, "Tu equipo - A atacar, E escapada, T tirar, P proteger, B bidones, R ahorrar");
    text(6, 205, "#", C_DIM); text(16, 205, "Corredor", C_DIM); text(110, 205, "Rol", C_DIM); text(142, 205, "Orden", C_DIM); text(200, 205, "Energía", C_DIM); text(250, 205, "Anaer.", C_DIM); text(300, 205, "Estado", C_DIM); text(360, 205, "Gap", C_DIM); text(404, 205, "km/h", C_DIM); text(436, 205, "Esf.", C_DIM);
    for (int h = 0; h < nh; h++) {
        SimRider *r = &sim.r[hs[h]]; int y = 215 + h * 11;
        int sel = hs[h] == sel_s;
        if (sel) rect(4, y - 1, 468, 11, C_PANEL3); else if (hit(4, y - 1, 468, 11)) rect(4, y - 1, 468, 11, C_PANEL2);
        if (hit(4, y - 1, 468, 11) && IN.click) sel_s = hs[h];
        textf(6, y, C_DIM, "%d", h + 1);
        text_fit(16, y, 92, rider_name(r->rider), r->status ? C_DIM : (sel ? C_YEL : C_TEXT));
        text(110, y, role_short(r->role), r->role == ROLE_LIDER ? C_YEL : C_CYN);
        text(142, y, order_name(r->order), r->order == ORD_AUTO ? C_DIM : C_GRN);
        if (r->order == ORD_ATACAR || r->order == ORD_TIRAR || r->order == ORD_ESCAPADA) text(180, y, r->intens == 0 ? "-" : (r->intens == 1 ? "=" : "+"), C_ORG);
        bar(200, y + 1, 44, 6, (int)r->energy, r->energy > 55 ? C_GRN : (r->energy > 25 ? C_ORG : C_RED));
        bar(250, y + 1, 44, 6, (int)r->wp, C_CYN);
        text(300, y, sim_status_name(r), r->status ? C_RED : (r->stun > 0 ? C_RED : (r->energy < 15 ? C_RED : C_TEXT)));
        if (r->status == 0) {
            float gp = sim_gap_to_leader(&sim, hs[h]);
            if (sim.r[hs[h]].group == 0) text(360, y, "cabeza", C_DIM); else textf(360, y, C_TEXT, "+%d:%02d", (int)gp / 60, (int)gp % 60);
            textf(404, y, C_TEXT, "%.0f", r->v * 3.6f);
            textf(436, y, r->r_now > 1.05f ? C_RED : C_DIM, "%d%%", (int)(r->r_now * 100));
        } else if (r->status == 2) textf(360, y, C_GRN, "%d.º", r->place);
    }
    /* botones de orden */
    int by = 215 + 8 * 11 + 2;
    static const struct { const char *l; int ord; } B[7] = { {"Atacar",ORD_ATACAR},{"Escapada",ORD_ESCAPADA},{"Tirar",ORD_TIRAR},{"Proteger",ORD_PROTEGER},{"Bidones",ORD_AVITUALLAR},{"Ahorrar",ORD_RECUPERAR},{"Auto",ORD_AUTO} };
    for (int b = 0; b < 7; b++) if (btn(4 + b * 60, by, 58, 12, B[b].l, sim.r[sel_s].order == B[b].ord ? RGB(70, 130, 80) : C_PANEL3)) { if (B[b].ord == ORD_AUTO) order_key('X'); else sim_set_order(&sim, sel_s, B[b].ord, intens); }
    static const char *inl[3] = { "Suave", "Media", "Máxima" };
    if (btn(426, by, 46, 12, inl[intens], RGB(120, 90, 40))) intens = (intens + 1) % 3;
    int by2 = by + 14;
    int sl_ = sim.human_team_slot;
    if (sl_ >= 0) { char t[64]; snprintf(t, sizeof t, "Táctica: %s (Z)", strat_name(sim.tstrat[sl_])); if (btn(4, by2, 180, 12, t, RGB(80, 100, 170))) sim.tstrat[sl_] = (unsigned char)((sim.tstrat[sl_] + 1) % STR_COUNT); }
    /* esprint */
    if (sprint_prompt) {
        int flash = ((int)(anim * 6)) & 1;
        if (btn(190, by2 - 1, 140, 14, "¡ESPRINT! (ESPACIO)", flash ? RGB(210, 70, 50) : RGB(150, 40, 30))) { sim_launch_sprint(&sim); speed = 1; sim_event(&sim, 3, "¡Lanzas el esprint a %.0f m!", rem); }
        /* medidor de distancia */
        rect(336, by2, 134, 11, C_BLK);
        int zone0 = (int)(134 * (1.0f - 260.0f / 750.0f)), zone1 = (int)(134 * (1.0f - 150.0f / 750.0f));
        rect(336 + zone0, by2 + 1, zone1 - zone0, 9, RGB(40, 140, 60));
        int cur = (int)(134 * (1.0f - rem / 750.0f)); rect(336 + cur, by2, 2, 11, C_YEL);
    }
    /* ---- clasificacion en vivo ---- */
    win(476, 192, 162, 150, "Orden de carrera");
    for (int k = 0; k < 13 && k < sim.nact; k++) {
        SimRider *r = &sim.r[sim.order[k]]; int y = 205 + k * 10;
        if (r->human) rect(478, y - 1, 158, 10, col_mix(C_PANEL, C_YEL, 60));
        textf(480, y, C_DIM, "%d", k + 1); chip(492, y, r->team);
        text_fit(502, y, 80, rider_name(r->rider), r->human ? C_YEL : C_TEXT);
        float gp = sim_gap_to_leader(&sim, sim.order[k]);
        if (sim.r[sim.order[k]].group == 0 && !sim.tt) text(600, y, "cab", C_DIM); else if (!sim.tt) textf(596, y, C_DIM, "+%d:%02d", (int)gp / 60, (int)gp % 60);
    }
    if (sim.tt) text(480, 340 - 12, "Orden por distancia recorrida", C_DIM);
    rect(0, 344, SW, 16, C_PANEL2);
    textf(6, 349, C_DIM, "Espacio: pausa/esprint · ←/→ velocidad · ↑/↓ corredor · 1/2/3 intensidad · Z táctica");
    if (speed == 0 && !sim.done) text_c(180, 80, "|| PAUSA", C_YEL);
}

/* ---------------------------------------------------------------- resultados */
static int run_index(int rider) { for (int i = 0; i < run->nr; i++) if (run->r[i].rider == rider) return i; return -1; }

void result_draw(void) {
    clear(C_BG);
    const StageDef *st = &STAGES[stage_idx]; const RaceDef *rd = &RACES[race_i];
    rect(0, 0, SW, 17, C_PANEL2);
    char hd[160]; snprintf(hd, sizeof hd, "RESULTADO — %s · Etapa %d: %s → %s", rd->name, st->num, st->from, st->to);
    text(8, 5, hd, C_YEL);
    win(2, 20, 316, 300, "Clasificación de la etapa");
    float win_t = 0;
    for (int k = 0; k < 24; k++) {
        int rider = run->last_winner[k]; if (rider < 0) break;
        int ri = run_index(rider); if (ri < 0) continue;
        RunRider *rr = &run->r[ri]; Rider *r = &G.riders[rider];
        int y = 34 + k * 11;
        if (rr->human) rect(4, y - 1, 312, 11, col_mix(C_PANEL, C_YEL, 60));
        textf(8, y, C_DIM, "%2d", k + 1); chip(26, y, r->team);
        text_fit(38, y, 150, r->name, rr->human ? C_YEL : C_TEXT);
        text(194, y, TEAMS[r->team].abbr, C_DIM);
        if (k == 0) { win_t = rr->stage_time; int s = (int)rr->stage_time; textf(230, y, C_TEXT, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60); }
        else { int d = (int)(rr->stage_time - win_t); textf(236, y, C_DIM, "+%d:%02d", d / 60, d % 60); }
    }
    win(322, 20, 316, 180, rd->nstages > 1 ? "Clasificación general" : "Resumen");
    if (rd->nstages > 1) {
        short ord[MAX_RUN_R]; int n = run_gc_sorted(run, ord);
        float lead = n ? run->r[ord[0]].gc : 0;
        for (int k = 0; k < 14 && k < n; k++) {
            RunRider *rr = &run->r[ord[k]]; Rider *r = &G.riders[rr->rider]; int y = 34 + k * 11;
            if (rr->human) rect(324, y - 1, 312, 11, col_mix(C_PANEL, C_YEL, 60));
            textf(328, y, C_DIM, "%2d", k + 1); chip(346, y, r->team);
            text_fit(358, y, 150, r->name, rr->human ? C_YEL : C_TEXT);
            text(512, y, TEAMS[r->team].abbr, C_DIM);
            if (k == 0) text(560, y, "líder", C_YEL); else { int d = (int)(rr->gc - lead); textf(556, y, C_DIM, "+%d:%02d", d / 60, d % 60); }
        }
    } else {
        text_wrap(330, 36, 300, G.nnews ? G.news[G.nnews - 1] : "Carrera terminada.", C_TEXT, 3);
    }
    win(322, 204, 316, 116, "Tu equipo");
    int row = 0, best = 99;
    for (int i = 0; i < run->nr; i++) if (run->r[i].human) {
        RunRider *rr = &run->r[i]; int y = 218 + row * 11; if (row >= 8) break;
        text_fit(328, y, 130, rider_name(rr->rider), C_TEXT);
        if (rr->abandoned) text(470, y, "abandona", C_RED); else { textf(470, y, C_TEXT, "%d.º", rr->stage_pos); if (rr->stage_pos < best) best = rr->stage_pos; if (rr->stage_pos > 0) { int d = (int)(rr->stage_time - win_t); textf(520, y, C_DIM, "+%d:%02d", d / 60, d % 60); } }
        row++;
    }
    if (btn(2, 326, 200, 18, "CONTINUAR", RGB(60, 130, 70)) || key_pressed(VK_SPACE_) || key_pressed(VK_RET_)) { hub_after_race(); }
}

void race_debug_start(int interactive) { if (g_scr == SC_PREP) { start_race(interactive); if (interactive) speed = 3; } }
