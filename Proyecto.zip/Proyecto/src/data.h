#ifndef DATA_H
#define DATA_H

/* Datos estaticos (generados desde las bases SQLite por tools/export_data.py) */

/* atributos (orden fijo, igual que la base de datos) */
enum {
    A_LLANO, A_MONTANA, A_MEDIA, A_DESCENSO, A_PAVES, A_CRI, A_PROLOGO,
    A_ESPRINT, A_ACEL, A_FONDO, A_RESIST, A_RECUP, A_COLINAS, A_ESCAPADA, A_COUNT
};

/* tipo de ciclista */
enum { T_RODADOR, T_ESPRINTER, T_PUNCHEUR, T_CRI, T_ESCALADOR, T_CLASICOMANO, T_VUELTOMANO, T_COUNT };

/* categoria de equipo */
enum { CAT_WT, CAT_PRO, CAT_CONTI, CAT_U23 };

/* tipo de etapa */
enum { K_LLANA, K_MEDIA, K_MONTANA, K_CRI, K_CRE, K_CLASICA };

/* categoria de carrera */
enum { TIER_GT, TIER_MONUMENTO, TIER_WT, TIER_PRO };

typedef struct {
    const char *name;
    const char *abbr;
    char country[4];
    unsigned char cat;
    unsigned char c1[3], c2[3];
} TeamDef;

typedef struct {
    const char *name;
    char country[4];
    short byear;
    unsigned char bmonth, type, level, pot;
    short wins;
    short team;              /* indice en TEAMS, -1 = agente libre */
    unsigned char a[A_COUNT];
} RiderDef;

typedef struct {
    const char *slug;
    const char *name;
    unsigned char tier, squad, slots;
    char country[4];
    unsigned char nstages;
    short stage0;
    short first_day;
} RaceDef;

typedef struct {
    short race;
    unsigned char num, kind;
    short day;               /* dia del anio (0 = 1 de enero) */
    const char *from;
    const char *to;
    float dist_km;
    short dplus;
    int pt0;                 /* indice en PT_ALT / PT_LAT / PT_LON (cada 500 m) */
    short npt;
    unsigned char est_profile, est_map;
    int surf0;
    unsigned char nsurf;
} StageDef;

typedef struct { short stage, km0_10, km1_10; unsigned char type; } SurfDef; /* 1 = adoquin, 2 = sterrato */

extern const TeamDef TEAMS[];  extern const int TEAM_COUNT;
extern const RiderDef RIDERS[]; extern const int RIDER_COUNT;
extern const RaceDef RACES[];  extern const int RACE_COUNT;
extern const StageDef STAGES[]; extern const int STAGE_COUNT;
extern const SurfDef SURFS[];  extern const int SURF_COUNT;
extern const short PT_ALT[];   extern const int PT_ALT_COUNT;
extern const float PT_LAT[];   extern const float PT_LON[];

#endif
