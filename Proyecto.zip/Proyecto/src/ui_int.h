#ifndef UI_INT_H
#define UI_INT_H
#include "gfx.h"
#include "game.h"
#include "sim.h"
#include "ui.h"

enum { SC_MENU, SC_TEAMSEL, SC_HUB, SC_PREP, SC_RACE, SC_RESULT };
extern int g_scr;

int  hit(int x, int y, int w, int h);
int  btn(int x, int y, int w, int h, const char *s, Col c);
int  btn_en(int x, int y, int w, int h, const char *s, Col c, int enabled);
void win(int x, int y, int w, int h, const char *title);
void bar(int x, int y, int w, int h, int pct, Col c);
void chip(int x, int y, int team);
Col  team_c1(int team);
Col  team_c2(int team);
int  key_pressed(int vk);
void toast(const char *fmt, ...);
Col  val_col(int v);
void draw_cyclist(int x, int y, Col c1, Col c2, int frame, int scale, int mine);

/* perfiles y mapas */
void draw_profile(int x, int y, int w, int h, const StageDef *st, const Sim *sim, int show_groups);
void draw_map(int x, int y, int w, int h, const StageDef *st, const Sim *sim);

/* carrera */
void race_enter(void);
void prep_draw(void);
void race_draw(float dt);
void result_draw(void);
void hub_after_race(void);
void race_debug_start(int interactive);

#define VK_LEFT_ 37
#define VK_UP_ 38
#define VK_RIGHT_ 39
#define VK_DOWN_ 40
#define VK_SPACE_ 32
#define VK_RET_ 13
#define VK_ESC_ 27
#define VK_TAB_ 9
#define VK_F5_ 116
#define VK_PLUS_ 187
#define VK_MINUS_ 189

#endif
