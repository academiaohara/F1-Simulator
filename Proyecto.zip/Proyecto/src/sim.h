#ifndef SIM_H
#define SIM_H
#include "game.h"

#define SIM_MAX 208
#define MAX_CLIMBS 14
#define EV_MAX 40

typedef struct {
    float km0, km1, len, grade, top_alt;
    unsigned char cat;           /* 0 = HC, 1..4 */
    unsigned char taken;
} Climb;

typedef struct {
    short run_idx, rider, team;
    unsigned char tslot, role, human, order, intens;
    unsigned char status;        /* 0 corre, 1 abandona, 2 llegado, 3 fuera de control */
    unsigned char chase, is_break, ai_pull, shelter, sprinted;
    float ai_r;
    float pos, v, energy, wp, wpmax, perf, r_now, p_now;
    float stun, feed_t, brk_t, start_off, gc_pre, finish_t, sp_at, sp_gain, atk_t;
    float stage_gain;            /* diferencia con el primero */
    short place, group, target;
    short kom_pts, pts;
    unsigned char a[A_COUNT];
    unsigned char bonk, crash_inj, brk_id;
} SimRider;

typedef struct {
    int first, n;                /* indices en order[] */
    float front, back, v;
    float gap;                   /* segundos hasta el grupo cabeza */
    int mine, leader_here;
    int has_break_riders;
} Group;

typedef struct {
    int t_sec;
    char text[88];
    unsigned char kind;          /* 0 info, 1 ataque, 2 incidente, 3 mia */
} Event;

typedef struct {
    const StageDef *st;
    const RaceDef *race;
    int stage_idx;
    float L;
    int tt, ttt, interactive, tier, n_alt;
    const short *alt;
    float gr[700];
    unsigned char surf[700];
    int n; SimRider r[SIM_MAX];
    int nteams; short tteam[MAX_RACE_T]; unsigned char tstrat[MAX_RACE_T];
    short tleader[MAX_RACE_T], tsprinter[MAX_RACE_T];
    float t, dt;
    int order[SIM_MAX]; int nact;
    int ngroups; Group grp[SIM_MAX];
    int main_group;
    Climb climbs[MAX_CLIMBS]; int nclimbs;
    float feed_km, isprint_km; int isprint_done, feed_done;
    float rain, heat, wind;
    Event ev[EV_MAX]; int nev;
    int finished, done;
    int human_sprint;            /* 1 = jugador pidio lanzar el esprint */
    float human_sprint_at;
    float attempt_km[6]; int nattempt, next_attempt;
    float think_t, think_acc;
    int break_group_gap;         /* segundos de la escapada (UI) */
    int stage_winner;
    float leader_pos;
    unsigned int rng;
    int kom_order[MAX_CLIMBS][8]; int kom_cnt[MAX_CLIMBS];
    int isp_cnt; int isp_order[8];
    int crashes, abandons;
    int team_tt_n;
    int human_team_slot;
    int brk_counter;
} Sim;

void sim_setup(Sim *s, int stage_idx, RaceRun *run, int interactive);
void sim_step(Sim *s);
void sim_run_all(Sim *s);
void sim_finalize(Sim *s, RaceRun *run);
void sim_set_order(Sim *s, int si, int order, int intens);
void sim_set_strat(Sim *s, int strat);
void sim_launch_sprint(Sim *s);
void sim_event(Sim *s, int kind, const char *fmt, ...);
float sim_grade_at(const Sim *s, float x);
float sim_alt_at(const Sim *s, float x);
int  sim_rider_group(const Sim *s, int si);
float sim_gap_to_leader(const Sim *s, int si);
const char *sim_status_name(const SimRider *r);
int  sim_leader_idx(const Sim *s);           /* corredor de cabeza */
int  sim_climb_at(const Sim *s, float pos);
void stage_climbs(const StageDef *st, Climb *out, int *n);
const char *climb_cat_name(int cat);

/* reglas de organizacion */
void assign_roles(const short *riders, int n, int kind, unsigned char *roles_out);

#endif
