#ifndef CICLISMO_SAVE_H
#define CICLISMO_SAVE_H

#include <stddef.h>
#include "game.h"

int save_game(const GameState *state, const char *path, char *error, size_t error_size);
int load_game(GameState *state, const char *path, char *error, size_t error_size);

#endif
