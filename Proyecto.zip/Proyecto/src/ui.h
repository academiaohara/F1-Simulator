#ifndef UI_H
#define UI_H
typedef struct Input {
    int mx, my, down, click, rclick, wheel;
    int keys[24]; int nk;
    int shift;
} Input;
extern Input IN;
extern char SAVE_PATH[512];
void ui_init(void);
void ui_frame(float dt);            /* dibuja en fb y procesa IN */
int  ui_wants_quit(void);
void ui_debug_goto(const char *what);
#endif
