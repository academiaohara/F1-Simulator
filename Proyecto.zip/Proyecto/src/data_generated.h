#ifndef CICLISMO_DATA_GENERATED_H
#define CICLISMO_DATA_GENERATED_H

static const GeneratedRider GENERATED_RIDERS[] = {
    {0, "Enric Mas", "Escalador", 80, 66, 73, 73, 77, 79},
    {1, "Nairo Quintana", "Escalador", 78, 57, 68, 69, 75, 74},
    {2, "Remi Cavagna", "Contrarrelojista", 65, 62, 79, 72, 69, 74},
    {3, "Einer Rubio", "Escalador", 78, 58, 65, 70, 74, 76},
    {4, "Ivan Ramiro Sosa", "Escalador", 77, 57, 60, 63, 73, 66},
    {5, "Ruben Guerreiro", "Puncheur", 75, 66, 65, 71, 76, 71},
    {6, "Alex Aranburu", "Puncheur", 69, 70, 68, 74, 77, 66},
    {7, "Antonio Pedrero", "Escalador", 76, 62, 62, 67, 73, 70},
};
static const int GENERATED_RIDER_COUNT = sizeof(GENERATED_RIDERS) / sizeof(GENERATED_RIDERS[0]);

static const GeneratedStage GENERATED_STAGES[] = {
    {"Tour de France", "Barcelona", "Barcelona", "CRE", 19.6f, 167, 12, {13, 10, 14, 11, 10, 22, 34, 58, 61, 54, 47, 88}},
    {"Tour de France", "Tarragona", "Barcelona", "media montana", 168.5f, 2049, 12, {12, 10, 20, 10, 13, 13, 10, 88, 85, 14, 12, 35}},
    {"Tour de France", "Pau", "Gavarnie-Gedre", "montana", 186.2f, 4149, 12, {10, 13, 19, 22, 30, 28, 35, 46, 62, 78, 88, 46}},
    {"Tour de France", "Hagetmau", "Bordeaux", "llana", 175.1f, 701, 12, {88, 32, 32, 48, 63, 66, 55, 42, 54, 18, 63, 10}},
    {"Tour de France", "Perigueux", "Bergerac", "llana", 180.4f, 1353, 12, {50, 88, 83, 29, 44, 50, 64, 27, 28, 21, 11, 10}},
    {"Tour de France", "Malemort", "Ussel", "media montana", 154.6f, 2792, 12, {15, 10, 36, 39, 36, 38, 49, 71, 52, 73, 88, 71}},
    {"Tour de France", "Aurillac", "Le Lioran", "media montana", 165.6f, 3791, 12, {10, 12, 27, 33, 32, 55, 43, 83, 41, 57, 88, 69}},
    {"Tour de France", "Vichy", "Nevers", "llana", 161.3f, 1107, 12, {56, 48, 42, 46, 19, 57, 27, 10, 35, 88, 84, 15}},
    {"Tour de France", "Circuit Nevers Magny-Cours", "Chalon-sur-Saone", "llana", 179.1f, 1412, 12, {28, 29, 35, 10, 13, 24, 48, 53, 72, 50, 88, 85}},
    {"Tour de France", "Dole", "Belfort", "media montana", 205.8f, 2309, 12, {10, 11, 13, 10, 17, 19, 23, 20, 27, 46, 88, 69}},
    {"Tour de France", "Mulhouse", "Le Markstein", "montana", 155.3f, 3941, 12, {10, 17, 62, 88, 64, 44, 43, 64, 41, 23, 25, 49}},
    {"Tour de France", "Champagnole", "Plateau de Solaison", "montana", 183.9f, 4098, 12, {25, 50, 41, 88, 60, 27, 14, 10, 28, 70, 47, 16}},
};
static const int GENERATED_STAGE_COUNT = sizeof(GENERATED_STAGES) / sizeof(GENERATED_STAGES[0]);

#endif
