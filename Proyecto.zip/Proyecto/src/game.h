#ifndef GAME_H
#define GAME_H

#include "data.h"

#define MAX_RIDERS   4096
#define MAX_TEAMS    224
#define MAX_RACE_T   26
#define MAX_RUN_R    208
#define MAX_RUNS     4
#define MAX_MSGS     64
#define MAX_SQUAD    8
#define SAVE_VERSION 3

enum { ROLE_LIBRE, ROLE_LIDER, ROLE_ESPRINTER, ROLE_LANZADOR, ROLE_GREGARIO, ROLE_RODADOR, ROLE_ESCAPADISTA, ROLE_COUNT };
enum { ORD_AUTO, ORD_ATACAR, ORD_ESCAPADA, ORD_TIRAR, ORD_PROTEGER, ORD_AVITUALLAR, ORD_RECUPERAR, ORD_COUNT };
enum { STR_AUTO, STR_CONTROL, STR_ESPRINT, STR_GENERAL, STR_ESCAPADA, STR_CONSERVAR, STR_COUNT };
enum { STAFF_ENTRENADOR, STAFF_MEDICO, STAFF_NUTRI, STAFF_MECANICO, STAFF_SCOUT, STAFF_DS, STAFF_COUNT };
enum { TR_LIGERO, TR_FONDO, TR_MONTANA, TR_SPRINT, TR_CRI, TR_PUNCH, TR_DESCANSO, TR_COUNT };
enum { PS_NONE, PS_OPCIONAL, PS_SOLICITABLE, PS_SOLICITADA, PS_INVITADA, PS_RECHAZADA, PS_OBLIGATORIA, PS_INSCRITA, PS_RENUNCIA, PS_CERRADA };
enum { PROM_NONE, PROM_GRANVUELTA, PROM_LIDER, PROM_DIAS };
enum { MSG_INFO, MSG_RIDER, MSG_BOARD, MSG_RACE, MSG_MARKET };

typedef struct { unsigned char kind; short deadline; short value; unsigned char done; } Promise;

typedef struct {
    char name[34];
    char country[4];
    short byear;
    unsigned char bmonth, retired;
    short team;                   /* -1 libre */
    unsigned char a[A_COUNT];
    unsigned char level, pot, type, role_pref;
    unsigned char rep, happy, form, fatigue, train, wants_leader;
    short inj_days;
    int   salary;                 /* EUR / anio */
    short contract_end;           /* anio en el que termina */
    int   value;
    short race_days;
    short wins, podiums;
    unsigned short pts;
    unsigned short pts_last;      /* temporada anterior */
    unsigned char seen;           /* scouting (0..100) */
    unsigned char shortlist;
    Promise prom[2];
    short offer_team;             /* equipo con el que negociamos */
    unsigned char refusals;
    unsigned char raced_today;
} Rider;

typedef struct {
    short def;
    unsigned char cat, rep, board;       /* board = confianza de la directiva 0..100 */
    long long cash;
    int  sponsor;                        /* ingresos anuales de patrocinio */
    unsigned char staff[STAFF_COUNT];
    unsigned int  pts, pts_last;
    short wins;
    int  spent_year, earned_year, prize_year;
    unsigned char want_riders;
} Team;

typedef struct {
    unsigned char kind, unread;
    short day, rider;
    char title[56];
    char body[200];
} Msg;

typedef struct {
    unsigned char n;
    short team[MAX_RACE_T];
    unsigned char pstatus;
    unsigned char requested;
    short rank_est;               /* posicion estimada de invitacion */
    short squad[MAX_SQUAD];
    unsigned char squad_role[MAX_SQUAD];
    unsigned char squad_n;
    unsigned char strat;
    unsigned char done;
    short winner_rider;
    short player_best;
    short inv_slots, cutscore, pscore;
    unsigned char auto_n;
} RaceEntry;

typedef struct {
    short rider;                  /* indice global */
    unsigned char tslot, role, human, abandoned;
    unsigned char order, intens;
    float gc;                     /* segundos acumulados */
    short pts, kom;
    short stage_pos;
    float stage_time;
    short best_pos;
} RunRider;

typedef struct {
    unsigned char active;
    short race;
    short stage;                  /* indice global de etapa en curso/siguiente */
    short stages_done;
    unsigned char focus;          /* 1 = carrera interactiva del jugador */
    unsigned char nteams;
    short team[MAX_RACE_T];
    unsigned char strat[MAX_RACE_T];
    short nr;
    RunRider r[MAX_RUN_R];
    short last_winner[24];
} RaceRun;

typedef struct {
    int version;
    int year, day;
    int player;
    unsigned int rng;
    Rider riders[MAX_RIDERS]; int nriders;
    Team  teams[MAX_TEAMS];   int nteams;
    RaceEntry entry[32];
    RaceRun runs[MAX_RUNS];
    Msg  inbox[MAX_MSGS]; int nmsg;
    char news[6][96]; int nnews;
    int  season_obj_rank, season_obj_wins;
    int  scout_pending;
    int  ai_tick;
} Game;

extern Game G;

/* utilidades */
unsigned int rnd(void);
float frnd(void);                 /* 0..1 */
float frange(float a, float b);
int   irange(int a, int b);
unsigned int hash32(unsigned int x);
const char *day_str(int day);          /* "12 mar" */
const char *money_str(long long v);    /* "1,2 M" */
int   age_of(const Rider *r);
const char *role_name(int r);
const char *role_short(int r);
const char *order_name(int o);
const char *strat_name(int s);
const char *kind_name(int k);
const char *cat_name(int c);
const char *tier_name(int t);
const char *type_name(int t);
const char *attr_name(int a);
const char *staff_name(int s);
const char *train_name(int s);
const char *country_name(const char *code);
const char *day_long(int day);
int   rider_ovr(const Rider *r);            /* nivel visible */
int   rider_gc_score(const Rider *r);
int   rider_sprint_score(const Rider *r);
int   rider_climb_score(const Rider *r);
int   rider_flat_score(const Rider *r);
int   rider_break_score(const Rider *r);
int   rider_classic_score(const Rider *r);
int   rider_tt_score(const Rider *r);
const char *rider_name(int i);

/* gestion */
void  game_new(int team);
void  game_start_season(void);
void  game_advance_day(void);            /* avanza un dia (sin carreras interactivas) */
int   team_roster(int t, short *out, int max);
int   team_payroll(int t);
int   team_size(int t);
int   team_ovr(int t);
long long team_budget_left(int t);
int   wage_cap(int t);
void  msg_add(int kind, int rider, const char *title, const char *fmt, ...);
void  news_add(const char *fmt, ...);
int   race_next_day(int race);           /* proximo dia de etapa >= hoy, o -1 */
int   race_last_day(int race);
int   race_cut_day(int race);            /* dia limite de inscripcion */
int   player_can_enter(int race, char *why, int whylen);
int   invite_score(int team, int race);
void  race_update_status(int race);
void  race_request_invite(int race);
void  race_withdraw(int race);
int   squad_valid(int race, char *why, int whylen);
void  squad_auto(int race);
int   rider_available(int ri, int race);
int   today_races(int *list, int max);  /* carreras con etapa hoy donde el jugador participa */
int   player_has_race_today(void);
void  race_prepare_all_today(void);
void  contract_expected_salary(const Rider *r, int team, int role, int years, int *ask);
int   offer_evaluate(int ri, int team, int salary, int years, int role, int fee, char *msg, int msglen, int commit);
int   rider_value(const Rider *r);
void  rider_release(int ri);
int   sign_cost_check(int ri, int salary, int fee);
int   staff_upgrade_cost(int s, int lvl);
void  staff_upgrade(int s);
void  rider_set_train(int ri, int tr);
void  scout_reveal(void);
int   rider_attr_seen(const Rider *r, int attr, int viewer);
int   promise_add(int ri, int kind, int value);
void  season_end(void);
int   player_rank(void);
int   team_rank_by_pts(int t);
void  prize_award(int team, int rider, int euros);
void  game_apply_race_result(int race, int stage_idx, int final_stage);
RaceRun *game_race_run(int race, int create);
void game_run_stage_headless(RaceRun *run);
void assign_ai_strats(RaceRun *run, int stage_idx);
void game_prepare_stage(RaceRun *run);
void game_finish_interactive(void *sim, RaceRun *run);
int   run_gc_sorted(RaceRun *run, short *out);

/* guardado */
int save_game(const char *path);
int load_game(const char *path);

#endif
