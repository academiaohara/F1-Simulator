#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#undef RGB
#undef IN
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "gfx.h"
#include "ui.h"

static HWND g_hwnd;
static BITMAPINFO g_bmi;
static int g_cw = 1280, g_ch = 720;
static int g_scale = 2, g_ox = 0, g_oy = 0;
static int g_fullscreen = 0;
static WINDOWPLACEMENT g_wp = { sizeof(WINDOWPLACEMENT) };
static int g_wheel = 0;
static int g_keys[24], g_nk = 0;

static void push_key(int vk) { if (g_nk < 24) g_keys[g_nk++] = vk; }

static void toggle_fullscreen(void) {
    DWORD style = GetWindowLong(g_hwnd, GWL_STYLE);
    if (!g_fullscreen) {
        MONITORINFO mi = { sizeof(mi) };
        if (GetWindowPlacement(g_hwnd, &g_wp) && GetMonitorInfo(MonitorFromWindow(g_hwnd, MONITOR_DEFAULTTOPRIMARY), &mi)) {
            SetWindowLong(g_hwnd, GWL_STYLE, style & ~WS_OVERLAPPEDWINDOW);
            SetWindowPos(g_hwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left, mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
            g_fullscreen = 1;
        }
    } else {
        SetWindowLong(g_hwnd, GWL_STYLE, style | WS_OVERLAPPEDWINDOW);
        SetWindowPlacement(g_hwnd, &g_wp);
        SetWindowPos(g_hwnd, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
        g_fullscreen = 0;
    }
}

static LRESULT CALLBACK wndproc(HWND h, UINT m, WPARAM w, LPARAM l) {
    switch (m) {
        case WM_SIZE: g_cw = LOWORD(l); g_ch = HIWORD(l); return 0;
        case WM_MOUSEWHEEL: g_wheel += GET_WHEEL_DELTA_WPARAM(w) / 120; return 0;
        case WM_KEYDOWN:
            if (w == VK_F11) { toggle_fullscreen(); return 0; }
            if (w == VK_ESCAPE && g_fullscreen) { toggle_fullscreen(); return 0; }
            if (!(l & 0x40000000) || w == VK_UP || w == VK_DOWN || w == VK_LEFT || w == VK_RIGHT) push_key((int)w);
            return 0;
        case WM_SYSKEYDOWN: if (w == VK_RETURN) { toggle_fullscreen(); return 0; } break;
        case WM_CLOSE: DestroyWindow(h); return 0;
        case WM_DESTROY: PostQuitMessage(0); return 0;
        case WM_ERASEBKGND: return 1;
    }
    return DefWindowProcA(h, m, w, l);
}

static void present(HDC dc) {
    int sc = g_cw / SW; int s2 = g_ch / SH; if (s2 < sc) sc = s2; if (sc < 1) sc = 1;
    g_scale = sc;
    int dw = SW * sc, dh = SH * sc;
    g_ox = (g_cw - dw) / 2; g_oy = (g_ch - dh) / 2;
    if (g_ox < 0) g_ox = 0;
    if (g_oy < 0) g_oy = 0;
    if (g_ox > 0 || g_oy > 0) {
        HBRUSH b = (HBRUSH)GetStockObject(BLACK_BRUSH);
        RECT r1 = { 0, 0, g_cw, g_oy }, r2 = { 0, g_oy + dh, g_cw, g_ch }, r3 = { 0, g_oy, g_ox, g_oy + dh }, r4 = { g_ox + dw, g_oy, g_cw, g_oy + dh };
        FillRect(dc, &r1, b); FillRect(dc, &r2, b); FillRect(dc, &r3, b); FillRect(dc, &r4, b);
    }
    SetStretchBltMode(dc, COLORONCOLOR);
    StretchDIBits(dc, g_ox, g_oy, dw, dh, 0, 0, SW, SH, fb, &g_bmi, DIB_RGB_COLORS, SRCCOPY);
}

static void init_paths(void) {
    char p[MAX_PATH]; GetModuleFileNameA(NULL, p, MAX_PATH);
    char *sl = strrchr(p, '\\');
    if (sl) { sl[1] = 0; snprintf(SAVE_PATH, sizeof SAVE_PATH, "%spartida.sav", p); }
}

static int shot_mode(const char *cmd) {
    /* --shot salida.png escenario [frames] */
    char out[260] = "shot.png", what[64] = "menu"; int frames = 3;
    sscanf(cmd, "%259s %63s %d", out, what, &frames);
    gfx_init(); ui_init();
    ui_debug_goto(what);
    memset(&IN, 0, sizeof IN); IN.mx = -10; IN.my = -10;
    for (int f = 0; f < frames; f++) { IN.nk = 0; ui_frame(0.05f); }
    png_save(out, 2);
    return 0;
}

static int fuzz_mode(int frames) {
    static const char *sc[] = { "hub1", "hub2", "hub3", "hub4", "hub5", "hub6", "prep", "race", "hub0", "neg", "squadm", "result" };
    static const int keys[] = { 32, 13, 38, 40, 37, 39, 'A', 'E', 'T', 'P', 'B', 'R', 'X', 'Z', '1', '2', '3', 9 };
    unsigned int rs = 12345;
    gfx_init(); ui_init();
    int per = frames / 12; if (per < 50) per = 50;
    for (int f = 0; f < frames; f++) {
        if (f % per == 0) { ui_debug_goto(sc[(f / per) % 12]); }
        rs = rs * 1664525u + 1013904223u;
        memset(&IN, 0, sizeof IN);
        IN.mx = (int)((rs >> 8) % SW); IN.my = (int)((rs >> 20) % SH);
        IN.click = ((rs >> 4) & 7) == 0; IN.down = IN.click;
        IN.wheel = (int)((rs >> 12) % 5) - 2;
        if (((rs >> 6) & 3) == 0) { IN.keys[0] = keys[(rs >> 16) % 18]; IN.nk = 1; }
        ui_frame(0.05f);
    }
    printf("fuzz ok %d frames\n", frames);
    return 0;
}

int WINAPI WinMain(HINSTANCE inst, HINSTANCE prev, LPSTR cmd, int show) {
    (void)prev;
    init_paths();
    if (cmd && strstr(cmd, "--fuzz")) { AttachConsole(ATTACH_PARENT_PROCESS); freopen("CONOUT$", "w", stdout); return fuzz_mode(atoi(strstr(cmd, "--fuzz") + 7)); }
    if (cmd && strstr(cmd, "--shot")) return shot_mode(strstr(cmd, "--shot") + 7);
    WNDCLASSA wc = { 0 };
    wc.lpfnWndProc = wndproc; wc.hInstance = inst; wc.lpszClassName = "CiclismoMgr"; wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    RegisterClassA(&wc);
    RECT r = { 0, 0, 1280, 720 }; AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
    g_hwnd = CreateWindowA("CiclismoMgr", "Ciclismo Manager", WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, r.right - r.left, r.bottom - r.top, NULL, NULL, inst, NULL);
    ShowWindow(g_hwnd, show);
    memset(&g_bmi, 0, sizeof g_bmi);
    g_bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER); g_bmi.bmiHeader.biWidth = SW; g_bmi.bmiHeader.biHeight = -SH;
    g_bmi.bmiHeader.biPlanes = 1; g_bmi.bmiHeader.biBitCount = 32; g_bmi.bmiHeader.biCompression = BI_RGB;
    gfx_init(); ui_init();
    LARGE_INTEGER fq, t0; QueryPerformanceFrequency(&fq); QueryPerformanceCounter(&t0);
    int running = 1, prev_down = 0, prev_r = 0;
    while (running) {
        MSG msg;
        while (PeekMessageA(&msg, NULL, 0, 0, PM_REMOVE)) { if (msg.message == WM_QUIT) running = 0; TranslateMessage(&msg); DispatchMessageA(&msg); }
        if (!running) break;
        LARGE_INTEGER t1; QueryPerformanceCounter(&t1);
        float dt = (float)(t1.QuadPart - t0.QuadPart) / fq.QuadPart; t0 = t1; if (dt > 0.1f) dt = 0.1f;
        POINT p; GetCursorPos(&p); ScreenToClient(g_hwnd, &p);
        IN.mx = (p.x - g_ox) / g_scale; IN.my = (p.y - g_oy) / g_scale;
        if (p.x < g_ox || p.y < g_oy) { IN.mx = -10; IN.my = -10; }
        int fg = GetForegroundWindow() == g_hwnd;
        int down = (GetKeyState(VK_LBUTTON) & 0x8000) != 0 && fg;
        int rd = (GetKeyState(VK_RBUTTON) & 0x8000) != 0 && fg;
        IN.click = down && !prev_down; IN.rclick = rd && !prev_r; IN.down = down; prev_down = down; prev_r = rd;
        IN.wheel = g_wheel; g_wheel = 0;
        IN.nk = g_nk; memcpy(IN.keys, g_keys, sizeof(int) * g_nk); g_nk = 0;
        IN.shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
        ui_frame(dt);
        HDC dc = GetDC(g_hwnd); present(dc); ReleaseDC(g_hwnd, dc);
        if (ui_wants_quit()) PostMessage(g_hwnd, WM_CLOSE, 0, 0);
        Sleep(8);
    }
    return 0;
}
