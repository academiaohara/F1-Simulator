/* Gestion: mundo, calendario, invitaciones, contratos, finanzas, IA de mercado. */
#include "game.h"
#include "sim.h"
#include <math.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

Game G;

/* ---------------------------------------------------------------- utilidades */
unsigned int rnd(void) { G.rng = G.rng * 1664525u + 1013904223u; return G.rng >> 4; }
float frnd(void) { return (float)(rnd() & 0xFFFFF) / 1048576.0f; }
float frange(float a, float b) { return a + (b - a) * frnd(); }
int irange(int a, int b) { if (b <= a) return a; return a + (int)(rnd() % (unsigned)(b - a + 1)); }
unsigned int hash32(unsigned int x) { x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x; }
static int clampi(int v, int a, int b) { return v < a ? a : (v > b ? b : v); }

static const int MDAYS[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
static const char *MON3[12] = { "ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic" };
static const char *MONL[12] = { "enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre" };
const char *day_str(int day) {
    static char buf[4][16]; static int k = 0; k = (k + 1) & 3;
    int m = 0; day = clampi(day, 0, 364);
    while (m < 11 && day >= MDAYS[m]) { day -= MDAYS[m]; m++; }
    snprintf(buf[k], 16, "%d %s", day + 1, MON3[m]);
    return buf[k];
}
const char *day_long(int day) {
    static char buf[4][40]; static int k = 0; k = (k + 1) & 3;
    int m = 0; day = clampi(day, 0, 364);
    int d0 = day;
    while (m < 11 && day >= MDAYS[m]) { day -= MDAYS[m]; m++; }
    static const char *WD[7] = { "jue","vie","sáb","dom","lun","mar","mié" };  /* 1 ene 2026 = jueves */
    snprintf(buf[k], 40, "%s %d %s", WD[(d0 + (G.year - 2026) * 365) % 7], day + 1, MON3[m]);
    return buf[k];
}
const char *money_str(long long v) {
    static char buf[8][24]; static int k = 0; k = (k + 1) & 7;
    long long a = v < 0 ? -v : v;
    const char *sg = v < 0 ? "-" : "";
    if (a >= 1000000) snprintf(buf[k], 24, "%s%.2f M\x09", sg, a / 1e6);
    else if (a >= 10000) snprintf(buf[k], 24, "%s%d k\x09", sg, (int)(a / 1000));
    else snprintf(buf[k], 24, "%s%d \x09", sg, (int)a);
    return buf[k];
}
int age_of(const Rider *r) { return G.year - r->byear; }

const char *role_name(int r) { static const char *n[] = { "Libre","Líder","Esprínter","Lanzador","Gregario","Rodador","Escapadista" }; return n[r % ROLE_COUNT]; }
const char *role_short(int r) { static const char *n[] = { "LIB","LID","ESP","LAN","GRE","ROD","ESC" }; return n[r % ROLE_COUNT]; }
const char *order_name(int o) { static const char *n[] = { "Auto","Atacar","Escapada","Tirar","Proteger","Bidones","Ahorrar" }; return n[o % ORD_COUNT]; }
const char *strat_name(int s) { static const char *n[] = { "Automática","Controlar la carrera","Esprint masivo","Ir a por la general","Cazar etapa (escapada)","Conservar fuerzas" }; return n[s % STR_COUNT]; }
const char *kind_name(int k) { static const char *n[] = { "Llana","Media montaña","Montaña","Contrarreloj","CRE equipos","Clásica" }; return n[k % 6]; }
const char *cat_name(int c) { static const char *n[] = { "WorldTour","ProTeam","Continental","Sub-23" }; return n[c & 3]; }
const char *tier_name(int t) { static const char *n[] = { "Gran Vuelta","Monumento","WorldTour","ProSeries" }; return n[t & 3]; }
const char *type_name(int t) { static const char *n[] = { "Rodador","Esprínter","Puncheur","Contrarrelojista","Escalador","Clasicómano","Vueltómano" }; return n[t % T_COUNT]; }
const char *attr_name(int a) { static const char *n[] = { "Llano","Montaña","Media montaña","Descenso","Pavés","Contrarreloj","Prólogo","Esprint","Aceleración","Fondo","Resistencia","Recuperación","Colinas","Escapada" }; return n[a % A_COUNT]; }
const char *staff_name(int s) { static const char *n[] = { "Entrenador","Médico","Nutricionista","Mecánicos","Ojeador","Director deportivo" }; return n[s % STAFF_COUNT]; }
const char *train_name(int s) { static const char *n[] = { "Ligero","Fondo","Montaña","Esprint","Contrarreloj","Punch/Colinas","Descanso" }; return n[s % TR_COUNT]; }
const char *country_name(const char *c) {
    static const struct { const char *c, *n; } T[] = {
        {"ESP","España"},{"FRA","Francia"},{"ITA","Italia"},{"BEL","Bélgica"},{"NED","P. Bajos"},{"GER","Alemania"},{"GBR","R. Unido"},
        {"USA","EE.UU."},{"AUS","Australia"},{"COL","Colombia"},{"SLO","Eslovenia"},{"DEN","Dinamarca"},{"SUI","Suiza"},{"NOR","Noruega"},
        {"POR","Portugal"},{"POL","Polonia"},{"ECU","Ecuador"},{"AUT","Austria"},{"KAZ","Kazajistán"},{"CZE","Chequia"},{"CAN","Canadá"},
        {"UAE","Emiratos"},{"BHR","Baréin"},{"NZL","N. Zelanda"},{"IRL","Irlanda"},{"LUX","Luxemburgo"},{"RSA","Sudáfrica"},{"ERI","Eritrea"} };
    for (int i = 0; i < (int)(sizeof T / sizeof T[0]); i++) if (!strcmp(T[i].c, c)) return T[i].n;
    return c;
}

const char *rider_name(int i) { return G.riders[i].name; }

/* ---------------------------------------------------------------- puntuaciones */
int rider_ovr(const Rider *r) {
    int v[9] = { r->a[A_LLANO], r->a[A_MONTANA], r->a[A_MEDIA], r->a[A_PAVES], r->a[A_CRI], r->a[A_ESPRINT], r->a[A_COLINAS], r->a[A_FONDO], r->a[A_RESIST] };
    for (int i = 0; i < 9; i++) for (int j = i + 1; j < 9; j++) if (v[j] > v[i]) { int t = v[i]; v[i] = v[j]; v[j] = t; }
    return (v[0] + v[1] + v[2] + 1) / 3;
}
int rider_gc_score(const Rider *r) { return (int)(r->a[A_MONTANA] * 0.34f + r->a[A_MEDIA] * 0.12f + r->a[A_CRI] * 0.18f + r->a[A_FONDO] * 0.14f + r->a[A_RESIST] * 0.12f + r->a[A_RECUP] * 0.10f); }
int rider_sprint_score(const Rider *r) { return (int)(r->a[A_ESPRINT] * 0.6f + r->a[A_ACEL] * 0.3f + r->a[A_LLANO] * 0.1f); }
int rider_climb_score(const Rider *r) { return (int)(r->a[A_MONTANA] * 0.5f + r->a[A_MEDIA] * 0.3f + r->a[A_COLINAS] * 0.2f); }
int rider_flat_score(const Rider *r) { return (int)(r->a[A_LLANO] * 0.6f + r->a[A_FONDO] * 0.2f + r->a[A_CRI] * 0.2f); }
int rider_break_score(const Rider *r) { return (int)(r->a[A_ESCAPADA] * 0.5f + r->a[A_FONDO] * 0.25f + r->a[A_LLANO] * 0.15f + r->a[A_ACEL] * 0.1f); }
int rider_classic_score(const Rider *r) { return (int)(r->a[A_PAVES] * 0.25f + r->a[A_COLINAS] * 0.25f + r->a[A_LLANO] * 0.2f + r->a[A_ACEL] * 0.15f + r->a[A_FONDO] * 0.15f); }
int rider_tt_score(const Rider *r) { return r->a[A_CRI]; }

/* ---------------------------------------------------------------- mensajes */
void msg_add(int kind, int rider, const char *title, const char *fmt, ...) {
    if (G.nmsg >= MAX_MSGS) G.nmsg = MAX_MSGS - 1;
    memmove(&G.inbox[1], &G.inbox[0], sizeof(Msg) * G.nmsg);
    Msg *m = &G.inbox[0]; memset(m, 0, sizeof *m);
    m->kind = (unsigned char)kind; m->rider = (short)rider; m->day = (short)G.day; m->unread = 1;
    snprintf(m->title, sizeof m->title, "%s", title);
    va_list ap; va_start(ap, fmt); vsnprintf(m->body, sizeof m->body, fmt, ap); va_end(ap);
    G.nmsg++;
}
void news_add(const char *fmt, ...) {
    if (G.nnews >= 6) { memmove(G.news[0], G.news[1], 96 * 5); G.nnews = 5; }
    va_list ap; va_start(ap, fmt); vsnprintf(G.news[G.nnews++], 96, fmt, ap); va_end(ap);
}

/* ---------------------------------------------------------------- valores, salarios */
int rider_value(const Rider *r) {
    int ovr = rider_ovr(r);
    double v = 110000.0 * exp((ovr - 58) * 0.19);
    int age = age_of(r);
    if (age <= 25 && r->pot > ovr) v *= 1.0 + (r->pot - ovr) * 0.045;
    if (age >= 31) v *= 1.0 - (age - 30) * 0.07;
    if (age >= 35) v *= 0.5;
    if (v < 15000) v = 15000;
    return (int)(v / 1000) * 1000;
}
static int salary_for_value(int v, int rep) {
    double s = v * 0.30 + rep * 600.0;
    if (s < 40000) s = 40000;
    if (s > 6500000) s = 6500000;
    return ((int)s / 5000) * 5000;
}
void contract_expected_salary(const Rider *r, int team, int role, int years, int *ask) {
    int v = rider_value(r);
    double s = salary_for_value(v, r->rep);
    if (team >= 0) {
        double rd = G.teams[team].rep - r->rep;   /* equipos mas prestigiosos pagan menos exigencia */
        if (rd > 0) s *= 1.0 - fminf(0.15f, (float)rd * 0.004f);
        else s *= 1.0 + fminf(0.45f, (float)(-rd) * 0.012f);
    }
    if (role == ROLE_LIDER) s *= 1.05;
    if (role == ROLE_GREGARIO || role == ROLE_RODADOR) s *= 0.97;
    if (years >= 3) s *= 1.06;
    if (age_of(r) >= 32 && years >= 3) s *= 1.08;
    if (r->happy < 45) s *= 1.1;
    *ask = ((int)s / 5000) * 5000;
    if (*ask < 40000) *ask = 40000;
}

/* ---------------------------------------------------------------- equipos */
int team_roster(int t, short *out, int max) {
    int n = 0;
    for (int i = 0; i < G.nriders && n < max; i++) if (G.riders[i].team == t && !G.riders[i].retired) out[n++] = (short)i;
    return n;
}
int team_size(int t) { int n = 0; for (int i = 0; i < G.nriders; i++) if (G.riders[i].team == t && !G.riders[i].retired) n++; return n; }
int team_payroll(int t) { long long s = 0; for (int i = 0; i < G.nriders; i++) if (G.riders[i].team == t && !G.riders[i].retired) s += G.riders[i].salary; return (int)s; }
static int staff_cost_level(int lvl) { return lvl * 55000; }
static int team_staff_cost(int t) { int c = 0; for (int s = 0; s < STAFF_COUNT; s++) c += staff_cost_level(G.teams[t].staff[s]); return c; }
int staff_upgrade_cost(int s, int lvl) { (void)s; return 80000 + lvl * 120000; }
int wage_cap(int t) { return (int)(G.teams[t].sponsor * 0.80) - team_staff_cost(t); }
long long team_budget_left(int t) { return (long long)wage_cap(t) - team_payroll(t); }
int team_ovr(int t) {
    short r[40]; int n = team_roster(t, r, 40); int v[40];
    for (int i = 0; i < n; i++) v[i] = rider_ovr(&G.riders[r[i]]);
    for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) if (v[j] > v[i]) { int tmp = v[i]; v[i] = v[j]; v[j] = tmp; }
    int s = 0, k = n < 12 ? n : 12;
    for (int i = 0; i < k; i++) s += v[i];
    return k ? s / k : 40;
}
static int max_roster(int cat) { return cat == CAT_WT || cat == CAT_PRO ? 30 : (cat == CAT_CONTI ? 20 : 18); }
static int min_roster(int cat) { return cat == CAT_WT ? 24 : (cat == CAT_PRO ? 20 : (cat == CAT_CONTI ? 12 : 10)); }

/* ---------------------------------------------------------------- mundo nuevo */
static void init_rider(int i, const RiderDef *d) {
    Rider *r = &G.riders[i]; memset(r, 0, sizeof *r);
    snprintf(r->name, sizeof r->name, "%s", d->name);
    memcpy(r->country, d->country, 4);
    r->byear = d->byear; r->bmonth = d->bmonth;
    r->team = d->team;
    memcpy(r->a, d->a, A_COUNT);
    r->level = d->level; r->pot = d->pot; r->type = d->type;
    unsigned h = hash32((unsigned)i * 2654435761u + 7);
    int ovr = rider_ovr(r); r->level = (unsigned char)ovr;
    r->rep = (unsigned char)clampi((int)((ovr - 46) * 2.3f + (d->wins > 60 ? 20 : d->wins / 3)), 3, 99);
    r->happy = (unsigned char)(66 + h % 22);
    r->form = (unsigned char)(60 + (h >> 8) % 18);
    r->fatigue = 0; r->train = TR_LIGERO;
    r->wins = d->wins; r->seen = (unsigned char)(24 + (h >> 16) % 20);
    r->value = rider_value(r);
    if (d->team >= 0) {
        r->salary = salary_for_value(r->value, r->rep);
        r->contract_end = (short)(2026 + (h >> 4) % 4);
        if (age_of(r) >= 34 && r->contract_end > 2027) r->contract_end = 2027;
    }
    r->role_pref = ROLE_LIBRE;
    if (d->type == T_ESPRINTER) r->role_pref = ROLE_ESPRINTER;
    else if (d->type == T_ESCALADOR || d->type == T_VUELTOMANO) r->role_pref = ovr >= 72 ? ROLE_LIDER : ROLE_GREGARIO;
    else if (d->type == T_RODADOR) r->role_pref = ROLE_RODADOR;
    r->wants_leader = (unsigned char)(ovr >= 76 || r->rep > 70);
}

static void team_finances_init(int t) {
    Team *tm = &G.teams[t];
    int pay = team_payroll(t);
    static const int base[4] = { 2000000, 1000000, 350000, 150000 };
    tm->sponsor = (int)(pay * 1.30 + base[tm->cat] + (tm->rep - 50) * 20000);
    if (tm->sponsor < 120000) tm->sponsor = 120000;
    tm->cash = (long long)(tm->sponsor * (tm->cat == CAT_WT ? 0.20 : 0.15));
    static const unsigned char st[4][STAFF_COUNT] = { {3,3,3,3,2,3}, {2,2,2,2,2,2}, {1,1,1,1,1,1}, {1,1,1,1,0,1} };
    for (int s = 0; s < STAFF_COUNT; s++) tm->staff[s] = (unsigned char)clampi(st[tm->cat][s] + (tm->rep > 85 ? 1 : 0), 0, 5);
    tm->board = 65;
}

void game_new(int team) {
    unsigned int seed = (unsigned)time(NULL) ^ 0x9E3779B9u;
    memset(&G, 0, sizeof G);
    G.rng = seed;
    G.version = SAVE_VERSION; G.year = 2026; G.day = 0; G.player = team;
    G.nteams = TEAM_COUNT; G.nriders = RIDER_COUNT;
    for (int i = 0; i < RIDER_COUNT; i++) init_rider(i, &RIDERS[i]);
    for (int t = 0; t < TEAM_COUNT; t++) {
        Team *tm = &G.teams[t]; tm->def = (short)t; tm->cat = TEAMS[t].cat;
        short rs[40]; int n = team_roster(t, rs, 40);
        int v[40]; for (int i = 0; i < n; i++) v[i] = rider_ovr(&G.riders[rs[i]]);
        for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) if (v[j] > v[i]) { int tmp = v[i]; v[i] = v[j]; v[j] = tmp; }
        int k = n < 14 ? n : 14; float avg = 55; if (k) { int s = 0; for (int i = 0; i < k; i++) s += v[i]; avg = (float)s / k; }
        static const int cb[4] = { 62, 46, 31, 20 };
        tm->rep = (unsigned char)clampi(cb[tm->cat] + (int)((avg - 60) * 1.6f), 8, 98);
    }
    for (int t = 0; t < TEAM_COUNT; t++) team_finances_init(t);
    game_start_season();
    Team *p = &G.teams[team];
    msg_add(MSG_BOARD, -1, "Bienvenido, director", "La directiva de %s confía en ti. Revisa la plantilla, gestiona contratos y elige bien dónde competir. ¡Suerte!", TEAMS[team].name);
    const char *obj = p->cat == CAT_WT ? "terminar en el top 9 del ranking de equipos" : (p->cat == CAT_PRO ? "ser invitado a una Gran Vuelta y puntuar" : "ganar carreras y subir tu reputación");
    msg_add(MSG_BOARD, -1, "Objetivo de la temporada", "La directiva espera: %s. Presupuesto salarial máximo: %s.", obj, money_str(wage_cap(team)));
}

/* ---------------------------------------------------------------- calendario */
int race_last_day(int race) { const RaceDef *r = &RACES[race]; return STAGES[r->stage0 + r->nstages - 1].day; }
int race_next_day(int race) {
    const RaceDef *r = &RACES[race];
    for (int i = 0; i < r->nstages; i++) if (STAGES[r->stage0 + i].day >= G.day) return STAGES[r->stage0 + i].day;
    return -1;
}
int race_cut_day(int race) { return RACES[race].first_day - 21; }

static int race_main_kind(int race) {
    const RaceDef *rd = &RACES[race];
    int cm = 0, cmed = 0, ccl = 0;
    for (int i = 0; i < rd->nstages; i++) { int k = STAGES[rd->stage0 + i].kind; if (k == K_MONTANA) cm++; else if (k == K_MEDIA) cmed++; else if (k == K_CLASICA) ccl++; }
    if (ccl) return K_CLASICA;
    if (cm >= 2 || (rd->tier == TIER_GT)) return K_MONTANA;
    if (cm + cmed >= 2) return K_MEDIA;
    return K_LLANA;
}

static int cat_eligible(int tier, int cat, int home) {
    if (cat == CAT_WT || cat == CAT_PRO) return 1;
    if (tier == TIER_GT) return 0;
    if (cat == CAT_CONTI) return tier == TIER_PRO ? 1 : home;
    return tier == TIER_PRO ? home : 0;
}
int invite_score(int team, int race) {
    const RaceDef *rd = &RACES[race];
    int home = !strcmp(TEAMS[team].country, rd->country);
    int sc = G.teams[team].rep + (home ? 12 : 0) + (G.teams[team].cat == CAT_PRO ? 7 : 0);
    sc += (int)(hash32((unsigned)team * 131u + (unsigned)race * 977u + (unsigned)G.year) % 9) - 4;
    if (team == G.player) {
        sc += G.entry[race].requested ? 6 : 0;
        sc += G.teams[team].board > 70 ? 2 : 0;
    }
    return sc;
}

static unsigned char busy_cnt[MAX_TEAMS][366];
static int team_can_take(int t, int race) {
    const RaceDef *rd = &RACES[race];
    int a = rd->first_day, b = race_last_day(race);
    int cap = (G.teams[t].cat == CAT_WT || G.teams[t].cat == CAT_PRO) ? 2 : 1;
    for (int d = a; d <= b; d++) if (busy_cnt[t][d] >= cap) return 0;
    return 1;
}
static void team_take(int t, int race) { int a = RACES[race].first_day, b = race_last_day(race); for (int d = a; d <= b; d++) busy_cnt[t][d]++; }

static int cmp_cand_desc(const void *a, const void *b) { const int *x = a, *y = b; return y[1] - x[1]; }

static void build_entrants(int race, int *races_order, int nr) {
    (void)races_order; (void)nr;
    RaceEntry *e = &G.entry[race]; const RaceDef *rd = &RACES[race];
    e->n = 0; e->auto_n = 0;
    int player_wt_oblig = (G.teams[G.player].cat == CAT_WT && rd->tier <= TIER_WT);
    for (int t = 0; t < G.nteams; t++) {
        if (t == G.player || G.teams[t].cat != CAT_WT) continue;
        int take = rd->tier <= TIER_WT || (hash32((unsigned)t * 31u + (unsigned)race * 7u + (unsigned)G.year) % 100 < 55);
        if (take && team_can_take(t, race) && e->n < MAX_RACE_T) { e->team[e->n++] = (short)t; team_take(t, race); }
    }
    e->auto_n = (unsigned char)e->n;
    int cand[MAX_TEAMS][2]; int nc = 0;
    for (int t = 0; t < G.nteams; t++) {
        if (t == G.player || G.teams[t].cat == CAT_WT) continue;
        int home = !strcmp(TEAMS[t].country, rd->country);
        if (!cat_eligible(rd->tier, G.teams[t].cat, home)) continue;
        cand[nc][0] = t; cand[nc][1] = invite_score(t, race); nc++;
    }
    qsort(cand, nc, sizeof cand[0], cmp_cand_desc);
    int inv = rd->slots - e->n - (player_wt_oblig ? 1 : 0);
    int pcat = G.teams[G.player].cat;
    if (pcat != CAT_WT) inv = rd->slots - e->n;
    if (inv < 0) inv = 0;
    e->inv_slots = (short)inv;
    int taken = 0; e->cutscore = 0;
    for (int i = 0; i < nc && taken < inv; i++) {
        int t = cand[i][0];
        if (!team_can_take(t, race)) continue;
        e->team[e->n++] = (short)t; team_take(t, race); taken++; e->cutscore = (short)cand[i][1];
    }
}

void race_update_status(int race) {
    RaceEntry *e = &G.entry[race]; const RaceDef *rd = &RACES[race];
    Team *pt = &G.teams[G.player];
    int pcat = pt->cat;
    int home = !strcmp(TEAMS[G.player].country, rd->country);
    e->pscore = (short)invite_score(G.player, race);
    int rank = 1;
    for (int i = e->auto_n; i < e->n; i++) if (invite_score(e->team[i], race) > e->pscore) rank++;
    e->rank_est = (short)rank;
    if (e->done || race_last_day(race) < G.day) { if (e->pstatus != PS_INSCRITA) e->pstatus = PS_CERRADA; return; }
    if (e->pstatus == PS_RENUNCIA || e->pstatus == PS_INSCRITA) return;
    if (e->pstatus == PS_INVITADA || e->pstatus == PS_RECHAZADA) return;
    if (pcat == CAT_WT && rd->tier <= TIER_WT) { e->pstatus = PS_OBLIGATORIA; return; }
    if (pcat == CAT_WT) { e->pstatus = PS_OPCIONAL; return; }
    if (!cat_eligible(rd->tier, pcat, home)) { e->pstatus = PS_NONE; return; }
    e->pstatus = e->requested ? PS_SOLICITADA : PS_SOLICITABLE;
}

void race_request_invite(int race) {
    RaceEntry *e = &G.entry[race];
    if (e->pstatus == PS_SOLICITABLE) { e->requested = 1; e->pstatus = PS_SOLICITADA; }
}
void race_withdraw(int race) {
    RaceEntry *e = &G.entry[race];
    if (e->pstatus == PS_OPCIONAL || e->pstatus == PS_INVITADA || e->pstatus == PS_OBLIGATORIA || e->pstatus == PS_INSCRITA) {
        e->squad_n = 0;
        if (e->pstatus == PS_OPCIONAL || e->pstatus == PS_INSCRITA) e->pstatus = PS_OPCIONAL;
    }
}

static void resolve_invite(int race) {
    RaceEntry *e = &G.entry[race];
    if (e->pstatus != PS_SOLICITABLE && e->pstatus != PS_SOLICITADA) return;
    race_update_status(race);
    if (e->rank_est <= e->inv_slots) {
        e->pstatus = PS_INVITADA;
        if (e->n > e->auto_n) e->n--;             /* desplaza al ultimo invitado */
        msg_add(MSG_RACE, -1, "Invitación recibida", "¡%s te invita a participar! Selecciona tu equipo de %d corredores antes del %s.", RACES[race].name, RACES[race].squad, day_str(RACES[race].first_day - 1));
    } else {
        e->pstatus = PS_RECHAZADA;
        msg_add(MSG_RACE, -1, "Invitación denegada", "%s no te ha invitado (puesto %d de %d plazas). Más reputación y mejores resultados te abrirán puertas.", RACES[race].name, e->rank_est, e->inv_slots);
    }
}

void game_start_season(void) {
    memset(busy_cnt, 0, sizeof busy_cnt);
    for (int i = 0; i < 32; i++) { memset(&G.entry[i], 0, sizeof(RaceEntry)); G.entry[i].winner_rider = -1; }
    memset(G.runs, 0, sizeof G.runs);
    /* orden de prioridad: tiers mas altos primero */
    int order[32]; int n = 0;
    for (int tier = 0; tier <= 3; tier++) for (int r = 0; r < RACE_COUNT; r++) if (RACES[r].tier == tier) order[n++] = r;
    for (int i = 0; i < n; i++) build_entrants(order[i], order, n);
    for (int r = 0; r < RACE_COUNT; r++) race_update_status(r);
    for (int t = 0; t < G.nteams; t++) { G.teams[t].pts = 0; G.teams[t].wins = 0; G.teams[t].spent_year = 0; G.teams[t].earned_year = 0; G.teams[t].prize_year = 0; }
    for (int i = 0; i < G.nriders; i++) { Rider *r = &G.riders[i]; r->race_days = 0; r->pts = 0; r->podiums = 0; }
    int pc = G.teams[G.player].cat;
    G.season_obj_rank = pc == CAT_WT ? 9 : (pc == CAT_PRO ? 8 : 12);
    G.season_obj_wins = pc == CAT_WT ? 8 : (pc == CAT_PRO ? 3 : 1);
}

/* ---------------------------------------------------------------- disponibilidad y equipos */
static int rider_in_active_run(int ri) {
    for (int k = 0; k < MAX_RUNS; k++) {
        RaceRun *run = &G.runs[k]; if (!run->active) continue;
        for (int i = 0; i < run->nr; i++) if (run->r[i].rider == ri && !run->r[i].abandoned) return 1;
    }
    return 0;
}
static int races_overlap(int a, int b) { return !(race_last_day(a) < RACES[b].first_day || race_last_day(b) < RACES[a].first_day); }
int rider_available(int ri, int race) {
    Rider *r = &G.riders[ri];
    if (r->team != G.player || r->retired) return 0;
    if (r->inj_days > 0) return 0;
    for (int k = 0; k < RACE_COUNT; k++) {
        if (k == race || !races_overlap(k, race)) continue;
        RaceEntry *e = &G.entry[k];
        for (int i = 0; i < e->squad_n; i++) if (e->squad[i] == ri && (e->pstatus == PS_OBLIGATORIA || e->pstatus == PS_INVITADA || e->pstatus == PS_INSCRITA)) return 0;
    }
    return 1;
}
int squad_valid(int race, char *why, int len) {
    RaceEntry *e = &G.entry[race];
    if (e->squad_n != RACES[race].squad) { snprintf(why, len, "Faltan corredores: %d de %d.", e->squad_n, RACES[race].squad); return 0; }
    int lead = 0;
    for (int i = 0; i < e->squad_n; i++) {
        if (!rider_available(e->squad[i], race)) { snprintf(why, len, "%s no está disponible (lesión o conflicto).", rider_name(e->squad[i])); return 0; }
        if (G.riders[e->squad[i]].fatigue > 92) { snprintf(why, len, "%s está agotado.", rider_name(e->squad[i])); return 0; }
        if (e->squad_role[i] == ROLE_LIDER || e->squad_role[i] == ROLE_ESPRINTER) lead = 1;
    }
    if (!lead) { snprintf(why, len, "Necesitas un líder o un esprínter."); return 0; }
    why[0] = 0; return 1;
}
void squad_auto(int race) {
    RaceEntry *e = &G.entry[race]; const RaceDef *rd = &RACES[race];
    short pool[40]; int np = 0; short rs[40]; int n = team_roster(G.player, rs, 40);
    for (int i = 0; i < n; i++) if (rider_available(rs[i], race)) pool[np++] = rs[i];
    int kind = race_main_kind(race);
    int sc[40];
    for (int i = 0; i < np; i++) {
        Rider *r = &G.riders[pool[i]];
        int base = kind == K_MONTANA ? (rider_gc_score(r) + rider_climb_score(r)) / 2 : (kind == K_CLASICA ? rider_classic_score(r) : (rider_flat_score(r) + rider_sprint_score(r)) / 2);
        sc[i] = base * 3 + r->level + r->form / 4 - r->fatigue / 2;
    }
    short sel[8]; int ns = 0;
    int want = rd->squad;
    for (int k = 0; k < want && ns < np; k++) {
        int bi = -1;
        for (int i = 0; i < np; i++) { int used = 0; for (int j = 0; j < ns; j++) if (sel[j] == pool[i]) used = 1; if (used) continue; if (bi < 0 || sc[i] > sc[bi]) bi = i; }
        if (bi < 0) break;
        sel[ns++] = pool[bi];
    }
    /* garantizar un esprinter si hay uno decente y no se eligio */
    int has_sp = 0; for (int i = 0; i < ns; i++) if (rider_sprint_score(&G.riders[sel[i]]) >= 70) has_sp = 1;
    if (!has_sp && kind != K_MONTANA && ns >= 2) {
        int bi = -1, bv = 0;
        for (int i = 0; i < np; i++) { int used = 0; for (int j = 0; j < ns; j++) if (sel[j] == pool[i]) used = 1; if (used) continue; int v = rider_sprint_score(&G.riders[pool[i]]); if (v > bv) { bv = v; bi = i; } }
        if (bi >= 0 && bv >= 70) sel[ns - 1] = pool[bi];
    }
    e->squad_n = (unsigned char)ns;
    unsigned char roles[8];
    assign_roles(sel, ns, kind, roles);
    for (int i = 0; i < ns; i++) { e->squad[i] = sel[i]; e->squad_role[i] = roles[i]; }
    if (e->pstatus == PS_OPCIONAL) e->pstatus = PS_INSCRITA;
}
int player_can_enter(int race, char *why, int wl) {
    RaceEntry *e = &G.entry[race];
    switch (e->pstatus) {
        case PS_NONE: snprintf(why, wl, "Tu categoría no puede participar."); return 0;
        case PS_RECHAZADA: snprintf(why, wl, "Invitación denegada."); return 0;
        case PS_SOLICITABLE: case PS_SOLICITADA: snprintf(why, wl, "Pendiente de invitación."); return 0;
        case PS_CERRADA: snprintf(why, wl, "Carrera finalizada."); return 0;
    }
    why[0] = 0; return 1;
}
int player_has_race_today(void) {
    for (int r = 0; r < RACE_COUNT; r++) {
        RaceEntry *e = &G.entry[r];
        if (!(e->pstatus == PS_OBLIGATORIA || e->pstatus == PS_INVITADA || e->pstatus == PS_INSCRITA)) continue;
        if (e->squad_n == 0 && G.day < RACES[r].first_day) continue;
        const RaceDef *rd = &RACES[r];
        for (int i = 0; i < rd->nstages; i++) if (STAGES[rd->stage0 + i].day == G.day) {
            RaceRun *run = NULL;
            for (int k = 0; k < MAX_RUNS; k++) if (G.runs[k].active && G.runs[k].race == r) run = &G.runs[k];
            if (!run && i != 0) continue;
            if (run && run->stage != rd->stage0 + i) continue;
            return 1;
        }
    }
    return 0;
}
int today_races(int *list, int max) {
    int n = 0;
    for (int r = 0; r < RACE_COUNT && n < max; r++) {
        RaceEntry *e = &G.entry[r];
        if (!(e->pstatus == PS_OBLIGATORIA || e->pstatus == PS_INVITADA || e->pstatus == PS_INSCRITA)) continue;
        const RaceDef *rd = &RACES[r];
        for (int i = 0; i < rd->nstages; i++) if (STAGES[rd->stage0 + i].day == G.day) {
            RaceRun *run = NULL;
            for (int k = 0; k < MAX_RUNS; k++) if (G.runs[k].active && G.runs[k].race == r) run = &G.runs[k];
            if (run && run->stage != rd->stage0 + i) continue;
            list[n++] = r; break;
        }
    }
    return n;
}

/* ---------------------------------------------------------------- escuadras de la IA y carreras */
static void ai_squad(int team, int race, short *out, int want, int *nout) {
    short rs[40]; int n = team_roster(team, rs, 40);
    int kind = race_main_kind(race);
    int sc[40];
    for (int i = 0; i < n; i++) {
        Rider *r = &G.riders[rs[i]];
        int base = kind == K_MONTANA ? (rider_gc_score(r) + rider_climb_score(r)) / 2 : (kind == K_CLASICA ? rider_classic_score(r) : (rider_flat_score(r) + rider_sprint_score(r)) / 2);
        sc[i] = base * 3 + r->level + r->form / 4 - r->fatigue / 2 + (int)(hash32((unsigned)rs[i] + (unsigned)race * 13u) % 6);
        if (r->inj_days > 0 || r->fatigue > 88) sc[i] -= 400;
        if (rider_in_active_run(rs[i])) sc[i] -= 800;
    }
    int k = 0;
    for (; k < want; k++) {
        int bi = -1;
        for (int i = 0; i < n; i++) { int used = 0; for (int j = 0; j < k; j++) if (out[j] == rs[i]) used = 1; if (used) continue; if (bi < 0 || sc[i] > sc[bi]) bi = i; }
        if (bi < 0 || sc[bi] < -300) break;
        out[k] = rs[bi];
    }
    *nout = k;
}

void assign_ai_strats(RaceRun *run, int stage_idx) {
    const StageDef *st = &STAGES[stage_idx];
    for (int t = 0; t < run->nteams; t++) {
        if (run->team[t] == G.player && run->focus) continue;
        int best_gc = 0, best_sp = 0, best_cl = 0;
        for (int i = 0; i < run->nr; i++) {
            RunRider *rr = &run->r[i]; if (rr->tslot != t || rr->abandoned) continue;
            Rider *r = &G.riders[rr->rider];
            int g = rider_gc_score(r), s = rider_sprint_score(r), c = rider_classic_score(r);
            if (g > best_gc) best_gc = g; if (s > best_sp) best_sp = s; if (c > best_cl) best_cl = c;
        }
        int h = (int)(hash32((unsigned)(run->team[t] * 17 + stage_idx * 5)) % 100);
        int st_strat = STR_AUTO;
        int multi = RACES[run->race].nstages > 1;
        switch (st->kind) {
            case K_LLANA:
                if (best_sp >= 69) st_strat = STR_ESPRINT; else st_strat = (h < 55) ? STR_ESCAPADA : STR_AUTO;
                if (multi && best_gc >= 74 && best_sp < 74) st_strat = STR_AUTO;
                break;
            case K_MEDIA:
                if (multi && best_gc >= 70) st_strat = STR_GENERAL; else if (best_sp >= 74) st_strat = h < 50 ? STR_ESPRINT : STR_CONSERVAR; else st_strat = h < 65 ? STR_ESCAPADA : STR_AUTO;
                break;
            case K_MONTANA:
                if (best_gc >= 68) st_strat = STR_GENERAL; else if (best_sp >= 70) st_strat = STR_CONSERVAR; else st_strat = h < 70 ? STR_ESCAPADA : STR_AUTO;
                break;
            case K_CLASICA:
                if (best_cl >= 74) st_strat = STR_GENERAL; else if (best_sp >= 72 && h < 60) st_strat = STR_ESPRINT; else st_strat = STR_ESCAPADA;
                break;
            default: st_strat = STR_AUTO;
        }
        run->strat[t] = (unsigned char)st_strat;
    }
}

static RaceRun *run_for(int race) {
    for (int k = 0; k < MAX_RUNS; k++) if (G.runs[k].active && G.runs[k].race == race) return &G.runs[k];
    return NULL;
}

static RaceRun *run_create(int race) {
    RaceRun *run = NULL;
    for (int k = 0; k < MAX_RUNS; k++) if (!G.runs[k].active) { run = &G.runs[k]; break; }
    if (!run) return NULL;
    memset(run, 0, sizeof *run);
    RaceEntry *e = &G.entry[race]; const RaceDef *rd = &RACES[race];
    run->active = 1; run->race = (short)race; run->stage = (short)rd->stage0;
    int player_in = (e->pstatus == PS_OBLIGATORIA || e->pstatus == PS_INVITADA || e->pstatus == PS_INSCRITA) && e->squad_n > 0;
    int nt = 0;
    for (int i = 0; i < e->n && nt < MAX_RACE_T - 1; i++) run->team[nt++] = e->team[i];
    if (player_in) run->team[nt++] = (short)G.player;
    run->nteams = (unsigned char)nt;
    int kind = race_main_kind(race);
    for (int t = 0; t < nt && run->nr + 8 <= MAX_RUN_R; t++) {
        short sq[8]; int ns = 0; unsigned char roles[8]; int human = 0;
        if (run->team[t] == G.player && player_in) {
            ns = e->squad_n; for (int i = 0; i < ns; i++) { sq[i] = e->squad[i]; roles[i] = e->squad_role[i]; }
            human = 1; run->strat[t] = e->strat;
        } else {
            ai_squad(run->team[t], race, sq, rd->squad, &ns);
            assign_roles(sq, ns, kind, roles);
        }
        for (int i = 0; i < ns; i++) {
            RunRider *rr = &run->r[run->nr++];
            memset(rr, 0, sizeof *rr);
            rr->rider = sq[i]; rr->tslot = (unsigned char)t; rr->role = roles[i]; rr->human = (unsigned char)human;
            G.riders[sq[i]].raced_today = 1;
            if (human) {
                Rider *hr = &G.riders[sq[i]];
                for (int pp = 0; pp < 2; pp++) {
                    Promise *pr = &hr->prom[pp]; if (!pr->kind || pr->done) continue;
                    if (pr->kind == PROM_GRANVUELTA && rd->tier == TIER_GT) { pr->done = 1; hr->happy = (unsigned char)clampi(hr->happy + 10, 0, 100); }
                    if (pr->kind == PROM_LIDER && roles[i] == ROLE_LIDER && rd->tier <= TIER_WT) { pr->done = 1; hr->happy = (unsigned char)clampi(hr->happy + 8, 0, 100); }
                }
            }
        }
    }
    if (player_in) run->focus = 1;
    return run;
}

RaceRun *game_race_run(int race, int create) {
    RaceRun *r = run_for(race);
    if (!r && create) r = run_create(race);
    return r;
}

/* ---------------------------------------------------------------- puntos, premios */
static int uci_pts(int tier, int stage_race, int stage, int pos) {
    static const int gt_gc[20] = { 1000,800,650,540,440,360,300,250,200,160,120,100,80,70,60,50,40,30,25,20 };
    static const int wt_gc[20] = { 500,400,325,270,220,180,150,125,100,80,60,50,40,35,30,25,20,15,12,10 };
    static const int pr_gc[20] = { 200,150,100,80,60,45,35,28,22,18,14,12,10,8,6,5,4,3,2,1 };
    static const int mon[20] = { 800,600,480,400,320,260,200,160,120,100,80,70,60,50,40,30,25,20,15,10 };
    static const int wt1[20] = { 500,375,300,250,200,160,125,100,80,60,50,40,30,25,20,15,10,8,6,4 };
    static const int pr1[20] = { 200,150,110,90,70,55,40,30,22,18,14,12,10,8,6,5,4,3,2,1 };
    static const int stg[3][10] = { { 50,25,15,10,8,6,4,3,2,1 }, { 40,20,12,8,6,4,3,2,1,0 }, { 20,10,6,4,3,2,1,0,0,0 } };
    if (pos < 0 || pos >= 20) return 0;
    if (stage) { if (pos >= 10) return 0; return stg[tier == TIER_GT ? 0 : (tier == TIER_PRO ? 2 : 1)][pos]; }
    if (stage_race) return tier == TIER_GT ? gt_gc[pos] : (tier == TIER_PRO ? pr_gc[pos] : wt_gc[pos]);
    return tier == TIER_MONUMENTO ? mon[pos] : (tier == TIER_PRO ? pr1[pos] : wt1[pos]);
}
void prize_award(int team, int rider, int euros) {
    (void)rider;
    if (team < 0 || euros <= 0) return;
    G.teams[team].cash += euros; G.teams[team].prize_year += euros; G.teams[team].earned_year += euros;
}
static int prize_for(int tier, int stage_race, int stage, int pos) {
    static const int gcp[3][5] = { { 500000, 200000, 100000, 50000, 25000 }, { 200000, 80000, 40000, 20000, 10000 }, { 60000, 25000, 12000, 6000, 3000 } };
    static const int onep[4][5] = { { 0,0,0,0,0 }, { 80000, 40000, 20000, 10000, 5000 }, { 50000, 25000, 12000, 6000, 3000 }, { 20000, 10000, 5000, 2500, 1500 } };
    if (pos < 0 || pos >= 5) return stage && pos < 10 ? 0 : 0;
    if (stage) return tier == TIER_GT ? (pos == 0 ? 11000 : (pos < 3 ? 4000 : 0)) : (pos == 0 ? 4500 : 0);
    if (stage_race) return gcp[tier == TIER_GT ? 0 : (tier == TIER_PRO ? 2 : 1)][pos];
    return onep[tier & 3][pos];
}

static int gc_sorted(RaceRun *run, short *out) {
    int n = 0;
    for (int i = 0; i < run->nr; i++) if (!run->r[i].abandoned) out[n++] = (short)i;
    for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) if (run->r[out[j]].gc < run->r[out[i]].gc) { short t = out[i]; out[i] = out[j]; out[j] = t; }
    return n;
}
int run_gc_sorted(RaceRun *run, short *out) { return gc_sorted(run, out); }

static void rider_win_effects(int ri, int tier, float weight) {
    Rider *r = &G.riders[ri];
    r->wins++;
    float inc = (tier == TIER_GT ? 1.6f : (tier == TIER_MONUMENTO ? 2.2f : (tier == TIER_WT ? 1.0f : 0.5f))) * weight;
    int nr = r->rep + (int)(inc + 0.5f); r->rep = (unsigned char)clampi(nr, 0, 99);
    if (r->team >= 0) {
        Team *t = &G.teams[r->team];
        t->wins++;
        float ti = (tier == TIER_GT ? 0.6f : (tier == TIER_MONUMENTO ? 0.7f : (tier == TIER_WT ? 0.35f : 0.2f))) * weight;
        if (t->rep < 98 && frnd() < ti) t->rep++;
        r->happy = (unsigned char)clampi(r->happy + 6, 0, 100);
    }
}

void game_apply_race_result(int race, int stage_idx, int final_stage) {
    RaceRun *run = run_for(race); if (!run) return;
    const RaceDef *rd = &RACES[race];
    const StageDef *st = &STAGES[stage_idx];
    int stage_race = rd->nstages > 1;
    /* ganadores de etapa */
    for (int k = 0; k < 10; k++) {
        int ri = run->last_winner[k]; if (ri < 0) break;
        Rider *r = &G.riders[ri];
        int p = uci_pts(rd->tier, stage_race, stage_race, k);
        if (!stage_race || st->kind == K_CRE) {}
        if (stage_race || !final_stage) { r->pts = (unsigned short)(r->pts + p); if (r->team >= 0) G.teams[r->team].pts += p; }
        if (k < 3 && stage_race) r->podiums += 0;
        if (stage_race) prize_award(r->team, ri, prize_for(rd->tier, 1, 1, k));
    }
    int w = run->last_winner[0];
    if (stage_race && w >= 0) {
        rider_win_effects(w, rd->tier, 0.35f);
        if (rd->tier <= TIER_WT && (st->num == 1 || st->kind == K_MONTANA || rd->tier == TIER_GT))
            news_add("%s: etapa %d para %s (%s).", rd->name, st->num, rider_name(w), TEAMS[G.riders[w].team].abbr);
        if (G.riders[w].team == G.player) msg_add(MSG_RACE, w, "¡Victoria de etapa!", "%s ha ganado la etapa %d de %s (%s - %s).", rider_name(w), st->num, rd->name, st->from, st->to);
    }
    if (!stage_race && w >= 0) {
        /* clasica: resultado final */
        for (int k = 0; k < 20; k++) {
            int ri = run->last_winner[k]; if (ri < 0) break;
            Rider *r = &G.riders[ri];
            int p = uci_pts(rd->tier, 0, 0, k);
            r->pts = (unsigned short)(r->pts + p); if (r->team >= 0) G.teams[r->team].pts += p;
            if (k < 3) r->podiums++;
            prize_award(r->team, ri, prize_for(rd->tier, 0, 0, k));
        }
        rider_win_effects(w, rd->tier, 1.0f);
        news_add("%s: gana %s (%s).", rd->name, rider_name(w), TEAMS[G.riders[w].team].abbr);
        if (G.riders[w].team == G.player) msg_add(MSG_RACE, w, "¡Victoria!", "%s gana %s. La afición y los patrocinadores están eufóricos.", rider_name(w), rd->name);
        G.entry[race].winner_rider = (short)w;
    }
    if (final_stage) {
        G.entry[race].done = 1;
        if (stage_race) {
            short ord[MAX_RUN_R]; int n = gc_sorted(run, ord);
            for (int k = 0; k < n && k < 20; k++) {
                int ri = run->r[ord[k]].rider; Rider *r = &G.riders[ri];
                int p = uci_pts(rd->tier, 1, 0, k);
                r->pts = (unsigned short)(r->pts + p); if (r->team >= 0) G.teams[r->team].pts += p;
                if (k < 3) r->podiums++;
                prize_award(r->team, ri, prize_for(rd->tier, 1, 0, k));
            }
            if (n > 0) {
                int wi = run->r[ord[0]].rider;
                G.entry[race].winner_rider = (short)wi;
                rider_win_effects(wi, rd->tier, 1.0f);
                news_add("%s: ¡%s gana la general! (%s)", rd->name, rider_name(wi), TEAMS[G.riders[wi].team].abbr);
                if (G.riders[wi].team == G.player) msg_add(MSG_RACE, wi, "¡Campeón de la general!", "%s gana %s. Es un éxito histórico para %s.", rider_name(wi), rd->name, TEAMS[G.player].name);
            }
            /* mejor puesto del jugador */
            int best = -1;
            for (int k = 0; k < n; k++) if (run->r[ord[k]].human) { best = k + 1; break; }
            G.entry[race].player_best = (short)best;
        }
        for (int i = 0; i < run->nr; i++) if (run->r[i].human) {
            Rider *r = &G.riders[run->r[i].rider];
            if (run->r[i].abandoned) r->happy = (unsigned char)clampi(r->happy - 2, 0, 100);
        }
        if (run->focus) {
            int pt = G.player;
            short ord[MAX_RUN_R]; int n = gc_sorted(run, ord);
            int bestpos = 99; for (int k = 0; k < n; k++) if (run->r[ord[k]].human) { bestpos = k + 1; break; }
            if (rd->tier <= TIER_WT && bestpos <= 3) { if (G.teams[pt].rep < 98) G.teams[pt].rep++; }
            G.teams[pt].board = (unsigned char)clampi(G.teams[pt].board + (bestpos <= 10 ? 2 : (bestpos > 40 ? -1 : 0)), 0, 100);
        }
        run->active = 0;
    }
}

/* ---------------------------------------------------------------- avance de un dia */
void game_run_stage_headless(RaceRun *run) {
    static Sim sim;
    int stage_idx = run->stage;
    assign_ai_strats(run, stage_idx);
    sim_setup(&sim, stage_idx, run, 0);
    sim_run_all(&sim);
    sim_finalize(&sim, run);
    const RaceDef *rd = &RACES[run->race];
    int final_stage = (stage_idx == rd->stage0 + rd->nstages - 1);
    game_apply_race_result(run->race, stage_idx, final_stage);
    run->stage++;
}

void race_prepare_all_today(void) { /* reservado */ }

static void spend_race_costs(RaceRun *run);
void game_prepare_stage(RaceRun *run) {
    spend_race_costs(run);
    assign_ai_strats(run, run->stage);
}
void game_finish_interactive(void *simp, RaceRun *run) {
    Sim *sm = (Sim *)simp;
    sim_finalize(sm, run);
    const RaceDef *rd = &RACES[run->race];
    int stage_idx = run->stage;
    int final_stage = (stage_idx == rd->stage0 + rd->nstages - 1);
    game_apply_race_result(run->race, stage_idx, final_stage);
    run->stage++;
}

static void spend_race_costs(RaceRun *run) {
    for (int t = 0; t < run->nteams; t++) {
        int tm = run->team[t];
        int cnt = 0; for (int i = 0; i < run->nr; i++) if (run->r[i].tslot == t && !run->r[i].abandoned) cnt++;
        int cost = cnt * 900;
        G.teams[tm].cash -= cost; G.teams[tm].spent_year += cost;
    }
}

static void daily_updates(void) {
    for (int i = 0; i < G.nriders; i++) {
        Rider *r = &G.riders[i]; if (r->retired) continue;
        int tm = r->team;
        int medic = tm >= 0 ? G.teams[tm].staff[STAFF_MEDICO] : 0;
        if (r->inj_days > 0) { r->inj_days -= 1 + (medic >= 4 ? 1 : 0) * (G.day & 1); if (r->inj_days < 0) r->inj_days = 0; }
        if (r->raced_today) { r->raced_today = 0; continue; }
        int rec = 3 + r->a[A_RECUP] / 28 + medic;
        if (r->train == TR_DESCANSO) rec += 3;
        int nf = r->fatigue - rec; r->fatigue = (unsigned char)clampi(nf, 0, 100);
        /* forma: tiende a 74 en temporada, con ligera caida si esta fresco */
        int target = 72 + (tm >= 0 ? G.teams[tm].staff[STAFF_ENTRENADOR] * 2 : 0);
        if (r->train == TR_DESCANSO) target -= 4;
        if (r->form < target && (G.day & 1)) r->form++;
        else if (r->form > target + 8 && (G.day % 3) == 0) r->form--;
    }
}

static void weekly_updates(void) {
    short rs[40];
    /* entrenamiento: pequenas mejoras */
    for (int i = 0; i < G.nriders; i++) {
        Rider *r = &G.riders[i]; if (r->retired || r->team < 0) continue;
        int coach = G.teams[r->team].staff[STAFF_ENTRENADOR];
        int age = age_of(r);
        float chance = (age <= 24 ? 0.07f : (age <= 29 ? 0.035f : 0.015f)) * (1.0f + coach * 0.14f);
        int tr = r->train;
        if (r->team != G.player) tr = (int)(hash32((unsigned)i + (unsigned)G.day) % 6);
        if (tr == TR_DESCANSO || tr == TR_LIGERO) { if (frnd() < chance * 0.4f) { int a = irange(0, A_COUNT - 1); if (r->a[a] < 95) r->a[a]++; } continue; }
        if (r->fatigue > 75) continue;
        if (r->team == G.player) r->fatigue = (unsigned char)clampi(r->fatigue + 2, 0, 100);
        int pick[3] = { 0, 0, 0 };
        switch (tr) {
            case TR_FONDO: pick[0] = A_FONDO; pick[1] = A_RESIST; pick[2] = A_LLANO; break;
            case TR_MONTANA: pick[0] = A_MONTANA; pick[1] = A_MEDIA; pick[2] = A_RECUP; break;
            case TR_SPRINT: pick[0] = A_ESPRINT; pick[1] = A_ACEL; pick[2] = A_ESPRINT; break;
            case TR_CRI: pick[0] = A_CRI; pick[1] = A_PROLOGO; pick[2] = A_LLANO; break;
            default: pick[0] = A_COLINAS; pick[1] = A_ACEL; pick[2] = A_PAVES; break;
        }
        if (frnd() < chance * 3.0f) { int a = pick[irange(0, 2)]; int cap = r->type == T_ESPRINTER || 1 ? 96 : 96; if (r->a[a] < cap && (r->a[a] < r->pot + 6)) r->a[a]++; }
        /* satisfaccion: esta contento si compite lo suficiente */
    }
    /* felicidad del jugador */
    int n = team_roster(G.player, rs, 40);
    for (int k = 0; k < n; k++) {
        Rider *r = &G.riders[rs[k]];
        int expected = (G.day / 7) * 3;
        if (r->level >= 74) expected += 2;
        if (r->race_days + 6 < expected / 2 && r->level >= 68 && G.day > 90) r->happy = (unsigned char)clampi(r->happy - 2, 0, 100);
        else if (r->happy < 75) r->happy++;
        for (int p = 0; p < 2; p++) {
            Promise *pr = &r->prom[p]; if (!pr->kind || pr->done) continue;
            if (pr->kind == PROM_DIAS && r->race_days >= pr->value) { pr->done = 1; r->happy = (unsigned char)clampi(r->happy + 8, 0, 100); }
            if (G.day > pr->deadline) {
                pr->done = 2; r->happy = (unsigned char)clampi(r->happy - 22, 0, 100);
                msg_add(MSG_RIDER, rs[k], "Promesa incumplida", "%s está furioso: no cumpliste lo prometido. Su moral cae en picado.", r->name);
            }
        }
        if (r->happy < 34 && G.day % 28 == 0) msg_add(MSG_RIDER, rs[k], "Descontento", "%s se queja de su situación y estudia ofertas de otros equipos. Habla con él o dale protagonismo.", r->name);
        if (r->contract_end == G.year && G.day > 270 && G.day % 28 == 0) msg_add(MSG_RIDER, rs[k], "Contrato por vencer", "El contrato de %s termina esta temporada. Negocia su renovación en la pantalla de plantilla.", r->name);
    }
    /* ojeo pasivo */
    int sc = G.teams[G.player].staff[STAFF_SCOUT];
    for (int i = 0; i < G.nriders; i++) {
        Rider *r = &G.riders[i]; if (r->team == G.player || r->retired) continue;
        int add = r->shortlist ? 4 + sc * 4 : (sc > 0 && (i % 11 == G.day % 11) ? sc : 0);
        if (add) r->seen = (unsigned char)clampi(r->seen + add, 0, 100);
    }
}

static void ai_market_week(void) {
    /* equipos de la IA por debajo del minimo ficha libres */
    for (int t = 0; t < G.nteams; t++) {
        if (t == G.player) continue;
        int sz = team_size(t);
        if (sz >= min_roster(G.teams[t].cat) + 1) continue;
        int best = -1, bv = -1;
        for (int i = 0; i < G.nriders; i++) {
            Rider *r = &G.riders[i]; if (r->team != -1 || r->retired) continue;
            if (r->rep > G.teams[t].rep + 14) continue;
            int pay = salary_for_value(rider_value(r), r->rep);
            if (pay > wage_cap(t) - team_payroll(t) + 100000 && pay > 60000) continue;
            int v = rider_ovr(r) * 2 + (age_of(r) < 27 ? (r->pot - rider_ovr(r)) : 0);
            if (v > bv) { bv = v; best = i; }
        }
        if (best >= 0) {
            Rider *r = &G.riders[best];
            r->team = (short)t; r->salary = salary_for_value(rider_value(r), r->rep);
            r->contract_end = (short)(G.year + irange(1, 3)); r->happy = 70;
        }
    }
    /* fichajes entre equipos de la IA: de vez en cuando */
}

static void monthly_finances(void) {
    for (int t = 0; t < G.nteams; t++) {
        Team *tm = &G.teams[t];
        long long inc = tm->sponsor / 12;
        long long out = (long long)team_payroll(t) / 12 + team_staff_cost(t) / 12;
        tm->cash += inc - out; tm->earned_year += (int)inc; tm->spent_year += (int)out;
        if (t != G.player && tm->cash < 0) tm->cash = tm->cash / 2;   /* la IA se reorganiza */
    }
    Team *p = &G.teams[G.player];
    if (p->cash < 0) {
        msg_add(MSG_BOARD, -1, "Alerta financiera", "Las cuentas están en números rojos (%s). La directiva exige recortar gastos o la confianza caerá.", money_str(p->cash));
        p->board = (unsigned char)clampi(p->board - 6, 0, 100);
    }
}

void game_advance_day(void) {
    /* 1. carreras de hoy (las del jugador ya han sido jugadas por la interfaz) */
    for (int r = 0; r < RACE_COUNT; r++) {
        const RaceDef *rd = &RACES[r];
        if (G.day < rd->first_day || G.day > race_last_day(r)) continue;
        int has_today = 0, si = -1;
        for (int i = 0; i < rd->nstages; i++) if (STAGES[rd->stage0 + i].day == G.day) { has_today = 1; si = rd->stage0 + i; }
        if (!has_today || G.entry[r].done) continue;
        RaceRun *run = run_for(r);
        if (!run) {
            if (si != rd->stage0) continue;
            { RaceEntry *pe = &G.entry[r]; if ((pe->pstatus == PS_OBLIGATORIA || pe->pstatus == PS_INVITADA || pe->pstatus == PS_INSCRITA) && pe->squad_n == 0) squad_auto(r); }
            run = run_create(r);
            if (!run) continue;
        }
        if (run->stage != si) continue;      /* ya jugada hoy */
        spend_race_costs(run);
        game_run_stage_headless(run);
    }
    daily_updates();
    /* 2. eventos de calendario */
    for (int r = 0; r < RACE_COUNT; r++) {
        if (G.day == race_cut_day(r)) { resolve_invite(r); }
        RaceEntry *e = &G.entry[r];
        if (G.day == RACES[r].first_day - 7 && (e->pstatus == PS_OBLIGATORIA || e->pstatus == PS_INVITADA || e->pstatus == PS_INSCRITA) && e->squad_n == 0) {
            squad_auto(r);
            msg_add(MSG_RACE, -1, "Equipo preseleccionado", "Para %s (%s) se han elegido %d corredores automáticamente. Puedes cambiarlos en el calendario.", RACES[r].name, day_str(RACES[r].first_day), RACES[r].squad);
        }
        race_update_status(r);
    }
    if (G.day % 7 == 0) { weekly_updates(); ai_market_week(); }
    if (G.day > 0 && G.day % 30 == 14) monthly_finances();
    G.day++;
    if (G.day >= 365) season_end();
}

/* ---------------------------------------------------------------- fin de temporada */
int team_rank_by_pts(int t) {
    int rank = 1;
    for (int k = 0; k < G.nteams; k++) if (G.teams[k].cat == G.teams[t].cat && G.teams[k].pts > G.teams[t].pts) rank++;
    return rank;
}
int player_rank(void) { return team_rank_by_pts(G.player); }

static const char *FIRST[] = { "Alex","Marc","Pablo","Jonas","Luca","Tom","Enzo","Mateo","Lars","Pieter","Hugo","Adrien","Nico","Jan","Oscar","Iker","Joao","Mikel","Rafael","Samuel" };
static const char *LAST[] = { "Moreau","Rossi","Navarro","De Vries","Lindberg","Kowalski","Ferreira","Hansen","Duval","Bianchi","Larsen","Schmid","Ortega","Peeters","Novak","Costa","Berg","Roche","Vidal","Mertens" };

static void gen_neo(int slot) {
    Rider *r = &G.riders[slot]; memset(r, 0, sizeof *r);
    snprintf(r->name, sizeof r->name, "%s %s", FIRST[rnd() % 20], LAST[rnd() % 20]);
    static const char *CC[] = { "ESP","FRA","ITA","BEL","NED","GER","GBR","DEN","NOR","POR","COL","USA","AUS","SLO" };
    snprintf(r->country, 4, "%s", CC[rnd() % 14]);
    r->byear = (short)(G.year - irange(18, 20)); r->bmonth = (unsigned char)irange(1, 12);
    int base = irange(44, 62);
    for (int a = 0; a < A_COUNT; a++) r->a[a] = (unsigned char)clampi(base + irange(-8, 8), 30, 90);
    r->type = (unsigned char)irange(0, T_COUNT - 1);
    int ex = irange(6, 18);
    switch (r->type) { case T_ESCALADOR: r->a[A_MONTANA] += ex; r->a[A_MEDIA] += ex / 2; break; case T_ESPRINTER: r->a[A_ESPRINT] += ex; r->a[A_ACEL] += ex / 2; break; case T_CRI: r->a[A_CRI] += ex; r->a[A_LLANO] += ex / 2; break; case T_CLASICOMANO: r->a[A_PAVES] += ex; r->a[A_COLINAS] += ex / 2; break; case T_PUNCHEUR: r->a[A_COLINAS] += ex; r->a[A_ACEL] += ex / 2; break; default: r->a[A_LLANO] += ex; r->a[A_FONDO] += ex / 2; }
    for (int a = 0; a < A_COUNT; a++) if (r->a[a] > 92) r->a[a] = 92;
    r->team = -1; r->level = (unsigned char)rider_ovr(r); r->pot = (unsigned char)clampi(r->level + irange(2, 18), 0, 95);
    r->rep = (unsigned char)clampi((r->level - 46) * 2, 3, 40); r->happy = 75; r->form = 65; r->seen = 30;
    r->value = rider_value(r); r->wants_leader = 0;
}

void season_end(void) {
    int pc = G.teams[G.player].cat;
    int rank = player_rank();
    /* evaluacion de objetivos */
    int wins = G.teams[G.player].wins;
    int ok = (rank <= G.season_obj_rank) + (wins >= G.season_obj_wins);
    Team *p = &G.teams[G.player];
    if (ok == 2) { p->board = (unsigned char)clampi(p->board + 14, 0, 100); p->sponsor = (int)(p->sponsor * 1.12); }
    else if (ok == 1) { p->board = (unsigned char)clampi(p->board + 3, 0, 100); p->sponsor = (int)(p->sponsor * 1.03); }
    else { p->board = (unsigned char)clampi(p->board - 12, 0, 100); p->sponsor = (int)(p->sponsor * 0.92); }
    msg_add(MSG_BOARD, -1, "Balance de la temporada", "Puesto %d en el ranking (objetivo %d), %d victorias (objetivo %d). Confianza de la directiva: %d%%.", rank, G.season_obj_rank, wins, G.season_obj_wins, p->board);
    (void)pc;
    G.year++; G.day = 0;
    int retired = 0;
    for (int i = 0; i < G.nriders; i++) {
        Rider *r = &G.riders[i]; if (r->retired) continue;
        int age = age_of(r);
        r->pts_last = r->pts;
        /* progresion */
        for (int a = 0; a < A_COUNT; a++) {
            int d = 0;
            if (age <= 23) d = (rnd() % 100 < 55) ? irange(0, 3) : 0;
            else if (age <= 27) d = (rnd() % 100 < 35) ? irange(0, 2) : 0;
            else if (age <= 30) d = (rnd() % 100 < 20) ? irange(-1, 1) : 0;
            else if (age <= 34) d = (rnd() % 100 < 40) ? -irange(0, 2) : 0;
            else d = (rnd() % 100 < 60) ? -irange(1, 3) : 0;
            if (age <= 26 && r->level < r->pot && d > 0) d += 0;
            int nv = r->a[a] + d; r->a[a] = (unsigned char)clampi(nv, 25, 96);
        }
        r->level = (unsigned char)rider_ovr(r);
        r->value = rider_value(r);
        r->fatigue = 0; r->form = 62; r->inj_days = 0; r->race_days = 0; r->raced_today = 0;
        r->rep = (unsigned char)clampi((int)r->rep + (r->pts > 200 ? 2 : (r->pts == 0 && age > 30 ? -1 : 0)), 3, 99);
        r->prom[0].kind = r->prom[1].kind = 0;
        if (age >= 37 || (age >= 34 && r->level < 56 && r->team < 0)) { r->retired = 1; r->team = -2; retired++; continue; }
        /* contratos */
        if (r->team >= 0 && r->contract_end <= G.year - 1) {
            if (r->team == G.player) {
                r->team = -1; r->salary = 0;
                msg_add(MSG_RIDER, i, "Fin de contrato", "%s abandona el equipo al terminar su contrato.", r->name);
            } else {
                if (rnd() % 100 < 68) { r->contract_end = (short)(G.year + irange(1, 3)); r->salary = salary_for_value(rider_value(r), r->rep); }
                else { r->team = -1; r->salary = 0; }
            }
        }
        if (r->team == -1) r->contract_end = 0;
    }
    /* nuevos profesionales */
    int created = 0;
    for (int i = 0; i < G.nriders && created < 90; i++) if (G.riders[i].retired) { gen_neo(i); created++; }
    while (created < 90 && G.nriders < MAX_RIDERS) { gen_neo(G.nriders++); created++; }
    /* IA: rellenar plantillas */
    for (int k = 0; k < 6; k++) ai_market_week();
    /* reputaciones de equipos: tienden a su plantilla */
    for (int t = 0; t < G.nteams; t++) {
        Team *tm = &G.teams[t];
        static const int cb[4] = { 62, 46, 31, 20 };
        int tgt = cb[tm->cat] + (int)((team_ovr(t) - 60) * 1.6f) + (team_rank_by_pts(t) <= 3 ? 4 : 0);
        tm->rep = (unsigned char)clampi(tm->rep + (tgt > tm->rep ? 1 : (tgt < tm->rep ? -1 : 0)), 8, 98);
        tm->pts_last = tm->pts;
        if (t != G.player) {
            tm->sponsor = (int)(tm->sponsor * (0.97 + (rnd() % 8) * 0.01));
        }
    }
    game_start_season();
    msg_add(MSG_INFO, -1, "Nueva temporada", "Comienza la temporada %d. El calendario se repite; revisa invitaciones y contratos.", G.year);
}

/* ---------------------------------------------------------------- mercado y contratos */
int rider_attr_seen(const Rider *r, int attr, int viewer) {
    (void)viewer;
    if (r->team == G.player) return r->a[attr];
    int err_max = (int)((100 - r->seen) / 100.0f * (14.0f - G.teams[G.player].staff[STAFF_SCOUT] * 2.0f)) ;
    if (err_max < 0) err_max = 0;
    int h = (int)(hash32((unsigned)(r - G.riders) * 31u + (unsigned)attr * 7u) % (unsigned)(2 * err_max + 1)) - err_max;
    return clampi(r->a[attr] + h, 20, 99);
}
void scout_reveal(void) {}

int promise_add(int ri, int kind, int value) {
    Rider *r = &G.riders[ri];
    for (int p = 0; p < 2; p++) if (!r->prom[p].kind || r->prom[p].done) {
        r->prom[p].kind = (unsigned char)kind; r->prom[p].value = (short)value; r->prom[p].done = 0;
        r->prom[p].deadline = (short)(kind == PROM_DIAS ? 330 : 300);
        return 1;
    }
    return 0;
}

int sign_cost_check(int ri, int salary, int fee) {
    Team *t = &G.teams[G.player];
    if (team_size(G.player) >= max_roster(t->cat) && G.riders[ri].team != G.player) return 1;
    if (t->cash < fee) return 2;
    if (team_payroll(G.player) + salary - (G.riders[ri].team == G.player ? G.riders[ri].salary : 0) > wage_cap(G.player) * 1.05) return 3;
    return 0;
}

/* Evalua una oferta. Devuelve 0 = aceptada, otro = motivo del rechazo. */
int offer_evaluate(int ri, int team, int salary, int years, int role, int fee, char *msg, int ml, int commit) {
    Rider *r = &G.riders[ri];
    Team *t = &G.teams[team];
    int renewal = (r->team == team);
    int ask; contract_expected_salary(r, team, role, years, &ask);
    float rdiff = (float)(t->rep - r->rep);
    unsigned noise = hash32((unsigned)ri * 77u + (unsigned)G.day / 7u + (unsigned)r->refusals * 13u);
    /* equipo vendedor */
    if (!renewal && r->team >= 0) {
        int need = (int)(r->value * (0.7 + 0.25 * (r->contract_end - G.year + 1)) * (G.teams[r->team].rep > t->rep ? 1.15 : 1.0));
        if (need < r->value / 2) need = r->value / 2;
        if (fee < need) { snprintf(msg, ml, "%s pide al menos %s por su traspaso.", TEAMS[r->team].name, money_str(need)); return 3; }
    }
    /* reputacion */
    if (!renewal && rdiff < -16 - (r->team < 0 ? 4 + (int)(5 * (salary > ask * 1.4)) : 0) && salary < ask * 1.7) {
        snprintf(msg, ml, "%s no quiere fichar por un equipo con tan poca reputación.", r->name); return 2;
    }
    float need_sal = 0.90f + (rdiff < 0 ? -rdiff * 0.006f : 0) + (r->happy < 50 && renewal ? 0.12f : 0);
    if (renewal && r->happy < 28) { snprintf(msg, ml, "%s se niega a renovar: está muy descontento.", r->name); return 5; }
    if (salary < ask * need_sal) { snprintf(msg, ml, "%s quiere más dinero (pide ~%s).", r->name, money_str((long long)(ask * need_sal))); return 1; }
    /* rol: los buenos quieren ser lideres */
    int best_here = 0;
    for (int i = 0; i < G.nriders; i++) if (G.riders[i].team == team && i != ri && G.riders[i].level > best_here) best_here = G.riders[i].level;
    if (r->wants_leader && role != ROLE_LIDER && role != ROLE_ESPRINTER && r->level >= best_here + 1 && salary < ask * 1.25f) {
        snprintf(msg, ml, "%s exige un rol de líder (o más salario).", r->name); return 4;
    }
    if (!renewal && (noise % 100) < 6 && salary < ask * 1.2f) { snprintf(msg, ml, "%s lo piensa mejor y rechaza la oferta.", r->name); r->refusals++; return 5; }
    snprintf(msg, ml, "%s acepta: %s/año hasta %d.", r->name, money_str(salary), G.year + years - 1);
    if (commit) {
        if (!renewal && r->team >= 0) { G.teams[r->team].cash += fee; t->cash -= fee; t->spent_year += fee; }
        r->team = (short)team; r->salary = salary; r->contract_end = (short)(G.year + years - 1);
        r->role_pref = (unsigned char)role; r->happy = (unsigned char)clampi(r->happy + 10, 0, 100); r->refusals = 0;
        r->shortlist = 0; r->seen = 100;
        if (role == ROLE_LIDER) promise_add(ri, PROM_LIDER, 1);
    }
    return 0;
}

void rider_release(int ri) {
    Rider *r = &G.riders[ri];
    if (r->team != G.player) return;
    long long comp = (long long)r->salary * (r->contract_end - G.year + 1) / 2;
    G.teams[G.player].cash -= comp;
    r->team = -1; r->salary = 0; r->contract_end = 0;
    for (int i = 0; i < RACE_COUNT; i++) {
        RaceEntry *e = &G.entry[i];
        for (int k = 0; k < e->squad_n; k++) if (e->squad[k] == ri) { for (int m = k; m + 1 < e->squad_n; m++) { e->squad[m] = e->squad[m + 1]; e->squad_role[m] = e->squad_role[m + 1]; } e->squad_n--; k--; }
    }
}

void staff_upgrade(int s) {
    Team *t = &G.teams[G.player];
    if (t->staff[s] >= 5) return;
    int c = staff_upgrade_cost(s, t->staff[s]);
    if (t->cash < c) return;
    t->cash -= c; t->staff[s]++;
}
void rider_set_train(int ri, int tr) { G.riders[ri].train = (unsigned char)tr; }
