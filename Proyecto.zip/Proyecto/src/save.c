#include "game.h"
#include <stdio.h>
#include <string.h>

int save_game(const char *path) {
    FILE *f = fopen(path, "wb");
    if (!f) return 0;
    G.version = SAVE_VERSION;
    unsigned int magic = 0x43594331u;
    fwrite(&magic, 4, 1, f);
    int sz = (int)sizeof(Game);
    fwrite(&sz, 4, 1, f);
    int ok = fwrite(&G, sizeof(Game), 1, f) == 1;
    fclose(f);
    return ok;
}

int load_game(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    unsigned int magic = 0; int sz = 0;
    if (fread(&magic, 4, 1, f) != 1 || fread(&sz, 4, 1, f) != 1 || magic != 0x43594331u || sz != (int)sizeof(Game)) { fclose(f); return 0; }
    static Game tmp;
    int ok = fread(&tmp, sizeof(Game), 1, f) == 1 && tmp.version == SAVE_VERSION;
    fclose(f);
    if (ok) memcpy(&G, &tmp, sizeof(Game));
    return ok;
}
