/* Interfaz: widgets, menu, seleccion de equipo y pantallas de gestion. */
#include "ui_int.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

Input IN;
char SAVE_PATH[512] = "partida.sav";
int g_scr = SC_MENU;
static int quit_flag = 0;
static int tab = 0;
static float anim_t = 0;

/* ---------------------------------------------------------------- widgets */
int hit(int x, int y, int w, int h) { return IN.mx >= x && IN.my >= y && IN.mx < x + w && IN.my < y + h; }
int key_pressed(int vk) { for (int i = 0; i < IN.nk; i++) if (IN.keys[i] == vk) return 1; return 0; }

static char toast_txt[120]; static float toast_t = 0;
void toast(const char *fmt, ...) { va_list ap; va_start(ap, fmt); vsnprintf(toast_txt, sizeof toast_txt, fmt, ap); va_end(ap); toast_t = 3.2f; }

int btn_en(int x, int y, int w, int h, const char *s, Col c, int en) {
    int over = en && hit(x, y, w, h);
    int down = over && IN.down;
    Col base = en ? (over ? col_light(c, 28) : c) : col_mix(c, C_PANEL, 190);
    rect(x, y, w, h, base);
    rect(x, y, w, 1, down ? col_dark(base, 40) : col_light(base, 50));
    rect(x, y, 1, h, down ? col_dark(base, 40) : col_light(base, 50));
    rect(x, y + h - 1, w, 1, down ? col_light(base, 50) : col_dark(base, 55));
    rect(x + w - 1, y, 1, h, down ? col_light(base, 50) : col_dark(base, 55));
    int tw = text_w(s);
    text(x + (w - tw) / 2 + down, y + (h - 7) / 2 + down, s, en ? C_TEXT : C_DIM);
    return over && IN.click;
}
int btn(int x, int y, int w, int h, const char *s, Col c) { return btn_en(x, y, w, h, s, c, 1); }

void win(int x, int y, int w, int h, const char *title) {
    rect(x, y, w, h, C_PANEL);
    box(x, y, w, h, C_LINE_D);
    rect(x + 1, y + 1, w - 2, 1, C_LINE);
    rect(x + 1, y + 1, 1, h - 2, C_LINE);
    rect(x + 1, y + h - 2, w - 2, 1, C_LINE_D);
    rect(x + w - 2, y + 1, 1, h - 2, C_LINE_D);
    rect(x + 2, y + 2, w - 4, 9, C_PANEL3);
    for (int i = 0; i < w - 4; i += 2) px(x + 2 + i, y + 2, col_light(C_PANEL3, 22));
    text(x + 5, y + 3, title, C_TEXT);
}
void bar(int x, int y, int w, int h, int pct, Col c) {
    if (pct < 0) pct = 0; if (pct > 100) pct = 100;
    rect(x, y, w, h, C_BLK);
    int f = (w - 2) * pct / 100;
    rect(x + 1, y + 1, f, h - 2, c);
    if (h > 3) rect(x + 1, y + 1, f, 1, col_light(c, 50));
}
Col val_col(int v) { return v >= 80 ? C_YEL : (v >= 70 ? C_GRN : (v >= 60 ? C_CYN : (v >= 50 ? C_TEXT : C_DIM))); }
Col team_c1(int t) { return t < 0 ? C_DIM : RGB(TEAMS[t].c1[0], TEAMS[t].c1[1], TEAMS[t].c1[2]); }
Col team_c2(int t) { return t < 0 ? C_DIM : RGB(TEAMS[t].c2[0], TEAMS[t].c2[1], TEAMS[t].c2[2]); }
void chip(int x, int y, int t) {
    rect(x, y, 7, 7, C_BLK);
    rect(x + 1, y + 1, 5, 3, team_c1(t));
    rect(x + 1, y + 4, 5, 2, team_c2(t));
}

/* ---------------------------------------------------------------- ciclista en pixel art */
void draw_cyclist(int x, int y, Col c1, Col c2, int frame, int s, int mine) {
    /* x,y = centro inferior de las ruedas; mira a la derecha */
#define PX(dx, dy, c) rect(x + (dx) * s, y + (dy) * s, s, s, c)
    Col wheel = RGB(24, 24, 32), tire = RGB(70, 72, 84), frm = mine ? C_YEL : RGB(190, 195, 210), skin = RGB(236, 190, 150), shorts = RGB(24, 24, 34);
    Col jd = col_dark(c1, 50);
    int wx[2] = { -4, 4 };
    for (int w = 0; w < 2; w++) {
        int cx = wx[w], cy = -3;
        static const int ring[12][2] = { {-3,0},{-3,-1},{-2,-2},{-1,-3},{0,-3},{1,-3},{2,-2},{3,-1},{3,0},{3,1},{2,2},{1,3} };
        for (int i = -3; i <= 3; i++) for (int j = -3; j <= 3; j++) {
            int d = i * i + j * j;
            if (d <= 11 && d >= 6) PX(cx + i, cy + j, d >= 9 ? wheel : tire);
        }
        (void)ring;
        /* radios */
        int a = frame & 3;
        static const int sp[4][2] = { {1,0},{1,1},{0,1},{-1,1} };
        PX(cx + sp[a][0], cy + sp[a][1], C_WHT); PX(cx - sp[a][0], cy - sp[a][1], C_WHT);
        PX(cx, cy, frm);
    }
    /* cuadro */
    for (int i = -4; i <= 0; i++) PX(i, -3, frm);                 /* vaina */
    PX(0, -4, frm); PX(0, -5, frm); PX(-1, -6, frm); PX(-1, -7, frm);   /* tubo sillin */
    for (int i = -1; i <= 3; i++) PX(i, -7, frm);                 /* tubo horizontal */
    PX(1, -5, frm); PX(2, -6, frm);                               /* tubo diagonal */
    PX(4, -6, frm); PX(4, -5, frm); PX(4, -4, frm);               /* horquilla */
    PX(3, -8, frm); PX(4, -8, frm);                               /* manillar */
    PX(-2, -8, frm); PX(-1, -8, frm);                             /* sillin */
    /* ciclista */
    PX(-2, -9, shorts); PX(-1, -9, shorts);
    PX(-1, -10, c1); PX(0, -10, c1); PX(1, -10, c1); PX(2, -10, c1);            /* espalda */
    PX(0, -11, c1); PX(1, -11, c2); PX(2, -11, c1); PX(3, -10, c2);
    PX(3, -9, skin); PX(4, -9, skin);                                       /* brazos */
    PX(3, -11, skin); PX(4, -12, jd); PX(5, -12, jd); PX(4, -11, jd);       /* cabeza + casco */
    PX(5, -11, skin);
    /* piernas */
    static const int ft[4][4] = { {1,-1,1,-4}, {2,-2,1,-4}, {1,-4,2,-1}, {0,-3,1,-2} };
    int f = frame & 3;
    int fx1 = ft[f][0], fy1 = ft[f][1], fx2 = ft[(f + 2) & 3][0], fy2 = ft[(f + 2) & 3][1];
    PX(-1, -8, shorts); PX(0, -7 + 0, shorts);
    PX(fx1 - 1, fy1 - 3, jd); PX(fx1, fy1, skin);
    PX(fx2 - 1, fy2 - 3, c2); PX(fx2, fy2, skin);
    PX(fx1, fy1 + 1, shorts);
#undef PX
}

/* ---------------------------------------------------------------- estado de pantallas */
static int sel_rider = 0, scr_squad = 0;
static int sel_mkt = -1, scr_mkt = 0, mkt_filter = 0, mkt_sort = 0, mkt_n = 0;
static short mkt_list[MAX_RIDERS];
static int sel_race_i = 0, scr_cal = 0, cal_stage = 0, race_order[32], race_order_n = 0;
static int sel_msg = 0, scr_msg = 0;
static int teamsel_cat = 0, teamsel_scroll = 0, teamsel_sel = 0;
static int rank_mode = 0;

/* negociacion */
static struct { int on, ri, role, years, salary, fee, promise, code, renewal; char msg[120]; int ask; } neg;
/* equipo de carrera */
static struct { int on, race; int scroll; } sqm;

static void neg_open(int ri, int renewal) {
    memset(&neg, 0, sizeof neg);
    neg.on = 1; neg.ri = ri; neg.renewal = renewal;
    Rider *r = &G.riders[ri];
    neg.role = r->role_pref ? r->role_pref : ROLE_GREGARIO;
    neg.years = 2;
    contract_expected_salary(r, G.player, neg.role, neg.years, &neg.ask);
    neg.salary = neg.ask;
    neg.fee = (r->team >= 0 && !renewal) ? r->value : 0;
    neg.msg[0] = 0; neg.code = -1;
}

/* ---------------------------------------------------------------- menu y seleccion de equipo */
static int has_save(void) { FILE *f = fopen(SAVE_PATH, "rb"); if (f) { fclose(f); return 1; } return 0; }

static void draw_title_bg(void) {
    clear(RGB(18, 22, 52));
    /* cielo en bandas */
    for (int y = 0; y < 200; y++) {
        int t = y * 256 / 200;
        Col c = col_mix(RGB(34, 40, 96), RGB(255, 150, 90), t * t / 256);
        rect(0, y, SW, 1, c);
    }
    for (int i = 0; i < 70; i++) px((i * 97) % SW, (i * 53) % 90, (i & 3) == 0 ? C_WHT : RGB(190, 200, 240));
    /* sol */
    disc(470, 150, 26, RGB(255, 230, 140)); disc(470, 150, 20, RGB(255, 246, 190));
    /* montanas */
    for (int layer = 0; layer < 3; layer++) {
        Col mc = layer == 0 ? RGB(96, 74, 130) : (layer == 1 ? RGB(66, 54, 104) : RGB(40, 36, 78));
        for (int x = 0; x < SW; x++) {
            float h = 40 + layer * 18 + 30 * sinf(x * 0.017f + layer * 2.1f) + 16 * sinf(x * 0.045f + layer) + 8 * sinf(x * 0.11f);
            int y0 = 250 - (int)h + layer * 22 - 40;
            rect(x, y0, 1, 360 - y0, mc);
        }
    }
    /* carretera */
    for (int x = 0; x < SW; x++) {
        int y = 292 + (int)(14 * sinf(x * 0.012f + anim_t * 0.0f));
        rect(x, y, 1, 70, RGB(46, 46, 58));
        if (((x + (int)(anim_t * 60)) / 14) % 2 == 0) rect(x, y + 30, 1, 2, RGB(230, 220, 120));
        rect(x, y, 1, 2, RGB(190, 190, 200));
    }
}

static void menu_draw(void) {
    draw_title_bg();
    /* peloton animado */
    for (int i = 0; i < 9; i++) {
        int x = 80 + i * 52 + (int)(sinf(anim_t * 1.3f + i) * 4);
        int y = 322 + (i % 3) * 7 - (int)(14 * sinf((x) * 0.012f));
        y = 306 + (i % 3) * 8;
        static const Col cs[5] = { RGB(250,214,40), RGB(205,30,45), RGB(40,92,205), RGB(236,236,236), RGB(235,70,150) };
        draw_cyclist(x, y, cs[i % 5], cs[(i + 2) % 5], (int)(anim_t * 10) + i, 2, 0);
    }
    for (int k = 0; k < 2; k++) {
        const char *t = "CICLISMO MANAGER";
        int tw = text_w(t);
        for (int ch = 0; ch < (int)strlen(t); ch++) {
            char s[2] = { t[ch], 0 };
            /* texto grande x3 dibujando cada glifo escalado */
            (void)s; (void)tw;
        }
    }
    /* titulo grande: escalar pintando el texto en un buffer pequeno */
    {
        const char *t = "CICLISMO MANAGER";
        int tw = text_w(t);
        static Col buf[200 * 9]; Col save[200 * 9];
        (void)buf; (void)save;
        int sx = 320 - tw * 3 / 2, sy = 30;
        for (int j = 0; j < 9; j++) for (int i = 0; i < tw + 1; i++) {
            save[j * 200 + i] = getpx(i, j);
        }
        /* dibujar texto en esquina, copiar escalado y restaurar */
        text(0, 1, t, RGB(255, 0, 255));
        Col cp[200 * 9];
        for (int j = 0; j < 9; j++) for (int i = 0; i < tw + 1; i++) cp[j * 200 + i] = getpx(i, j);
        for (int j = 0; j < 9; j++) for (int i = 0; i < tw + 1; i++) px(i, j, save[j * 200 + i]);
        for (int j = 0; j < 9; j++) for (int i = 0; i < tw + 1; i++) if (cp[j * 200 + i] == RGB(255, 0, 255)) {
            rect(sx + i * 3 + 3, sy + j * 3 + 3, 3, 3, RGB(80, 30, 40));
            rect(sx + i * 3, sy + j * 3, 3, 3, j < 4 ? C_YEL : RGB(255, 170, 70));
        }
    }
    text_c(320, 68, "Gestión de equipos ciclistas profesionales", C_TEXT);
    int bx = 240, bw = 160;
    if (btn(bx, 100, bw, 18, "NUEVA PARTIDA", RGB(60, 110, 70))) { game_new(0); g_scr = SC_TEAMSEL; teamsel_sel = 0; teamsel_cat = 0; teamsel_scroll = 0; }
    if (btn_en(bx, 122, bw, 18, "CONTINUAR", RGB(60, 80, 130), has_save())) {
        if (load_game(SAVE_PATH)) { g_scr = SC_HUB; tab = 0; toast("Partida cargada."); } else toast("No se pudo cargar la partida.");
    }
    if (btn(bx, 144, bw, 18, "SALIR", RGB(120, 60, 60))) quit_flag = 1;
    text_c(320, 176, "Datos: ciclistas temporada 2024, rutas Tour/Giro/Vuelta 2026 (GPX)", C_DIM);
}

static int cat_teams[MAX_TEAMS];
static int cat_list(int cat) { int n = 0; for (int t = 0; t < G.nteams; t++) if (G.teams[t].cat == cat) cat_teams[n++] = t; return n; }

static void teamsel_draw(void) {
    clear(C_BG);
    win(2, 2, 636, 356, "ELIGE TU EQUIPO");
    static const char *cn[4] = { "WorldTour", "ProTeam", "Continental", "Sub-23" };
    for (int c = 0; c < 4; c++) if (btn(8 + c * 86, 16, 82, 14, cn[c], c == teamsel_cat ? RGB(80, 110, 190) : C_PANEL2)) { teamsel_cat = c; teamsel_scroll = 0; teamsel_sel = 0; }
    text(360, 20, "Cuanto más pequeño, más difícil y más libertad.", C_DIM);
    int n = cat_list(teamsel_cat);
    int rows = 25;
    if (IN.wheel) teamsel_scroll -= IN.wheel * 3;
    if (teamsel_scroll > n - rows) teamsel_scroll = n - rows; if (teamsel_scroll < 0) teamsel_scroll = 0;
    rect(8, 34, 300, 318, C_PANEL2);
    for (int i = 0; i < rows && i + teamsel_scroll < n; i++) {
        int t = cat_teams[i + teamsel_scroll]; int y = 36 + i * 12;
        int on = (t == teamsel_sel);
        if (on || hit(10, y, 296, 12)) rect(10, y, 296, 12, on ? C_PANEL3 : col_mix(C_PANEL2, C_PANEL3, 120));
        if (hit(10, y, 296, 12) && IN.click) teamsel_sel = t;
        chip(14, y + 2, t);
        text_fit(26, y + 2, 200, TEAMS[t].name, on ? C_YEL : C_TEXT);
        textf(248, y + 2, C_CYN, "REP %d", G.teams[t].rep);
        textf(290 - 6, y + 2, C_DIM, " ");
    }
    /* detalle */
    int t = teamsel_sel;
    if (G.teams[t].cat != teamsel_cat) { int nn = cat_list(teamsel_cat); if (nn) t = cat_teams[0]; teamsel_sel = t; }
    win(314, 34, 318, 318, "Ficha del equipo");
    chip(322, 50, t); text(334, 50, TEAMS[t].name, C_YEL);
    textf(322, 64, C_TEXT, "Categoría: %s   País: %s", cat_name(G.teams[t].cat), country_name(TEAMS[t].country));
    textf(322, 76, C_TEXT, "Reputación: %d   Nivel plantilla: %d", G.teams[t].rep, team_ovr(t));
    bar(322, 88, 120, 6, G.teams[t].rep, C_CYN);
    textf(322, 100, C_TEXT, "Ciclistas: %d   Patrocinio: %s/año", team_size(t), money_str(G.teams[t].sponsor));
    textf(322, 112, C_TEXT, "Masa salarial: %s   Tope: %s", money_str(team_payroll(t)), money_str(wage_cap(t)));
    textf(322, 124, C_TEXT, "Caja inicial: %s", money_str(G.teams[t].cash));
    const char *desc = G.teams[t].cat == CAT_WT ? "Obligado a correr las carreras WorldTour. Tour, Giro y Vuelta garantizados."
        : (G.teams[t].cat == CAT_PRO ? "Entras por invitación a Grandes Vueltas y WT según tu reputación."
        : (G.teams[t].cat == CAT_CONTI ? "Solo carreras ProSeries por invitación y alguna clásica local." : "Equipo de desarrollo: pocas carreras, gran margen de crecimiento."));
    text_wrap(322, 140, 304, desc, C_DIM, 4);
    text(322, 180, "Mejores corredores:", C_TEXT);
    short rs[40]; int nr = team_roster(t, rs, 40);
    for (int i = 0; i < nr; i++) for (int j = i + 1; j < nr; j++) if (G.riders[rs[j]].level > G.riders[rs[i]].level) { short tmp = rs[i]; rs[i] = rs[j]; rs[j] = tmp; }
    for (int i = 0; i < 8 && i < nr; i++) {
        Rider *r = &G.riders[rs[i]];
        textf(322, 192 + i * 11, C_TEXT, "%-22.22s", r->name);
        textf(450, 192 + i * 11, val_col(r->level), "%d", r->level);
        textf(474, 192 + i * 11, C_DIM, "%s", type_name(r->type));
        textf(560, 192 + i * 11, C_DIM, "%d años", age_of(r));
    }
    if (btn(322, 322, 150, 22, "FICHAR POR ESTE EQUIPO", RGB(60, 120, 70))) { game_new(t); g_scr = SC_HUB; tab = 0; sel_rider = 0; }
    if (btn(478, 322, 70, 22, "Atrás", RGB(120, 60, 60))) g_scr = SC_MENU;
}

/* ---------------------------------------------------------------- barra superior e inferior */
static const char *TABN[7] = { "INICIO", "PLANTILLA", "FICHAJES", "CALENDARIO", "EQUIPO", "BUZÓN", "RANKING" };

static int unread(void) { int n = 0; for (int i = 0; i < G.nmsg; i++) if (G.inbox[i].unread) n++; return n; }

static void hub_top(void) {
    rect(0, 0, SW, 17, C_PANEL2); rect(0, 17, SW, 1, C_LINE_D);
    for (int i = 0; i < 7; i++) {
        char lab[24]; if (i == 5 && unread()) snprintf(lab, sizeof lab, "BUZÓN (%d)", unread()); else snprintf(lab, sizeof lab, "%s", TABN[i]);
        if (btn(2 + i * 66, 1, 65, 15, lab, i == tab ? RGB(90, 120, 200) : C_PANEL3)) { tab = i; if (i == 2) mkt_n = -1; }
    }
    chip(470, 5, G.player);
    textf(480, 5, C_YEL, "%s", day_long(G.day));
    textf(572, 5, G.teams[G.player].cash < 0 ? C_RED : C_GRN, "%s", money_str(G.teams[G.player].cash));
}

static void do_advance(int to_event);

static void hub_bottom(void) {
    rect(0, 344, SW, 16, C_PANEL2); rect(0, 344, SW, 1, C_LINE_D);
    if (btn(430, 346, 100, 12, "AVANZAR DÍA ▶", RGB(70, 130, 80))) do_advance(0);
    if (btn(534, 346, 100, 12, "HASTA EVENTO ▶▶", RGB(70, 100, 150))) do_advance(1);
    if (btn(330, 346, 96, 12, "Guardar", C_PANEL3)) { if (save_game(SAVE_PATH)) toast("Partida guardada."); else toast("Error al guardar."); }
    if (btn(250, 346, 76, 12, "Menú", C_PANEL3)) g_scr = SC_MENU;
    if (toast_t > 0) text(6, 349, toast_txt, C_YEL);
    else text(6, 349, "Espacio: avanzar día", C_DIM);
}

static void do_advance(int to_event) {
    int start_unread = unread();
    for (int step = 0; step < (to_event ? 45 : 1); step++) {
        if (player_has_race_today()) { race_enter(); return; }
        if (G.day == 364 && !to_event) {}
        game_advance_day();
        if (to_event) {
            if (unread() > start_unread) break;
            if (player_has_race_today()) { race_enter(); return; }
            /* parar el dia antes de una carrera propia sin equipo */
            for (int r = 0; r < RACE_COUNT; r++) {
                RaceEntry *e = &G.entry[r];
                if (G.day == RACES[r].first_day - 1 && (e->pstatus == PS_OBLIGATORIA || e->pstatus == PS_INVITADA || e->pstatus == PS_INSCRITA)) { toast("Mañana empieza %s.", RACES[r].name); return; }
            }
        }
    }
    if (player_has_race_today()) race_enter();
}

/* ---------------------------------------------------------------- INICIO */
static void home_draw(void) {
    Team *t = &G.teams[G.player];
    win(2, 20, 250, 150, "Mi equipo");
    chip(8, 34, G.player); text(20, 34, TEAMS[G.player].name, C_YEL);
    textf(8, 48, C_TEXT, "%s · %s", cat_name(t->cat), country_name(TEAMS[G.player].country));
    textf(8, 60, C_TEXT, "Reputación"); bar(70, 60, 100, 6, t->rep, C_CYN); textf(176, 60, C_TEXT, "%d", t->rep);
    textf(8, 72, C_TEXT, "Directiva "); bar(70, 72, 100, 6, t->board, t->board > 50 ? C_GRN : C_RED); textf(176, 72, C_TEXT, "%d%%", t->board);
    textf(8, 86, C_TEXT, "Caja: %s", money_str(t->cash));
    textf(8, 98, C_TEXT, "Masa salarial: %s / %s", money_str(team_payroll(G.player)), money_str(wage_cap(G.player)));
    textf(8, 110, C_TEXT, "Plantilla: %d ciclistas   Nivel: %d", team_size(G.player), team_ovr(G.player));
    textf(8, 124, C_CYN, "Objetivo: top %d ranking y %d victorias", G.season_obj_rank, G.season_obj_wins);
    textf(8, 136, C_TEXT, "Ahora: puesto %d (%u pts), %d victorias", player_rank(), t->pts, t->wins);
    short rs[40]; int n = team_roster(G.player, rs, 40); int inj = 0, tired = 0;
    for (int i = 0; i < n; i++) { if (G.riders[rs[i]].inj_days > 0) inj++; if (G.riders[rs[i]].fatigue > 70) tired++; }
    textf(8, 150, inj ? C_RED : C_DIM, "Lesionados: %d   Fatigados: %d", inj, tired);

    win(256, 20, 382, 150, "Próximas carreras");
    int k = 0;
    for (int d = 0; d < 365 && k < 9; d++) {
        for (int r = 0; r < RACE_COUNT; r++) {
            if (RACES[r].first_day != G.day + d) continue;
            if (k >= 9) break;
            RaceEntry *e = &G.entry[r];
            const char *st = "—"; Col c = C_DIM;
            switch (e->pstatus) {
                case PS_OBLIGATORIA: st = e->squad_n ? "Equipo listo" : "Elegir equipo"; c = e->squad_n ? C_GRN : C_ORG; break;
                case PS_INVITADA: case PS_INSCRITA: st = e->squad_n ? "Equipo listo" : "Elegir equipo"; c = e->squad_n ? C_GRN : C_ORG; break;
                case PS_SOLICITABLE: st = "Solicitar invitación"; c = C_YEL; break;
                case PS_SOLICITADA: st = "Invitación pendiente"; c = C_CYN; break;
                case PS_RECHAZADA: st = "No invitado"; c = C_RED; break;
                case PS_OPCIONAL: st = "Opcional"; c = C_YEL; break;
                case PS_NONE: st = "No elegible"; c = C_DIM; break;
            }
            int y = 34 + k * 14;
            textf(262, y, C_DIM, "%-6s", day_str(RACES[r].first_day));
            textf(302, y, C_DIM, "en %3dd", d);
            text_fit(346, y, 168, RACES[r].name, C_TEXT);
            text(520, y, st, c);
            k++;
        }
    }
    if (!k) text(262, 40, "No quedan carreras esta temporada.", C_DIM);

    win(2, 174, 316, 166, "Noticias del pelotón");
    for (int i = 0; i < G.nnews; i++) text_fit(8, 190 + i * 22, 304, G.news[G.nnews - 1 - i], C_TEXT);
    if (!G.nnews) text(8, 192, "Sin noticias todavía.", C_DIM);

    win(322, 174, 316, 166, "Buzón reciente");
    for (int i = 0; i < 6 && i < G.nmsg; i++) {
        Msg *m = &G.inbox[i];
        int y = 190 + i * 24;
        if (hit(326, y, 308, 22) && IN.click) { tab = 5; sel_msg = i; }
        textf(328, y, m->unread ? C_YEL : C_DIM, "%s %s", day_str(m->day), m->title);
        text_fit(328, y + 10, 300, m->body, m->unread ? C_TEXT : C_DIM);
    }
}

/* ---------------------------------------------------------------- listas y ficha de ciclista */
static void attr_panel(int x, int y, int ri, int fog) {
    Rider *r = &G.riders[ri];
    for (int a = 0; a < A_COUNT; a++) {
        int v = fog ? rider_attr_seen(r, a, 0) : r->a[a];
        textf(x, y + a * 10, C_TEXT, "%s", attr_name(a));
        bar(x + 84, y + a * 10 + 1, 80, 6, v, val_col(v));
        textf(x + 170, y + a * 10, val_col(v), "%d", v);
    }
}

static void rider_head(int x, int y, int ri) {
    Rider *r = &G.riders[ri];
    chip(x, y, r->team >= 0 ? r->team : -1);
    text(x + 10, y, r->name, C_YEL);
    textf(x, y + 12, C_TEXT, "%d años · %s · %s", age_of(r), country_name(r->country), type_name(r->type));
    textf(x, y + 23, C_TEXT, "Nivel %d (pot. %d) · Rep. %d", r->level, r->pot, r->rep);
}

static void squad_draw(void) {
    short rs[40]; int n = team_roster(G.player, rs, 40);
    for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) if (G.riders[rs[j]].level > G.riders[rs[i]].level) { short tmp = rs[i]; rs[i] = rs[j]; rs[j] = tmp; }
    if (sel_rider >= n) sel_rider = n - 1; if (sel_rider < 0) sel_rider = 0;
    char title[64]; snprintf(title, sizeof title, "Plantilla (%d)", n);
    win(2, 20, 380, 322, title);
    text(8, 33, "Nombre", C_DIM); text(104, 33, "Ed", C_DIM); text(120, 33, "Tipo", C_DIM); text(180, 33, "Niv", C_DIM);
    text(202, 33, "Forma", C_DIM); text(238, 33, "Fat.", C_DIM); text(274, 33, "Mor.", C_DIM); text(310, 33, "Contrato", C_DIM);
    int rows = 26;
    if (hit(2, 20, 380, 322)) scr_squad -= IN.wheel * 2;
    if (scr_squad > n - rows) scr_squad = n - rows; if (scr_squad < 0) scr_squad = 0;
    for (int i = 0; i < rows && i + scr_squad < n; i++) {
        int idx = i + scr_squad; Rider *r = &G.riders[rs[idx]]; int y = 43 + i * 11;
        int on = idx == sel_rider;
        if (on) rect(4, y - 1, 376, 11, C_PANEL3); else if (hit(4, y - 1, 376, 11)) rect(4, y - 1, 376, 11, C_PANEL2);
        if (hit(4, y - 1, 376, 11) && IN.click) sel_rider = idx;
        text_fit(8, y, 94, r->name, r->inj_days > 0 ? C_RED : (on ? C_YEL : C_TEXT));
        textf(104, y, C_DIM, "%d", age_of(r));
        text_fit(120, y, 58, type_name(r->type), C_DIM);
        textf(180, y, val_col(r->level), "%d", r->level);
        bar(202, y + 1, 30, 6, r->form, C_GRN);
        bar(238, y + 1, 30, 6, r->fatigue, r->fatigue > 70 ? C_RED : C_ORG);
        bar(274, y + 1, 30, 6, r->happy, r->happy < 40 ? C_RED : C_CYN);
        if (r->inj_days > 0) textf(310, y, C_RED, "LES %dd", r->inj_days);
        else textf(310, y, r->contract_end <= G.year ? C_ORG : C_DIM, "%02d %s", r->contract_end % 100, money_str(r->salary));
    }
    if (n == 0) return;
    int ri = rs[sel_rider]; Rider *r = &G.riders[ri];
    win(386, 20, 252, 322, "Ficha");
    rider_head(392, 34, ri);
    attr_panel(392, 70, ri, 0);
    int y = 212;
    textf(392, y, C_TEXT, "Salario: %s  hasta %d", money_str(r->salary), r->contract_end);
    textf(392, y + 10, C_TEXT, "Valor de mercado: %s", money_str(r->value));
    textf(392, y + 20, C_TEXT, "Rol pref.: %s%s", role_name(r->role_pref), r->wants_leader ? " (quiere liderar)" : "");
    textf(392, y + 30, r->happy < 40 ? C_RED : C_TEXT, "Moral %d%%   Forma %d   Fatiga %d", r->happy, r->form, r->fatigue);
    textf(392, y + 40, C_TEXT, "Carreras: %d días   Victorias: %d", r->race_days, r->wins);
    for (int p = 0; p < 2; p++) if (r->prom[p].kind && r->prom[p].done != 1) {
        const char *pn = r->prom[p].kind == PROM_GRANVUELTA ? "Correr una Gran Vuelta" : (r->prom[p].kind == PROM_LIDER ? "Ser líder en carrera WT" : "Días de carrera");
        textf(392, y + 50 + p * 10, r->prom[p].done == 2 ? C_RED : C_ORG, "Promesa: %s", pn);
    }
    text(392, y + 74, "Entreno:", C_DIM);
    if (btn(392 + 52, y + 72, 100, 11, train_name(r->train), C_PANEL3)) rider_set_train(ri, (r->train + 1) % TR_COUNT);
    if (btn(392, y + 90, 76, 14, "Renovar", RGB(60, 110, 70))) neg_open(ri, 1);
    if (btn(472, y + 90, 76, 14, "Liberar", RGB(130, 60, 60))) {
        if (team_size(G.player) > 20) { rider_release(ri); toast("%s liberado (indemnización pagada).", r->name); }
        else toast("Plantilla mínima: no puedes liberar más.");
    }
}

/* ---------------------------------------------------------------- FICHAJES */
static int mk_key(const Rider *r) { return mkt_sort == 0 ? rider_ovr(r) * 100 + r->pot : (mkt_sort == 1 ? r->pot * 100 + rider_ovr(r) : -age_of(r) * 100 + rider_ovr(r)); }
static int cmp_mk(const void *a, const void *b) { return mk_key(&G.riders[*(const short *)b]) - mk_key(&G.riders[*(const short *)a]); }
static void mkt_rebuild(void) {
    mkt_n = 0;
    for (int i = 0; i < G.nriders; i++) {
        Rider *r = &G.riders[i]; if (r->retired || r->team == G.player) continue;
        if (mkt_filter == 0 && r->team != -1) continue;
        if (mkt_filter == 2 && !(age_of(r) <= 23 && r->pot >= r->level + 5)) continue;
        if (mkt_filter == 3 && !r->shortlist) continue;
        if (mkt_filter == 4 && !(r->team >= 0 && r->contract_end <= G.year)) continue;
        mkt_list[mkt_n++] = (short)i;
    }
    qsort(mkt_list, mkt_n, sizeof(short), cmp_mk);
    if (sel_mkt >= mkt_n) sel_mkt = -1;
}

static void market_draw(void) {
    if (mkt_n < 0) mkt_rebuild();
    static const char *fn[5] = { "Libres", "Todos", "Promesas", "Seguidos", "Vencen" };
    for (int f = 0; f < 5; f++) if (btn(2 + f * 64, 20, 62, 13, fn[f], f == mkt_filter ? RGB(80, 110, 190) : C_PANEL2)) { mkt_filter = f; mkt_rebuild(); scr_mkt = 0; }
    static const char *sn[3] = { "Orden: nivel", "Orden: potencial", "Orden: joven" };
    if (btn(326, 20, 100, 13, sn[mkt_sort], C_PANEL3)) { mkt_sort = (mkt_sort + 1) % 3; mkt_rebuild(); }
    char title[64]; snprintf(title, sizeof title, "Mercado (%d)", mkt_n);
    win(2, 36, 424, 306, title);
    text(8, 49, "Nombre", C_DIM); text(104, 49, "Ed", C_DIM); text(120, 49, "Tipo", C_DIM); text(180, 49, "Niv", C_DIM); text(204, 49, "Pot", C_DIM);
    text(228, 49, "Equipo", C_DIM); text(270, 49, "Valor", C_DIM); text(340, 49, "Contr.", C_DIM);
    int rows = 24;
    if (hit(2, 36, 424, 306)) scr_mkt -= IN.wheel * 2;
    if (scr_mkt > mkt_n - rows) scr_mkt = mkt_n - rows; if (scr_mkt < 0) scr_mkt = 0;
    for (int i = 0; i < rows && i + scr_mkt < mkt_n; i++) {
        int idx = i + scr_mkt; Rider *r = &G.riders[mkt_list[idx]]; int y = 59 + i * 11;
        int on = idx == sel_mkt;
        if (on) rect(4, y - 1, 420, 11, C_PANEL3); else if (hit(4, y - 1, 420, 11)) rect(4, y - 1, 420, 11, C_PANEL2);
        if (hit(4, y - 1, 420, 11) && IN.click) sel_mkt = idx;
        text_fit(8, y, 94, r->name, on ? C_YEL : C_TEXT);
        textf(104, y, C_DIM, "%d", age_of(r));
        text_fit(120, y, 58, type_name(r->type), C_DIM);
        int ov = r->level + (int)((hash32(mkt_list[idx]) % 3) - 1) * (100 - r->seen) / 40;
        textf(180, y, val_col(ov), "%d", ov);
        if (r->seen > 55) textf(204, y, val_col(r->pot), "%d", r->pot); else text(204, y, "?", C_DIM);
        if (r->team >= 0) text(228, y, TEAMS[r->team].abbr, C_TEXT); else text(228, y, "LIBRE", C_GRN);
        text(270, y, money_str(r->value), C_TEXT);
        if (r->team >= 0) textf(340, y, C_DIM, "%d", r->contract_end);
        if (r->shortlist) text(400, y, "\x08", C_YEL);
    }
    if (sel_mkt >= 0 && sel_mkt < mkt_n) {
        int ri = mkt_list[sel_mkt]; Rider *r = &G.riders[ri];
        win(430, 36, 208, 306, "Ficha del ciclista");
        rider_head(436, 50, ri);
        textf(436, 76, C_DIM, "Ojeo: %d%%  (los datos son estimados)", r->seen);
        attr_panel(436, 88, ri, 1);
        int y = 232;
        textf(436, y, C_TEXT, "Equipo: %s", r->team >= 0 ? TEAMS[r->team].name : "Agente libre");
        textf(436, y + 10, C_TEXT, "Valor: %s  Contrato: %d", money_str(r->value), r->contract_end);
        int ask; contract_expected_salary(r, G.player, r->role_pref, 2, &ask);
        textf(436, y + 20, C_TEXT, "Pide aprox. %s/año", money_str(ask));
        textf(436, y + 30, r->rep > G.teams[G.player].rep + 14 ? C_RED : C_GRN, "Rep. %d vs tu equipo %d", r->rep, G.teams[G.player].rep);
        if (btn(436, y + 46, 94, 14, "Ojear (5 k)", C_PANEL3)) { if (G.teams[G.player].cash >= 5000) { G.teams[G.player].cash -= 5000; r->seen = (unsigned char)(r->seen + 25 > 100 ? 100 : r->seen + 25); } }
        if (btn(534, y + 46, 98, 14, r->shortlist ? "Dejar de seguir" : "Seguir", C_PANEL3)) r->shortlist ^= 1;
        if (btn(436, y + 66, 196, 18, "HACER OFERTA", RGB(60, 120, 70))) neg_open(ri, 0);
    } else {
        win(430, 36, 208, 306, "Ficha del ciclista");
        text_wrap(436, 54, 196, "Selecciona un ciclista de la lista. Ojear mejora la precisión de sus atributos. Los ciclistas de mayor reputación que tu equipo pueden rechazarte.", C_DIM, 6);
    }
}

/* ---------------------------------------------------------------- modal de negociacion */
static void neg_draw(void) {
    if (!neg.on) return;
    Rider *r = &G.riders[neg.ri];
    rect(0, 0, SW, SH, RGB(0, 0, 0)); /* oscurece */
    for (int y = 0; y < SH; y++) for (int x = (y & 1); x < SW; x += 2) px(x, y, C_BG);
    int x = 120, y = 50, w = 400, h = 258;
    win(x, y, w, h, neg.renewal ? "Renovación de contrato" : "Negociación de fichaje");
    rider_head(x + 8, y + 16, neg.ri);
    int yy = y + 56;
    textf(x + 8, yy, C_TEXT, "Pide aprox.: %s/año   Valor: %s", money_str(neg.ask), money_str(r->value));
    yy += 14;
    text(x + 8, yy, "Salario/año", C_TEXT);
    int step = IN.shift ? 50000 : 10000;
    if (btn(x + 120, yy - 2, 14, 12, "-", C_PANEL3)) { neg.salary -= step; if (neg.salary < 40000) neg.salary = 40000; }
    textf(x + 140, yy, C_YEL, "%s", money_str(neg.salary));
    if (btn(x + 262, yy - 2, 14, 12, "+", C_PANEL3)) neg.salary += step;
    yy += 16;
    text(x + 8, yy, "Años", C_TEXT);
    if (btn(x + 120, yy - 2, 14, 12, "-", C_PANEL3)) { if (neg.years > 1) neg.years--; }
    textf(x + 144, yy, C_YEL, "%d (hasta %d)", neg.years, G.year + neg.years - 1);
    if (btn(x + 262, yy - 2, 14, 12, "+", C_PANEL3)) { if (neg.years < 4) neg.years++; }
    yy += 16;
    text(x + 8, yy, "Rol prometido", C_TEXT);
    if (btn(x + 120, yy - 2, 156, 12, role_name(neg.role), C_PANEL3)) neg.role = (neg.role % (ROLE_COUNT - 1)) + 1;
    yy += 16;
    if (!neg.renewal && r->team >= 0) {
        text(x + 8, yy, "Traspaso", C_TEXT);
        if (btn(x + 120, yy - 2, 14, 12, "-", C_PANEL3)) { neg.fee -= 50000; if (neg.fee < 0) neg.fee = 0; }
        textf(x + 140, yy, C_YEL, "%s", money_str(neg.fee));
        if (btn(x + 262, yy - 2, 14, 12, "+", C_PANEL3)) neg.fee += 50000;
        yy += 16;
    }
    if (btn(x + 8, yy - 2, 12, 12, neg.promise ? "\x06" : " ", C_PANEL3)) neg.promise ^= 1;
    text(x + 26, yy, "Prometer plaza en una Gran Vuelta (+8% de aceptación)", C_TEXT);
    yy += 16;
    textf(x + 8, yy, C_DIM, "Masa salarial tras fichar: %s / tope %s", money_str(team_payroll(G.player) + neg.salary - (neg.renewal ? r->salary : 0)), money_str(wage_cap(G.player)));
    yy += 12;
    textf(x + 8, yy, C_DIM, "Caja: %s", money_str(G.teams[G.player].cash));
    yy += 14;
    if (neg.msg[0]) text_wrap(x + 8, yy, w - 16, neg.msg, neg.code == 0 ? C_GRN : C_ORG, 3);
    int by = y + h - 24;
    if (btn(x + 8, by, 120, 18, "ENVIAR OFERTA", RGB(60, 120, 70))) {
        int eff_sal = neg.promise ? (int)(neg.salary * 1.08f) : neg.salary;
        int chk = sign_cost_check(neg.ri, neg.salary, neg.renewal ? 0 : neg.fee);
        if (chk == 1) { snprintf(neg.msg, sizeof neg.msg, "Plantilla completa: libera a alguien antes."); neg.code = 9; }
        else if (chk == 2) { snprintf(neg.msg, sizeof neg.msg, "No tienes caja para el traspaso."); neg.code = 9; }
        else if (chk == 3) { snprintf(neg.msg, sizeof neg.msg, "Superas el tope salarial de la directiva."); neg.code = 9; }
        else {
            neg.code = offer_evaluate(neg.ri, G.player, eff_sal, neg.years, neg.role, neg.renewal ? 0 : neg.fee, neg.msg, sizeof neg.msg, 0);
            if (neg.code == 0) {
                offer_evaluate(neg.ri, G.player, neg.salary, neg.years, neg.role, neg.renewal ? 0 : neg.fee, neg.msg, sizeof neg.msg, 1);
                if (neg.promise) promise_add(neg.ri, PROM_GRANVUELTA, 1);
                toast("¡%s firmado!", r->name);
                neg.on = 0; mkt_n = -1;
            }
        }
    }
    if (btn(x + 136, by, 80, 18, "Cancelar", RGB(120, 60, 60))) neg.on = 0;
}

/* ---------------------------------------------------------------- CALENDARIO */
static int cmp_race_day(const void *a, const void *b) { return RACES[*(const int *)a].first_day - RACES[*(const int *)b].first_day; }

static const char *status_txt(RaceEntry *e, Col *c) {
    *c = C_DIM;
    switch (e->pstatus) {
        case PS_OBLIGATORIA: *c = e->squad_n ? C_GRN : C_ORG; return e->squad_n ? "Obligatoria · lista" : "Obligatoria · sin equipo";
        case PS_INVITADA: *c = e->squad_n ? C_GRN : C_ORG; return e->squad_n ? "Invitado · lista" : "Invitado · sin equipo";
        case PS_INSCRITA: *c = e->squad_n ? C_GRN : C_ORG; return "Inscrito";
        case PS_SOLICITABLE: *c = C_YEL; return "Solicitar invitación";
        case PS_SOLICITADA: *c = C_CYN; return "Solicitud enviada";
        case PS_RECHAZADA: *c = C_RED; return "No invitado";
        case PS_OPCIONAL: *c = C_YEL; return "Opcional";
        case PS_NONE: return "No elegible";
        case PS_CERRADA: return "Finalizada";
    }
    return "";
}

static void squad_modal(void) {
    if (!sqm.on) return;
    int race = sqm.race; RaceEntry *e = &G.entry[race]; const RaceDef *rd = &RACES[race];
    for (int y = 0; y < SH; y++) for (int x = (y & 1); x < SW; x += 2) px(x, y, C_BG);
    int x = 60, y = 24, w = 520, h = 310;
    char t[96]; snprintf(t, sizeof t, "Equipo para %s (%d corredores)", rd->name, rd->squad);
    win(x, y, w, h, t);
    short rs[40]; int n = team_roster(G.player, rs, 40);
    for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) if (G.riders[rs[j]].level > G.riders[rs[i]].level) { short tmp = rs[i]; rs[i] = rs[j]; rs[j] = tmp; }
    text(x + 8, y + 16, "Corredor", C_DIM); text(x + 130, y + 16, "Niv", C_DIM); text(x + 156, y + 16, "Forma", C_DIM); text(x + 190, y + 16, "Fatiga", C_DIM); text(x + 232, y + 16, "Rol", C_DIM); text(x + 300, y + 16, "Estado", C_DIM);
    int rows = 22;
    if (IN.wheel) sqm.scroll -= IN.wheel * 2;
    if (sqm.scroll > n - rows) sqm.scroll = n - rows; if (sqm.scroll < 0) sqm.scroll = 0;
    for (int i = 0; i < rows && i + sqm.scroll < n; i++) {
        int ri = rs[i + sqm.scroll]; Rider *r = &G.riders[ri]; int yy = y + 27 + i * 12;
        int pos = -1; for (int k = 0; k < e->squad_n; k++) if (e->squad[k] == ri) pos = k;
        int avail = rider_available(ri, race);
        if (pos >= 0) rect(x + 4, yy - 1, 400, 12, col_mix(C_PANEL, C_GRN, 60));
        if (btn_en(x + 6, yy, 10, 9, pos >= 0 ? "\x06" : " ", C_PANEL3, avail || pos >= 0)) {
            if (pos >= 0) { for (int m = pos; m + 1 < e->squad_n; m++) { e->squad[m] = e->squad[m + 1]; e->squad_role[m] = e->squad_role[m + 1]; } e->squad_n--; }
            else if (e->squad_n < rd->squad) { e->squad[e->squad_n] = (short)ri; e->squad_role[e->squad_n] = ROLE_GREGARIO; e->squad_n++; }
        }
        text_fit(x + 22, yy + 1, 106, r->name, avail ? C_TEXT : C_DIM);
        textf(x + 130, yy + 1, val_col(r->level), "%d", r->level);
        bar(x + 156, yy + 2, 28, 5, r->form, C_GRN); bar(x + 190, yy + 2, 28, 5, r->fatigue, r->fatigue > 70 ? C_RED : C_ORG);
        if (pos >= 0) { if (btn(x + 228, yy - 1, 66, 11, role_name(e->squad_role[pos]), C_PANEL3)) e->squad_role[pos] = (unsigned char)((e->squad_role[pos] + 1) % ROLE_COUNT); }
        if (r->inj_days > 0) textf(x + 300, yy + 1, C_RED, "Lesión %dd", r->inj_days);
        else if (!avail) text(x + 300, yy + 1, "Otra carrera", C_ORG);
        else if (r->fatigue > 70) text(x + 300, yy + 1, "Cansado", C_ORG);
    }
    textf(x + 416, y + 20, C_TEXT, "Seleccionados %d/%d", e->squad_n, rd->squad);
    if (btn(x + 416, y + 34, 96, 14, "Automático", RGB(60, 90, 140))) { e->pstatus = e->pstatus == PS_OPCIONAL ? PS_INSCRITA : e->pstatus; squad_auto(race); }
    char why[80]; int ok = squad_valid(race, why, sizeof why);
    text_wrap(x + 416, y + 56, 98, ok ? "Equipo válido." : why, ok ? C_GRN : C_ORG, 5);
    text_wrap(x + 416, y + 110, 98, "Líder: protegido en la montaña. Esprínter: se guarda para meta. Lanzador: tira del tren. Gregario: ayuda. Escapadista: ataca pronto.", C_DIM, 12);
    if (btn(x + 416, y + h - 40, 96, 16, "ACEPTAR", RGB(60, 120, 70))) { if (e->pstatus == PS_OPCIONAL && e->squad_n) e->pstatus = PS_INSCRITA; sqm.on = 0; }
}

static void cal_draw(void) {
    if (!race_order_n) { race_order_n = RACE_COUNT; for (int i = 0; i < RACE_COUNT; i++) race_order[i] = i; qsort(race_order, RACE_COUNT, sizeof(int), cmp_race_day); }
    win(2, 20, 316, 322, "Temporada");
    int rows = 28;
    if (hit(2, 20, 316, 322)) scr_cal -= IN.wheel * 2;
    if (scr_cal > race_order_n - rows) scr_cal = race_order_n - rows; if (scr_cal < 0) scr_cal = 0;
    static const char *tn[4] = { "GV", "MON", "WT", "PRO" };
    for (int i = 0; i < rows && i + scr_cal < race_order_n; i++) {
        int r = race_order[i + scr_cal]; int y = 34 + i * 11; RaceEntry *e = &G.entry[r];
        int on = r == sel_race_i;
        if (on) rect(4, y - 1, 312, 11, C_PANEL3); else if (hit(4, y - 1, 312, 11)) rect(4, y - 1, 312, 11, C_PANEL2);
        if (hit(4, y - 1, 312, 11) && IN.click) { sel_race_i = r; cal_stage = 0; }
        Col c; (void)status_txt(e, &c);
        rect(6, y + 1, 3, 7, c);
        textf(12, y, G.day > race_last_day(r) ? C_DIM : C_TEXT, "%-6s", day_str(RACES[r].first_day));
        text(54, y, tn[RACES[r].tier], RACES[r].tier <= 1 ? C_YEL : C_CYN);
        text_fit(82, y, 156, RACES[r].name, on ? C_YEL : C_TEXT);
        if (e->done) text(250, y, "\x06", C_GRN);
        else if (RACES[r].nstages > 1) textf(244, y, C_DIM, "%dd", RACES[r].nstages);
    }
    int r = sel_race_i; const RaceDef *rd = &RACES[r]; RaceEntry *e = &G.entry[r];
    win(322, 20, 316, 322, rd->name);
    Col sc; const char *st = status_txt(e, &sc);
    textf(328, 34, C_TEXT, "%s · %s", tier_name(rd->tier), country_name(rd->country));
    textf(328, 45, C_TEXT, "%s → %s · %d etapa%s · equipos de %d", day_str(rd->first_day), day_str(race_last_day(r)), rd->nstages, rd->nstages > 1 ? "s" : "", rd->squad);
    textf(328, 56, sc, "Estado: %s", st);
    /* requisitos */
    const char *req = rd->tier <= TIER_WT ? "Requisito: licencia WorldTour (obligatoria) o invitación a ProTeams." : "Requisito: ProSeries, abierta a ProTeam/Continental por invitación.";
    text_wrap(328, 67, 304, req, C_DIM, 2);
    if (e->inv_slots > 0 && G.teams[G.player].cat != CAT_WT) {
        textf(328, 85, C_TEXT, "Plazas de invitación: %d · tu puesto estimado: %d", e->inv_slots, e->rank_est);
        textf(328, 95, C_DIM, "Tu puntuación %d · corte %d (reputación + local + solicitud)", e->pscore, e->cutscore);
        textf(328, 105, C_DIM, "Anuncio de invitaciones: %s", day_str(race_cut_day(r)));
    }
    /* acciones */
    int ay = 118;
    if (e->pstatus == PS_SOLICITABLE && btn(328, ay, 130, 14, "Solicitar invitación", RGB(70, 110, 160))) { race_request_invite(r); toast("Solicitud enviada a la organización."); }
    if (e->pstatus == PS_OPCIONAL && btn(328, ay, 130, 14, "Inscribirse", RGB(60, 120, 70))) { squad_auto(r); toast("Inscrito con selección automática."); }
    if ((e->pstatus == PS_OBLIGATORIA || e->pstatus == PS_INVITADA || e->pstatus == PS_INSCRITA) && G.day <= rd->first_day) {
        if (btn(328, ay, 130, 14, "Elegir equipo", RGB(60, 120, 70))) { sqm.on = 1; sqm.race = r; sqm.scroll = 0; }
        if (e->pstatus != PS_OBLIGATORIA && btn(462, ay, 90, 14, "Renunciar", RGB(130, 60, 60))) { e->squad_n = 0; e->pstatus = rd->tier <= TIER_WT && G.teams[G.player].cat == CAT_WT ? PS_OPCIONAL : PS_RENUNCIA; }
    }
    if (e->squad_n) {
        textf(328, ay + 20, C_TEXT, "Equipo:");
        for (int i = 0; i < e->squad_n; i++) textf(328 + (i % 2) * 150, ay + 31 + (i / 2) * 10, C_TEXT, "%-4s %s", role_short(e->squad_role[i]), "");
        for (int i = 0; i < e->squad_n; i++) text_fit(352 + (i % 2) * 150, ay + 31 + (i / 2) * 10, 118, rider_name(e->squad[i]), C_TEXT);
    }
    /* etapas */
    int sy = 192;
    text(328, sy, "Etapas", C_YEL);
    int ns = rd->nstages;
    for (int i = 0; i < ns && i < 10; i++) {
        const StageDef *sd = &STAGES[rd->stage0 + i]; int y = sy + 11 + i * 9;
        if (i == cal_stage) rect(326, y - 1, 148, 9, C_PANEL3);
        if (hit(326, y - 1, 148, 9) && IN.click) cal_stage = i;
        textf(328, y, C_DIM, "%2d", sd->num);
        text(346, y, kind_name(sd->kind), sd->kind == K_MONTANA ? C_RED : (sd->kind == K_MEDIA ? C_ORG : (sd->kind >= K_CRI && sd->kind <= K_CRE ? C_CYN : C_GRN)));
        textf(430, y, C_DIM, "%.0fk", sd->dist_km);
    }
    if (cal_stage >= ns) cal_stage = 0;
    const StageDef *sd = &STAGES[rd->stage0 + cal_stage];
    draw_profile(478, 192, 156, 70, sd, NULL, 0);
    draw_map(478, 266, 156, 72, sd, NULL);
    textf(328, 306, C_TEXT, "%s → %s", sd->from, sd->to);
    textf(328, 318, C_DIM, "%.1f km · D+ %d m%s", sd->dist_km, sd->dplus, sd->est_profile ? " (perfil estimado)" : "");
    textf(328, 328, C_DIM, "%s", sd->est_map ? "Trazado del mapa estimado" : "Trazado GPX real");
}

/* ---------------------------------------------------------------- EQUIPO */
static void team_draw(void) {
    Team *t = &G.teams[G.player];
    win(2, 20, 380, 180, "Personal técnico");
    static const char *eff[STAFF_COUNT] = { "Mejora el entrenamiento y la forma", "Acelera lesiones y recuperación", "Más energía con avituallamiento", "Menos pinchazos y caídas", "Ojeo pasivo y datos de fichajes", "Mejor lectura de carrera" };
    for (int s = 0; s < STAFF_COUNT; s++) {
        int y = 36 + s * 26;
        textf(8, y, C_TEXT, "%s", staff_name(s));
        for (int k = 0; k < 5; k++) rect(106 + k * 12, y, 10, 8, k < t->staff[s] ? C_GRN : C_PANEL3);
        text(8, y + 11, eff[s], C_DIM);
        if (t->staff[s] < 5) {
            char lab[40]; snprintf(lab, sizeof lab, "Subir (%s)", money_str(staff_upgrade_cost(s, t->staff[s])));
            if (btn_en(240, y - 1, 136, 13, lab, RGB(60, 110, 70), t->cash >= staff_upgrade_cost(s, t->staff[s]))) staff_upgrade(s);
        } else text(240, y, "Nivel máximo", C_YEL);
    }
    win(386, 20, 252, 180, "Finanzas");
    int pay = team_payroll(G.player);
    int staff = 0; for (int s = 0; s < STAFF_COUNT; s++) staff += t->staff[s] * 55000;
    textf(392, 36, C_TEXT, "Caja actual: %s", money_str(t->cash));
    textf(392, 48, C_TEXT, "Patrocinio anual: %s", money_str(t->sponsor));
    textf(392, 60, C_TEXT, "Salarios anuales: %s", money_str(pay));
    textf(392, 72, C_TEXT, "Personal técnico: %s", money_str(staff));
    textf(392, 84, C_TEXT, "Tope salarial: %s", money_str(wage_cap(G.player)));
    textf(392, 96, team_budget_left(G.player) < 0 ? C_RED : C_GRN, "Margen: %s", money_str(team_budget_left(G.player)));
    textf(392, 112, C_TEXT, "Premios este año: %s", money_str(t->prize_year));
    textf(392, 124, C_TEXT, "Balance previsto/año: %s", money_str((long long)t->sponsor - pay - staff));
    text_wrap(392, 140, 240, "Los ingresos entran cada mes. Los gastos de viaje de carrera se descuentan por corredor y día.", C_DIM, 4);
    win(2, 204, 636, 138, "Directiva y objetivos");
    textf(8, 220, C_TEXT, "Confianza de la directiva"); bar(150, 220, 160, 7, t->board, t->board > 50 ? C_GRN : (t->board > 30 ? C_ORG : C_RED)); textf(316, 220, C_TEXT, "%d%%", t->board);
    textf(8, 236, C_TEXT, "Objetivo 1: terminar entre los %d primeros de tu categoría", G.season_obj_rank);
    textf(400, 236, player_rank() <= G.season_obj_rank ? C_GRN : C_ORG, "Ahora: puesto %d", player_rank());
    textf(8, 248, C_TEXT, "Objetivo 2: conseguir %d victorias", G.season_obj_wins);
    textf(400, 248, t->wins >= G.season_obj_wins ? C_GRN : C_ORG, "Ahora: %d", t->wins);
    text_wrap(8, 268, 620, "Cumplir ambos objetivos sube el patrocinio un 12% el año siguiente. Fallar ambos lo reduce y puede costarte la confianza. Las victorias y los podios de tus ciclistas aumentan la reputación del equipo, lo que te permite fichar a mejores corredores y conseguir invitaciones.", C_DIM, 5);
}

/* ---------------------------------------------------------------- BUZON */
static void inbox_draw(void) {
    win(2, 20, 300, 322, "Mensajes");
    int rows = 28;
    if (scr_msg > G.nmsg - rows) scr_msg = G.nmsg - rows; if (scr_msg < 0) scr_msg = 0;
    if (hit(2, 20, 300, 322)) scr_msg -= IN.wheel * 2;
    for (int i = 0; i < rows && i + scr_msg < G.nmsg; i++) {
        int idx = i + scr_msg; Msg *m = &G.inbox[idx]; int y = 34 + i * 11;
        if (idx == sel_msg) rect(4, y - 1, 296, 11, C_PANEL3); else if (hit(4, y - 1, 296, 11)) rect(4, y - 1, 296, 11, C_PANEL2);
        if (hit(4, y - 1, 296, 11) && IN.click) { sel_msg = idx; m->unread = 0; }
        if (m->unread) text(7, y, "\x05", C_YEL);
        textf(16, y, C_DIM, "%-6s", day_str(m->day));
        text_fit(56, y, 240, m->title, m->unread ? C_YEL : C_TEXT);
    }
    win(306, 20, 332, 322, "Lectura");
    if (G.nmsg == 0) { text(312, 40, "No hay mensajes.", C_DIM); return; }
    if (sel_msg >= G.nmsg) sel_msg = 0;
    Msg *m = &G.inbox[sel_msg]; m->unread = 0;
    textf(312, 34, C_YEL, "%s", m->title);
    textf(312, 46, C_DIM, "%s", day_str(m->day));
    text_wrap(312, 64, 318, m->body, C_TEXT, 12);
    if (m->rider >= 0 && G.riders[m->rider].team == G.player) {
        if (btn(312, 150, 120, 14, "Ver ciclista", C_PANEL3)) {
            short rs[40]; int n = team_roster(G.player, rs, 40);
            for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) if (G.riders[rs[j]].level > G.riders[rs[i]].level) { short tmp = rs[i]; rs[i] = rs[j]; rs[j] = tmp; }
            for (int i = 0; i < n; i++) if (rs[i] == m->rider) sel_rider = i;
            tab = 1;
        }
    }
}

/* ---------------------------------------------------------------- RANKING */
static int cmp_tpts(const void *a, const void *b) { return (int)G.teams[*(const int *)b].pts - (int)G.teams[*(const int *)a].pts; }
static int cmp_rpts(const void *a, const void *b) { return (int)G.riders[*(const short *)b].pts - (int)G.riders[*(const short *)a].pts; }
static void rank_draw(void) {
    if (btn(2, 20, 100, 13, rank_mode ? "Ver equipos" : "Ver ciclistas", C_PANEL3)) rank_mode ^= 1;
    static int tl[MAX_TEAMS]; static short rl[MAX_RIDERS];
    int nt = 0; for (int t = 0; t < G.nteams; t++) if (G.teams[t].cat == G.teams[G.player].cat || G.teams[t].cat <= CAT_PRO) tl[nt++] = t;
    qsort(tl, nt, sizeof(int), cmp_tpts);
    win(2, 36, 316, 306, "Ranking de equipos (temporada)");
    for (int i = 0; i < 26 && i < nt; i++) {
        int t = tl[i]; int y = 50 + i * 11;
        if (t == G.player) rect(4, y - 1, 312, 11, C_PANEL3);
        textf(8, y, C_DIM, "%2d", i + 1); chip(26, y, t);
        text_fit(38, y, 190, TEAMS[t].name, t == G.player ? C_YEL : C_TEXT);
        textf(240, y, C_CYN, "%u", G.teams[t].pts);
        textf(284, y, C_DIM, "%dV", G.teams[t].wins);
    }
    int nr = 0; for (int i = 0; i < G.nriders; i++) if (!G.riders[i].retired && G.riders[i].pts > 0) rl[nr++] = (short)i;
    qsort(rl, nr, sizeof(short), cmp_rpts);
    win(322, 36, 316, 306, "Ranking de ciclistas (puntos UCI)");
    for (int i = 0; i < 26 && i < nr; i++) {
        Rider *r = &G.riders[rl[i]]; int y = 50 + i * 11;
        if (r->team == G.player) rect(324, y - 1, 312, 11, C_PANEL3);
        textf(328, y, C_DIM, "%2d", i + 1); if (r->team >= 0) chip(346, y, r->team);
        text_fit(358, y, 150, r->name, r->team == G.player ? C_YEL : C_TEXT);
        text(512, y, r->team >= 0 ? TEAMS[r->team].abbr : "---", C_DIM);
        textf(552, y, C_CYN, "%u", r->pts);
        textf(596, y, C_DIM, "%dV", r->wins > 99 ? 99 : r->wins);
    }
    if (!nr) text(330, 56, "Aún no hay puntos: empieza la temporada.", C_DIM);
}

/* ---------------------------------------------------------------- bucle de pantallas */
static void hub_draw(void) {
    clear(C_BG);
    hub_top();
    switch (tab) {
        case 0: home_draw(); break;
        case 1: squad_draw(); break;
        case 2: market_draw(); break;
        case 3: cal_draw(); break;
        case 4: team_draw(); break;
        case 5: inbox_draw(); break;
        case 6: rank_draw(); break;
    }
    hub_bottom();
    if (neg.on) neg_draw();
    if (sqm.on) squad_modal();
    if (!neg.on && !sqm.on && key_pressed(VK_SPACE_)) do_advance(0);
}

void hub_after_race(void) { game_advance_day(); g_scr = SC_HUB; if (player_has_race_today()) race_enter(); }

void ui_init(void) { gfx_init(); g_scr = SC_MENU; }
int ui_wants_quit(void) { return quit_flag; }

void ui_frame(float dt) {
    anim_t += dt;
    if (toast_t > 0) toast_t -= dt;
    switch (g_scr) {
        case SC_MENU: menu_draw(); break;
        case SC_TEAMSEL: teamsel_draw(); break;
        case SC_HUB: hub_draw(); break;
        case SC_PREP: prep_draw(); break;
        case SC_RACE: race_draw(dt); break;
        case SC_RESULT: result_draw(); break;
    }
    if (toast_t > 0 && g_scr != SC_HUB) { int w = text_w(toast_txt) + 12; rect(320 - w / 2, 330, w, 14, C_BLK); box(320 - w / 2, 330, w, 14, C_LINE); text_c(320, 334, toast_txt, C_YEL); }
}

void ui_debug_goto(const char *what) {
    if (!strncmp(what, "hub", 3)) {
        game_new(12); g_scr = SC_HUB; tab = what[3] ? what[3] - '0' : 0;
        if (tab == 3) { sel_race_i = 7; }
        if (tab == 2) { mkt_n = -1; }
        if (tab == 5) sel_msg = 0;
        if (G.day == 0) for (int i = 0; i < 40; i++) game_advance_day();
    } else if (!strcmp(what, "menu")) g_scr = SC_MENU;
    else if (!strcmp(what, "teamsel")) { game_new(0); g_scr = SC_TEAMSEL; }
    else if (!strcmp(what, "neg")) { game_new(12); g_scr = SC_HUB; tab = 2; mkt_n = -1; mkt_filter = 1; mkt_rebuild(); sel_mkt = 3; neg_open(mkt_list[3], 0); }
    else if (!strcmp(what, "squadm")) { game_new(12); g_scr = SC_HUB; tab = 3; sel_race_i = 0; squad_auto(0); sqm.on = 1; sqm.race = 0; }
    else if (!strcmp(what, "prep") || !strcmp(what, "race") || !strcmp(what, "result")) {
        game_new(12);
        /* saltar al primer dia de carrera con el jugador */
        for (int k = 0; k < 120 && !player_has_race_today(); k++) game_advance_day();
        g_scr = SC_HUB;
        if (player_has_race_today()) race_enter();
        if (!strcmp(what, "race")) race_debug_start(1);
        if (!strcmp(what, "result")) race_debug_start(0);
    }
}
