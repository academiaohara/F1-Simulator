$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
& "$root\build_windows.ps1"
$release = Join-Path $root 'release\ciclismo_manager'
New-Item -ItemType Directory -Force -Path $release | Out-Null
Copy-Item "$root\ciclismo_manager.exe" $release -Force
Copy-Item "$root\README.md" $release -Force
Write-Host "Version portable creada en: $release"
