#!/usr/bin/env python3
"""
Incorpora la traza GPS y el perfil real de cada etapa a ciclismo_2026.sqlite.
Requiere conexión a Internet cuando se ejecuta en el ordenador del usuario.
Sin dependencias externas: Python 3.9+.

Ejemplos:
    python completar_gpx.py --solo tour-de-france
    python completar_gpx.py --solo giro-ditalia --limite 3
    python completar_gpx.py --enlaces
    python completar_gpx.py
    python completar_gpx.py --archivo mi_etapa.gpx --etapa-id 1
"""
import argparse
import math
import re
import sqlite3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'ciclismo_2026.sqlite'
GPX_DIR = ROOT / 'gpx_descargados'
HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; local-cycling-game/1.0)', 'Accept': 'text/html,application/gpx+xml,application/xml,*/*'}
MAIN_PAGE = 'https://www.cyclingstage.com/gpx-2026-pro-cycling-races/'

class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.current_href=None
        self.anchors=[]
        self.txt=[]
    def handle_starttag(self, tag, attrs):
        if tag=='a':
            self.current_href=dict(attrs).get('href')
            self.txt=[]
    def handle_data(self, data):
        if self.current_href is not None:
            self.txt.append(data)
    def handle_endtag(self, tag):
        if tag=='a' and self.current_href:
            self.anchors.append((self.current_href,' '.join(self.txt).strip()))
            self.current_href=None

def read_url(url, timeout=22):
    req=urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data=r.read(8_000_000)
    return data

def links_from_page(url):
    raw=read_url(url)
    p=LinkParser()
    p.feed(raw.decode('utf-8', 'replace'))
    unique={}
    for href,name in p.anchors:
        absolute=urllib.parse.urljoin(url,href)
        if urllib.parse.urlsplit(absolute).path.lower().endswith('.gpx'):
            unique.setdefault(absolute,name)
    return list(unique)

PATH_SLUG = {
 'tour-de-france':'tour-de-france',
 'giro-ditalia':'giro-italy',
 'vuelta-espana':'vuelta-spain',
}

def match_route_url(comp, number, candidates):
    slug=comp['slug']
    gender=comp['categoria']
    slug_base=slug.removesuffix('-women')
    route_slug=PATH_SLUG.get(slug,slug_base)
    path_key='/' + route_slug + '/2026/'
    matched=[u for u in candidates if path_key in urllib.parse.urlsplit(u).path]
    if comp['tipo']!='clásica':
        matched=[u for u in matched if re.search(r'/stage-'+str(number)+r'(?:-|\.)',urllib.parse.urlsplit(u).path)]
        return matched[0] if matched else None
    # Clásicas: separar fichas femeninas de las masculinas.
    female_pat=r'female|femmes|women|woman|donne|ladies|ladys|feminin'
    matched=[u for u in matched if bool(re.search(female_pat,u.lower()))==(gender=='F')]
    return matched[0] if matched else None


def sync_urls(conn, show=True):
    conn.row_factory=sqlite3.Row
    pages=[x[0] for x in conn.execute('SELECT DISTINCT fuente_gpx FROM competiciones WHERE fuente_gpx IS NOT NULL ORDER BY fuente_gpx')]
    found=[]
    for page in pages:
        try:
            links=links_from_page(page)
            found.extend(links)
            if show: print(f'Enlaces en {page}: {len(links)}')
        except (OSError,TimeoutError,ValueError) as ex:
            print(f'Aviso: no se pudo consultar {page}: {ex}',file=sys.stderr)
        time.sleep(.5)
    updated=0
    for st in conn.execute('''SELECT e.id,e.numero,c.slug,c.categoria,c.tipo,c.nombre
       FROM etapas e JOIN competiciones c ON c.id=e.competicion_id'''):
        url=match_route_url(st, st['numero'],found)
        if url:
            conn.execute('UPDATE etapas SET url_gpx=? WHERE id=?',(url,st['id']))
            updated+=1
    conn.commit()
    if show: print(f'Enlaces GPX localizados y actualizados: {updated}')
    return updated


def _localname(tag): return tag.rsplit('}',1)[-1]

def parse_gpx(raw):
    root=ET.fromstring(raw)
    pts=[]
    for node in root.iter():
        if _localname(node.tag)!='trkpt': continue
        try:
            lat=float(node.attrib['lat']);lon=float(node.attrib['lon'])
        except (ValueError,KeyError): continue
        alt=None
        for child in node:
            if _localname(child.tag)=='ele':
                try: alt=float(child.text)
                except (ValueError,TypeError): pass
                break
        pts.append((lat,lon,alt))
    if len(pts)<2:
        for node in root.iter():
            if _localname(node.tag)!='rtept': continue
            try: lat=float(node.attrib['lat']);lon=float(node.attrib['lon'])
            except (ValueError,KeyError): continue
            alt=None
            for child in node:
                if _localname(child.tag)=='ele':
                    try: alt=float(child.text)
                    except (ValueError,TypeError): pass
                    break
            pts.append((lat,lon,alt))
    if len(pts)<2: raise ValueError('Este GPX no contiene una ruta con al menos dos puntos GPS.')
    return pts

def haversine_km(a,b):
    lat1,lon1=math.radians(a[0]),math.radians(a[1])
    lat2,lon2=math.radians(b[0]),math.radians(b[1])
    s=math.sin((lat2-lat1)/2)**2+math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2
    return 12742*math.asin(min(1,math.sqrt(s)))

def interpolated(pts,step=.5):
    # Devuelve una muestra equidistante para el motor del videojuego.
    acc=0.
    last=pts[0]
    result=[(0.0,*last)]
    next_km=step
    for current in pts[1:]:
        seg=haversine_km(last,current)
        if seg==0:
            last=current
            continue
        while next_km<=acc+seg+1e-7:
            t=max(0,min(1,(next_km-acc)/seg))
            lat=last[0]+(current[0]-last[0])*t
            lon=last[1]+(current[1]-last[1])*t
            ele=None
            if last[2] is not None and current[2] is not None:
                ele=last[2]+(current[2]-last[2])*t
            result.append((round(next_km,3),lat,lon,ele))
            next_km+=step
        acc+=seg
        last=current
    if acc>result[-1][0]+1e-4:
        result.append((round(acc,3),*last))
    return result,acc

def calculate_gain(points):
    # Estimación: suavizado en ventana de 300 m y umbral vertical antirruido.
    h=[p[3] for p in points]
    if sum(x is not None for x in h)<len(h)*.7: return None
    smooth=[]
    for i in range(len(h)):
        near=[v for v in h[max(0,i-1):min(len(h),i+2)] if v is not None]
        smooth.append(sum(near)/len(near) if near else None)
    gain=0.
    for a,b in zip(smooth,smooth[1:]):
        if a is not None and b is not None and b-a>1.5:
            gain+=b-a
    return int(round(gain))

def import_gpx(conn,stage_id,raw):
    pts=parse_gpx(raw)
    sampled,km=interpolated(pts,.5)
    have_alt=sum(p[3] is not None for p in sampled)
    has_alt=have_alt>=max(2,int(len(sampled)*.70))
    # D+ se calcula con malla fina de 100m para conservar ascensiones cortas.
    fine,_=interpolated(pts,.1) if has_alt else ([],0)
    estimated=calculate_gain(fine) if has_alt else None
    gradients=[]
    for i,(d,lat,lon,ele) in enumerate(sampled):
        gradient=None
        if i and ele is not None and sampled[i-1][3] is not None:
            delta=d-sampled[i-1][0]
            if delta>0:gradient=(ele-sampled[i-1][3])/(delta*10)
        gradients.append((stage_id,d,round(lat,7),round(lon,7),round(ele,2) if ele is not None else None,
                          round(gradient,2) if gradient is not None else None))
    with conn:
        conn.execute('DELETE FROM perfil WHERE etapa_id=?',(stage_id,))
        conn.executemany('INSERT INTO perfil (etapa_id,km,lat,lon,altitud_m,pendiente_pct) VALUES (?,?,?,?,?,?)',gradients)
        conn.execute('''UPDATE etapas SET ruta_verificada=1,distancia_gpx_km=?,
                     desnivel_gpx_estimado_m=?,puntos_con_altitud=?,
                     distancia_km=COALESCE(distancia_km,?),
                     desnivel_positivo_m=COALESCE(desnivel_positivo_m,?) WHERE id=?''',
                     (round(km,1),estimated,int(has_alt),round(km,1),estimated,stage_id))
    return km,estimated,len(gradients),has_alt

def main():
    a=argparse.ArgumentParser(description='Descarga e importa las trazas GPX de las carreras 2026.')
    a.add_argument('--solo',help='Filtrar por slug de la competición: tour-de-france, giro-ditalia, vuelta-espana, ...')
    a.add_argument('--limite',type=int,help='Procesar como máximo N etapas')
    a.add_argument('--enlaces',action='store_true',help='Solo sincronizar enlaces; no descargar GPX')
    a.add_argument('--sin-sincronizar',action='store_true',help='Usar los enlaces ya guardados')
    a.add_argument('--archivo',type=Path,help='Importar un GPX existente en lugar de descargar')
    a.add_argument('--etapa-id',type=int,help='ID de la etapa cuando se usa --archivo')
    a.add_argument('--reintentar',action='store_true',help='Volver a importar etapas que ya tengan geometría')
    args=a.parse_args()
    if not DB.exists(): raise SystemExit('No se encontró ciclismo_2026.sqlite junto al script.')
    conn=sqlite3.connect(DB)
    conn.row_factory=sqlite3.Row
    if args.archivo:
        if not args.etapa_id: raise SystemExit('Falta --etapa-id N')
        r=import_gpx(conn,args.etapa_id,args.archivo.read_bytes())
        print('GPX importado:',r)
        return
    if not args.sin_sincronizar:
        sync_urls(conn)
    if args.enlaces: return
    GPX_DIR.mkdir(exist_ok=True)
    query='''SELECT e.id,e.numero,e.url_gpx,e.ruta_verificada,c.slug,c.nombre
             FROM etapas e JOIN competiciones c ON c.id=e.competicion_id
             WHERE e.url_gpx IS NOT NULL'''
    params=[]
    if args.solo:
        query+=' AND c.slug LIKE ?'
        params.append('%'+args.solo+'%')
    if not args.reintentar:
        query+=' AND e.ruta_verificada=0'
    query+=' ORDER BY c.id,e.numero'
    rows=conn.execute(query,params).fetchall()
    if args.limite is not None:
        rows=rows[:max(0,args.limite)]
    print('GPX pendientes:',len(rows))
    ok=0; fail=0
    for i,st in enumerate(rows,1):
        out=GPX_DIR/(st['slug']+'_'+str(st['numero']).zfill(2)+'.gpx')
        try:
            if out.exists():
                raw=out.read_bytes()
            else:
                raw=read_url(st['url_gpx'])
                if not raw.lstrip().startswith(b'<'):
                    raise ValueError('La descarga no parece ser un GPX/XML.')
            km,gain,points,alt=import_gpx(conn,st['id'],raw)
            if not out.exists():out.write_bytes(raw)
            ok+=1
            print(f'[{i}/{len(rows)}] {st["nombre"]} {st["numero"]}: {km:.1f} km; D+ estimado {gain if gain is not None else "N/D"} m; {points} muestras; altitud {"sí" if alt else "no"}')
        except Exception as ex:
            fail+=1
            print(f'[{i}/{len(rows)}] ERROR {st["nombre"]} {st["numero"]}: {ex}',file=sys.stderr)
        time.sleep(.6)
    conn.close()
    print(f'Terminado. Importadas {ok}, sin importar {fail}. Archivo: {DB}')

if __name__=='__main__':main()
