/* Ejemplo de acceso a las carreras desde C con SQLite.
 * Linux:   gcc ejemplo_c.c -lsqlite3 -o ejemplo
 * Windows: enlazar sqlite3.lib o compilar sqlite3.c + ejemplo_c.c
 * Ejecutar en la misma carpeta que ciclismo_2026.sqlite.
 */
#include <stdio.h>
#include <sqlite3.h>

int main(void) {
    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    const char *sql =
        "SELECT c.nombre, e.numero, e.salida, e.meta, e.distancia_km, "
        "e.desnivel_positivo_m, e.dificultad FROM etapas e "
        "JOIN competiciones c ON e.competicion_id = c.id "
        "WHERE c.slug='tour-de-france' ORDER BY e.numero";

    if (sqlite3_open("ciclismo_2026.sqlite", &db) != SQLITE_OK) {
        fprintf(stderr, "No se pudo abrir la base: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, NULL) != SQLITE_OK) {
        fprintf(stderr, "Error SQL: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        const unsigned char *nombre = sqlite3_column_text(stmt, 0);
        int num = sqlite3_column_int(stmt, 1);
        const unsigned char *salida = sqlite3_column_text(stmt, 2);
        const unsigned char *meta = sqlite3_column_text(stmt, 3);
        double km = sqlite3_column_double(stmt, 4);
        int desnivel = sqlite3_column_int(stmt, 5);
        int dif = sqlite3_column_int(stmt, 6);
        printf("%s etapa %d: %s -> %s | %.1f km | +%d m | dif %d/10\n",
               nombre ? (const char *)nombre : "?", num,
               salida ? (const char *)salida : "?",
               meta ? (const char *)meta : "?",km,desnivel,dif);
    }
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return 0;
}
