#!/usr/bin/env python3
"""Crea un catálogo local SQLite de carreras 2026 a partir de datos verificables.
Contiene cifras de desnivel de las tres grandes vueltas y enlaces GPX a CyclingStage.
No contiene perfiles km a km antes de ejecutar completar_gpx.py.
"""
import csv
import json
import os
import sqlite3
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB = BASE / 'ciclismo_2026.sqlite'
SITE = 'https://www.cyclingstage.com'
CDN = 'https://cdn.cyclingstage.com/images'
C0 = f'{SITE}/gpx-2026-pro-cycling-races/'

# fecha | salida | meta | kilómetros | desnivel acumulado m | tipo
TOUR = '''
07-04|Barcelona|Barcelona|19.6|167|CRE
07-05|Tarragona|Barcelona|168.5|2049|media montaña
07-06|Granollers|Les Angles|195.9|3940|montaña
07-07|Carcassonne|Foix|181.9|2784|media montaña
07-08|Lannemezan|Pau|158.3|1395|llana
07-09|Pau|Gavarnie-Gèdre|186.2|4149|montaña
07-10|Hagetmau|Bordeaux|175.1|701|llana
07-11|Périgueux|Bergerac|180.4|1353|llana
07-12|Malemort|Ussel|154.6|2792|media montaña
07-14|Aurillac|Le Lioran|165.6|3791|media montaña
07-15|Vichy|Nevers|161.3|1107|llana
07-16|Circuit Nevers Magny-Cours|Chalon-sur-Saône|179.1|1412|llana
07-17|Dole|Belfort|205.8|2309|media montaña
07-18|Mulhouse|Le Markstein|155.3|3941|montaña
07-19|Champagnole|Plateau de Solaison|183.9|4098|montaña
07-21|Évian-les-Bains|Thonon-les-Bains|26.1|470|CRI
07-22|Chambéry|Voiron|174.7|2362|llana
07-23|Voiron|Orcières-Merlette|185.2|3944|montaña
07-24|Gap|Alpe d'Huez|127.9|3572|montaña
07-25|Le Bourg d'Oisans|Alpe d'Huez|170.9|5624|montaña
07-26|Paris|Paris|88.7|1028|llana
'''
GIRO = '''
05-08|Nessebar|Burgas|147|872|llana
05-09|Burgas|Veliko Tarnovo|221|2348|media montaña
05-10|Plovdiv|Sofia|175|1577|llana
05-12|Catanzaro|Cosenza|138|1600|media montaña
05-13|Praia a Mare|Potenza|203|3724|media montaña
05-14|Paestum|Naples|141|680|llana
05-15|Formia|Blockhaus|244|4467|montaña
05-16|Chieti|Fermo|156|1804|media montaña
05-17|Cervia|Corno alle Scale|184|2351|montaña
05-19|Viareggio|Massa|42|105|CRI
05-20|Porcari|Chiavari|195|2939|media montaña
05-21|Imperia|Novi Ligure|175|2046|llana
05-22|Alessandria|Verbania|189|1326|media montaña
05-23|Aosta|Pila (Gressan)|133|4209|montaña
05-24|Voghera|Milan|156|612|llana
05-26|Bellinzona|Carì|113|2928|montaña
05-27|Cassano d'Adda|Andalo|202|3257|media montaña
05-28|Fai della Paganella|Pieve di Soligo|171|1896|media montaña
05-29|Feltre|Alleghe (Piani di Pezzè)|151|4888|montaña
05-30|Gemona del Friuli|Piancavallo|200|3751|montaña
05-31|Rome|Rome|131|1709|llana
'''
VUELTA = '''
08-22|Monaco|Monaco|9.4|55|CRI
08-23|Monaco|Manosque|202.1|2942|media montaña
08-24|Gruissan|Font Romeu|174|2639|montaña
08-25|Andorra la Vella|Andorra la Vella|104.8|3024|montaña
08-26|Falset|Roquetes|173.3|1689|llana
08-27|Alcossebre|Castelló|177.4|2984|media montaña
08-28|Vall d'Alba|Aramón Valdelinares|149.8|3597|montaña
08-29|Puçol|Xeraco|171|1280|llana
08-30|La Vila Joiosa/Villajoyosa|Alto de Aitana|187.4|4952|montaña
09-01|Alcaraz|Elche de la Sierra|184.7|2669|media montaña
09-02|Cartagena|Lorca|151.3|1444|llana
09-03|Vera|Calar Alto|166.6|4475|montaña
09-04|Almuñécar|Loja|192.8|3277|media montaña
09-05|Jaén|Sierra de la Pandera|154.5|4107|montaña
09-06|Palma del Río|Córdoba|189.7|3347|media montaña
09-08|Cortegana|La Rábida (Palos de la Frontera)|181.1|1914|llana
09-09|Dos Hermanas|Sevilla|185|930|llana
09-10|El Puerto de Santa María|Jerez de la Frontera|32.1|169|CRI
09-11|Vélez-Málaga|Peñas Blancas (Estepona)|210.8|4018|montaña
09-12|La Calahorra|Collado del Alguacil|186.8|4849|montaña
09-13|Carrefour Granada|Granada|112|1311|media montaña
'''

# Categorías/recorridos de carreras por etapas de 2026 para las que hay GPX publicados.
# Se deja nulo el kilometraje y D+ cuando no se ha contrastado.
SHORT = [
 ('Volta a la Comunitat Valenciana','tour-of-valencia','España',[
  ('Segorbe','Torreblanca'),('Carlet','Alginet'),('Orihuela','Sant Vicent'),('La Nucía','Teulada Moraira'),('Bétera','Valencia')]),
 ('UAE Tour','uae-tour','Emiratos Árabes Unidos',[
  ('Madinat Zayed','Liwa'),('Al Hudayriyat','Al Hudayriyat'),('Umm Al Quwain','Jebel Mobrah'),('Fujairah','Fujairah'),('Dubai','Dubai'),('Al Ain','Jebel Hafeet'),('Abu Dhabi','Abu Dhabi')]),
 ('Vuelta a Andalucía (Ruta del Sol)','ruta-del-sol','España',[
  ('Benahavís','Pizarra'),('Torrox','Otura'),('Jaén','Lopera'),('Montoro','Pozoblanco'),('La Roda','Lucena')]),
 ('Volta ao Algarve','volta-ao-algarve','Portugal',[
  ('Vila Real de Santo António','Tavira'),('Portimão','Alto da Fóia'),('Vilamoura','Vilamoura'),('Albufeira','Lagos'),('Faro','Alto do Malhão')]),
 ('Paris-Nice','paris-nice','Francia',[
  ('Achères','Carrières'),('Épône','Montargis'),('Cosne-Cours-sur-Loire','Pouilly'),('Bourges','Uchon'),(None,'Colombier-le-Vieux'),('Barbentane','Apt'),('Nice','Auron'),('Nice','Nice')]),
 ('Tirreno-Adriatico','tirreno-adriatico','Italia',[
  ('Lido di Camaiore','Lido di Camaiore'),('Camaiore','San Gimignano'),('Cortona','Magliano de’ Marsi'),('Tagliacozzo','Martinsicuro'),(None,'Mombaroccio'),('San Severino Marche','Camerino'),(None,'San Benedetto del Tronto')]),
 ('Volta a Catalunya','volta-a-catalunya','España',[
  ('Sant Feliu de Guíxols','Sant Feliu de Guíxols'),('Figueres','Banyoles'),('Mont-roig del Camp','Vila-seca'),('Mataró','Vallter'),('La Seu d’Urgell','Coll de Pal'),('Berga','Queralt'),('Barcelona','Barcelona')]),
 ('Itzulia Basque Country','tour-of-the-basque-country','España',[
  ('Bilbao','Bilbao'),('Pamplona','Mendukilo'),('Basauri','Basauri'),('Galdakao','Galdakao'),('Eibar','Eibar'),('Goizper-Antzuola','Bergara')]),
 ('O Gran Camiño','o-gran-camino','España',[
  ('A Coruña','A Coruña'),('Vilalba','Barreiros'),('Carballo','Padrón'),('Xinzo','Alto Cabeza de Meda'),('As Neves','Monte Trega')]),
 ('Tour of the Alps','tour-of-the-alps','Italia / Austria',[
  ('Innsbruck','Innsbruck'),('Telfs','Martell'),('Latsch','Arco'),('Arco','Trento'),('Trento','Bolzano')]),
]

# Clásicas para las cuales CyclingStage ofrece GPX; enlace se sincroniza desde la web.
CLASSICS = [
 ('Omloop Het Nieuwsblad','omloop-het-nieuwsblad','Bélgica','M'),
 ('Kuurne-Brussels-Kuurne','kuurne-brussels-kuurne','Bélgica','M'),
 ('E3 Saxo Classic','e3-saxo-classic','Bélgica','M'),
 ('In Flanders Fields (Gent-Wevelgem)','gent-wevelgem','Bélgica','M'),
 ('Dwars door Vlaanderen','dwars-door-vlaanderen','Bélgica','M'),
 ('Ronde van Vlaanderen','tour-of-flanders','Bélgica','M'),
 ('Brabantse Pijl','brabantse-pijl','Bélgica','M'),
 ('Liège-Bastogne-Liège','liege-bastogne-liege','Bélgica','M'),
 ('Strade Bianche','strade-bianche','Italia','M'),
 ('Milano-Sanremo','milan-sanremo','Italia','M'),
 ('Paris-Roubaix','paris-roubaix','Francia','M'),
 ('Amstel Gold Race','amstel-gold-race','Países Bajos','M'),
 ('Strade Bianche Donne','strade-bianche','Italia','F'),
 ('Ronde van Vlaanderen Women','tour-of-flanders','Bélgica','F'),
 ('Paris-Roubaix Femmes','paris-roubaix','Francia','F'),
 ('Amstel Gold Race Ladies Edition','amstel-gold-race','Países Bajos','F'),
]

schema = '''
PRAGMA foreign_keys=ON;
CREATE TABLE competiciones (
 id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, nombre TEXT NOT NULL,
 temporada INTEGER NOT NULL, tipo TEXT NOT NULL, categoria TEXT NOT NULL DEFAULT 'M',
 pais TEXT, descripcion TEXT, fuente_gpx TEXT, fuente_datos TEXT
);
CREATE TABLE etapas (
 id INTEGER PRIMARY KEY, competicion_id INTEGER NOT NULL REFERENCES competiciones(id),
 numero INTEGER NOT NULL, fecha TEXT, salida TEXT, meta TEXT,
 distancia_km REAL, desnivel_positivo_m INTEGER,
 tipo TEXT, dificultad INTEGER,
 url_gpx TEXT, ruta_verificada INTEGER NOT NULL DEFAULT 0,
 distancia_gpx_km REAL, desnivel_gpx_estimado_m INTEGER,
 puntos_con_altitud INTEGER NOT NULL DEFAULT 0,
 observaciones TEXT,
 UNIQUE(competicion_id, numero)
);
CREATE TABLE perfil (
 etapa_id INTEGER NOT NULL REFERENCES etapas(id) ON DELETE CASCADE,
 km REAL NOT NULL, lat REAL, lon REAL, altitud_m REAL,
 pendiente_pct REAL, PRIMARY KEY(etapa_id,km)
);
CREATE TABLE puertos (
 id INTEGER PRIMARY KEY, etapa_id INTEGER NOT NULL REFERENCES etapas(id),
 nombre TEXT, km_inicio REAL, km_fin REAL, altitud_cima_m REAL,
 desnivel_m REAL, pendiente_media_pct REAL, categoria TEXT,
 fuente TEXT
);
CREATE INDEX idx_etapas_fecha ON etapas(fecha);
CREATE INDEX idx_etapas_tipo ON etapas(tipo);
CREATE INDEX idx_etapas_dificultad ON etapas(dificultad);
CREATE INDEX idx_perfil_etapa ON perfil(etapa_id);
'''

def difficulty(ascent, km, typ):
    if ascent is None: return None
    # Índice propio de 1 a 10. No es una clasificación UCI ni PCS.
    import math
    val = ascent / 610.0 + (ascent / max(km or 175, 30)) * 0.10
    if typ in ('CRI','CRE'): val *= 0.60
    return max(1, min(10, round(1 + val)))

if DB.exists(): DB.unlink()
conn = sqlite3.connect(DB)
conn.row_factory = sqlite3.Row
conn.executescript(schema)

def add_comp(slug,name,tipo,pais,cat='M',gpx=C0,source=None,descr=None):
    cur=conn.execute('INSERT INTO competiciones (slug,nombre,temporada,tipo,categoria,pais,descripcion,fuente_gpx,fuente_datos) VALUES (?,?,?,?,?,?,?,?,?)',
        (slug,name,2026,tipo,cat,pais,descr,gpx,source))
    return cur.lastrowid

def add_stage(cid,n,date=None,origin=None,dest=None,km=None,gain=None,typ=None,url=None,obs=None):
    conn.execute('INSERT INTO etapas (competicion_id,numero,fecha,salida,meta,distancia_km,desnivel_positivo_m,tipo,dificultad,url_gpx,observaciones) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
        (cid,n,date,origin,dest,km,gain,typ,difficulty(gain,km,typ),url,obs))

for slug, name, country, text_rows, page, pattern in [
    ('tour-de-france','Tour de France','Francia / España',TOUR,f'{SITE}/tour-de-france-2026-gpx/',f'{CDN}/tour-de-france/2026/stage-{{n}}-parcours.gpx'),
    ('giro-ditalia','Giro d’Italia','Italia / Bulgaria / Suiza',GIRO,f'{SITE}/giro-2026-gpx/',f'{CDN}/giro-italy/2026/stage-{{n}}-route.gpx'),
    ('vuelta-espana','Vuelta a España','España / Mónaco / Francia / Andorra',VUELTA,f'{SITE}/vuelta-2026-gpx/',f'{CDN}/vuelta-spain/2026/stage-{{n}}-route.gpx'),
]:
    cid=add_comp(slug,name,'Gran Vuelta',country,gpx=page,
         source=f'https://www.procyclingstats.com/race/{"giro-d-italia" if slug=="giro-ditalia" else "vuelta-a-espana" if slug=="vuelta-espana" else "tour-de-france"}/2026/route/stages')
    rows=[x.strip() for x in text_rows.splitlines() if x.strip()]
    assert len(rows)==21,(slug,len(rows))
    for n,row in enumerate(rows,1):
        md,orig,dest,km,gain,typ=row.split('|')
        url=pattern.format(n=n)
        obs = 'Etapa 21 modificada en carrera. El GPX disponible puede corresponder al trazado originalmente previsto.' if slug=='tour-de-france' and n==21 else None
        add_stage(cid,n,f'2026-{md}',orig,dest,float(km),int(gain),typ,url,obs)

for name, slug, country, stages in SHORT:
    cid=add_comp(slug,name,'por etapas',country,gpx=C0)
    for n,(a,b) in enumerate(stages,1):
        typ='CRI' if (slug,n) in {('uae-tour',2),('tirreno-adriatico',1),('o-gran-camino',1)} else None
        url=f'{CDN}/{slug}/2026/stage-{n}-route.gpx'
        add_stage(cid,n,origin=a,dest=b,typ=typ,url=url,
            obs='Distancia/desnivel no cargados; ejecutar completar_gpx.py para obtener geometría y estimaciones.' )

for name,slug,country,gender in CLASSICS:
    cid=add_comp(slug+('-women' if gender=='F' else ''),name,'clásica',country,gender,gpx=C0)
    add_stage(cid,1,typ='clásica',url=None,
        obs='URL GPX pendiente de sincronizar; ejecutar completar_gpx.py.')

conn.commit()
# CSV y JSON desnormalizados para otras herramientas y lenguajes.
rows = [dict(x) for x in conn.execute('''SELECT c.slug AS competicion_slug,c.nombre AS competicion,c.tipo AS tipo_competicion,
 c.categoria AS categoria,c.pais,c.temporada,e.numero,e.fecha,e.salida,e.meta,e.distancia_km,
 e.desnivel_positivo_m,e.tipo AS tipo_etapa,e.dificultad,e.url_gpx,e.observaciones
 FROM etapas e JOIN competiciones c ON c.id=e.competicion_id ORDER BY c.id,e.numero''')]
cols=list(rows[0].keys())
with open(BASE/'etapas_2026.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)
with open(BASE/'etapas_2026.json','w',encoding='utf-8') as f:
 json.dump(rows,f,ensure_ascii=False,indent=2)
counts=conn.execute('SELECT (SELECT COUNT(*) FROM competiciones),(SELECT COUNT(*) FROM etapas),(SELECT COUNT(*) FROM etapas WHERE desnivel_positivo_m IS NOT NULL),(SELECT COUNT(*) FROM etapas WHERE url_gpx IS NOT NULL)').fetchone()
print('Base creada:',DB,'Competiciones/etapas/con D+/con GPX URL =',counts)
conn.close()
