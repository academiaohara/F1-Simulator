# Ciclismo Manager — Diseño del primer prototipo

## Intención

Crear un juego de gestión ciclista para Windows, programado en C, que pueda ejecutarse desde una carpeta sin permisos de administrador. La primera entrega debe demostrar el bucle principal: elegir equipo, revisar plantilla y contratos, planificar una carrera, recibir mensajes de los corredores y tomar decisiones durante una etapa.

## Alcance del MVP

- Aplicación gráfica de ventana con estética pixel art sencilla.
- Datos cargados desde las bases SQLite existentes de ciclistas/equipos y carreras/etapas.
- Selección de un equipo y visualización de su plantilla.
- Presupuesto, salarios, duración contractual, reputación y felicidad.
- Buzón con quejas y promesas incumplidas.
- Calendario corto con carreras disponibles y requisitos básicos.
- Carrera táctica simplificada por sectores, con órdenes de atacar, proteger, tirar, avituallarse y esperar.
- Perfil de etapa y grupos de carrera representados visualmente.
- Guardado local dentro de la carpeta del juego o en una carpeta de usuario no protegida.

## Fuera de alcance de esta entrega

- Simulación completa de todo el pelotón y todas las reglas UCI.
- Mercado contractual completo con agentes, cláusulas legales y negociaciones de varias rondas.
- Red multijugador.
- Licencias comerciales de nombres, logos, equipaciones o datos propietarios.
- Editor de etapas y soporte completo de todos los GPX.

## Decisiones técnicas

- C99.
- raylib para ventana, dibujo, entrada y audio básico.
- SQLite para consultar las bases existentes.
- Datos de juego separados de las bases de referencia.
- Compilación Windows portable, sin instalador ni escritura en directorios protegidos.
- La simulación y la interfaz estarán separadas para poder probar la lógica sin abrir la ventana.

## Datos propios del juego

Los atributos de la base 2024 se conservarán como referencia. El juego añadirá reputación, felicidad, rol, expectativas, salario, contrato, presupuesto y promesas en una capa propia. Los valores derivados se podrán recalibrar sin modificar los SQLite originales.

## Criterio de éxito

Una persona debe poder abrir el ejecutable, elegir un equipo, consultar su plantilla y buzón, seleccionar una etapa con perfil, dar órdenes a varios corredores y ver un resultado reproducible con cambios en fatiga, felicidad y clasificación.
