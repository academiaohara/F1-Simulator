# Ciclismo Manager MVP Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build the first playable Windows C prototype for cycling-team management and tactical stage decisions.

**Architecture:** A small C99 application will load reference data from the existing SQLite databases, map it into an owned game-state model, and render a single-window UI with raylib. Simulation rules will be pure C modules so they can be tested without the graphical loop.

**Tech Stack:** C99, raylib, SQLite3, MinGW-w64 or MSVC, small C test harness, existing SQLite/GPX data.

**Spec:** `docs/superpowers/specs/2026-11-05-ciclismo-mvp-design.md`

## Global Constraints

- The first delivery is a vertical slice, not the full game.
- The executable must run from a user-writable folder without administrator permissions.
- Reference databases remain unmodified; game-owned state is stored separately.
- No proprietary game database or copyrighted assets are copied into the deliverable.
- UI text is Spanish for the prototype.

## Review Focus

- Missing or partial race data must show an explicit fallback instead of crashing — covered by the database loader test.
- A contract promise must affect happiness when fulfilled or broken — covered by the morale test.
- Orders must be valid only for selected riders and valid race sectors — covered by the race simulation test.
- Saving in a user-writable path must work when the executable is placed on the Desktop — covered by the save/load test.
- A failed SQLite/raylib dependency must produce a readable error and non-zero exit — covered by startup validation.

### Task 1: Project skeleton and dependency detection

**Files:**
- Create: `src/main.c`
- Create: `src/app.h`
- Create: `src/app.c`
- Create: `CMakeLists.txt`
- Create: `build_windows.ps1`
- Create: `README.md`
- Create: `tests/test_runner.c`

**Interfaces:**
- `int app_run(const char *data_dir)` starts the application.
- `int app_validate_dependencies(const char *data_dir, char *error, size_t error_size)` checks data and runtime prerequisites.

- [ ] Add a buildable C99 skeleton and a test target.
- [ ] Verify a missing-data-path failure is readable and returns non-zero.
- [ ] Verify a valid data path reaches the application loop.

### Task 2: Reference-data loader and owned game model

**Files:**
- Create: `src/data.h`
- Create: `src/data.c`
- Create: `src/game_types.h`
- Create: `tests/test_data.c`

**Interfaces:**
- `bool data_load_reference(DataStore *store, const char *rider_db, const char *race_db, char *error, size_t error_size)`.
- `const Rider *data_find_rider(const DataStore *store, int id)`.
- `const Stage *data_find_stage(const DataStore *store, int id)`.

- [ ] Load a bounded prototype roster and a bounded calendar from the two SQLite files.
- [ ] Preserve source IDs and source labels while creating game-owned records.
- [ ] Handle empty profiles, missing GPX and missing team references.
- [ ] Test that the real databases produce non-zero riders, teams, competitions and stages.

### Task 3: Contracts, reputation, morale and inbox

**Files:**
- Create: `src/management.h`
- Create: `src/management.c`
- Create: `tests/test_management.c`

**Interfaces:**
- `void management_apply_promise_result(GameState *state, int rider_id, PromiseResult result)`.
- `bool management_make_offer(GameState *state, int rider_id, const ContractOffer *offer, OfferResult *result)`.
- `void management_generate_inbox(GameState *state)`.

- [ ] Implement salary, duration, role, budget and reputation checks.
- [ ] Implement happiness and trust changes for fulfilled/broken promises.
- [ ] Generate Spanish inbox messages for warnings, complaints and accepted offers.
- [ ] Test salary affordability, low-reputation rejection, promise fulfilment and complaint generation.

### Task 4: Calendar and tactical race simulation

**Files:**
- Create: `src/race_sim.h`
- Create: `src/race_sim.c`
- Create: `tests/test_race_sim.c`

**Interfaces:**
- `void race_sim_start(RaceState *race, const Stage *stage, const Team *team, uint32_t seed)`.
- `bool race_sim_issue_order(RaceState *race, int rider_id, RiderOrder order)`.
- `void race_sim_tick(RaceState *race, float minutes)`.
- `RaceResult race_sim_finish(const RaceState *race)`.

- [ ] Convert the GPX profile into playable sectors with terrain and gradient.
- [ ] Simulate fatigue, drafting, groups, attacks, protection, food and sprint preparation.
- [ ] Make rider role and attributes alter order effects.
- [ ] Test deterministic output for a fixed seed and valid/invalid order handling.

### Task 5: Pixel-art UI vertical slice

**Files:**
- Create: `src/ui.h`
- Create: `src/ui.c`
- Modify: `src/app.c`
- Create: `assets/README.md`

**Interfaces:**
- `void ui_draw(const GameState *state, const RaceState *race, Screen screen)`.
- `void ui_handle_input(GameState *state, RaceState *race, Screen *screen)`.

- [ ] Add screens for team overview, roster/contracts, inbox, calendar and race.
- [ ] Draw a readable route profile, rider group markers and order buttons without external assets.
- [ ] Use a coherent low-resolution palette and nearest-neighbour scaling.
- [ ] Test the application manually through the complete MVP loop.

### Task 6: Save/load and portable Windows package

**Files:**
- Create: `src/save.h`
- Create: `src/save.c`
- Create: `tests/test_save.c`
- Modify: `build_windows.ps1`
- Modify: `README.md`

**Interfaces:**
- `bool save_game(const GameState *state, const char *path, char *error, size_t error_size)`.
- `bool load_game(GameState *state, const char *path, char *error, size_t error_size)`.

- [ ] Save only owned game state, never overwrite reference databases.
- [ ] Prefer a save path beside the executable when writable and fall back to `%LOCALAPPDATA%`.
- [ ] Produce a portable release folder containing `.exe`, DLLs if required, data and README.
- [ ] Verify the release runs from a Desktop folder without elevation.

## Verification

- Run the C test harness after each task.
- Build a Release Windows executable with `build_windows.ps1`.
- Launch the executable from a copied Desktop folder.
- Complete the flow: select team → read inbox → inspect contract → choose stage → issue orders → finish stage → save → reload.
