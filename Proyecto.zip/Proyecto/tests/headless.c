#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../src/game.h"
#include "../src/sim.h"
#include "../src/gfx.h"

int main(int argc, char **argv) {
    int team = argc > 1 ? atoi(argv[1]) : 12;
    game_new(team);
    printf("Equipo: %s riders=%d\n", TEAMS[team].name, team_size(team));
    clock_t t0 = clock();
    int days = argc > 2 ? atoi(argv[2]) : 365;
    for (int d = 0; d < days; d++) {
        int day = G.day;
        game_advance_day();
        if (G.day != day + 1 && G.day != 0) printf("?\n");
    }
    printf("Simulados %d dias en %.2fs\n", days, (double)(clock() - t0) / CLOCKS_PER_SEC);
    for (int i = 0; i < G.nnews; i++) printf("  %s\n", G.news[i]);
    for (int t = 0; t < G.nteams; t++) (void)t;
    return 0;
}
