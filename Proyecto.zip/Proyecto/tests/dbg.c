#include <stdio.h>
#include <string.h>
#include "../src/game.h"
#include "../src/sim.h"
static Sim sim;
int main(int argc, char **argv) {
    game_new(12);
    G.day = 100; memset(G.runs, 0, sizeof G.runs);
    RaceRun *run = game_race_run(atoi(argv[1]), 1);
    int sidx = RACES[atoi(argv[1])].stage0 + atoi(argv[2]);
    assign_ai_strats(run, sidx);
    sim_setup(&sim, sidx, run, 1);
    int nextp = 0;
    while (!sim.done && sim.t < 16000) {
        sim_step(&sim);
        if (sim.t >= nextp) {
            nextp += 600;
            printf("t=%5.0f km=%.0f groups=%d:", sim.t, sim.leader_pos / 1000, sim.ngroups);
            for (int g = 0; g < sim.ngroups && g < 5; g++) printf(" [n=%d gap=%.0f v=%.0f brk=%d]", sim.grp[g].n, sim.grp[g].gap, sim.grp[g].v * 3.6f, sim.grp[g].has_break_riders);
            printf("\n");
        }
    }
    for (int i = 0; i < sim.nev && i < 12; i++) printf("EV %d: %s\n", sim.ev[i].t_sec, sim.ev[i].text);
    return 0;
}
