#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../src/game.h"
#include "../src/sim.h"
static Sim sim;
static int cmpf(const void *a, const void *b) {
    const SimRider *x = *(SimRider *const *)a, *y = *(SimRider *const *)b;
    if ((x->status == 2) != (y->status == 2)) return x->status == 2 ? -1 : 1;
    return x->finish_t < y->finish_t ? -1 : (x->finish_t > y->finish_t);
}
int main(int argc, char **argv) {
    game_new(12);
    int race = atoi(argv[1]);
    int st = atoi(argv[2]);
    int seeds = argc > 3 ? atoi(argv[3]) : 1;
    int bunch = 0, brk_win = 0, elim = 0;
    for (int s = 0; s < seeds; s++) {
        G.day = 100 + s * 7;
        memset(G.runs, 0, sizeof G.runs);
        RaceRun *run = game_race_run(race, 1);
        int sidx = RACES[race].stage0 + st;
        assign_ai_strats(run, sidx);
        sim_setup(&sim, sidx, run, 0);
        sim_run_all(&sim);
        SimRider *l[SIM_MAX]; int n = 0;
        for (int i = 0; i < sim.n; i++) l[n++] = &sim.r[i];
        qsort(l, n, sizeof l[0], cmpf);
        int fin = 0;
        for (int i = 0; i < n; i++) if (l[i]->status == 2) fin++;
        float win = l[0]->finish_t;
        float lim = win * 1.12f;
        int late = 0;
        for (int i = 0; i < fin; i++) if (l[i]->finish_t > lim) late++;
        elim += late;
        int ten = l[9]->finish_t - win < 25;
        if (ten) bunch++; else brk_win++;
        if (seeds <= 3) {
            printf("%s st%d %.0fkm | %dh%02dm %.1f km/h | 10o=+%.0f 30o=+%.0f fuera_de_tiempo=%d winner=%s rol=%d\n", RACES[race].name, st + 1, sim.st->dist_km,
                (int)(win / 3600), (int)(win / 60) % 60, sim.st->dist_km / (win / 3600), l[9]->finish_t - win, l[29]->finish_t - win, late, rider_name(l[0]->rider), l[0]->role);
        }
    }
    printf("RESUMEN %d seeds: llegada en grupo=%d  ganador escapado=%d  fuera de tiempo medio=%.1f\n", seeds, bunch, brk_win, (float)elim / seeds);
    return 0;
}
