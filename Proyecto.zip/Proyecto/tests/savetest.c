#include <stdio.h>
#include <string.h>
#include "../src/game.h"
int main(void) {
    game_new(12);
    for (int i = 0; i < 120; i++) game_advance_day();
    int d = G.day, cash = (int)G.teams[G.player].cash;
    if (!save_game("tests_tmp.sav")) { printf("FAIL save\n"); return 1; }
    game_new(3);
    if (!load_game("tests_tmp.sav")) { printf("FAIL load\n"); return 1; }
    printf("save/load %s (dia %d=%d, caja %d=%d, equipo %d)\n", (G.day == d && (int)G.teams[G.player].cash == cash && G.player == 12) ? "OK" : "FAIL", G.day, d, (int)G.teams[G.player].cash, cash, G.player);
    remove("tests_tmp.sav");
    return 0;
}
