#include <stdio.h>
#include <string.h>
#include "../src/game.h"
#include "../src/sim.h"
static Sim sim;
int main(void) {
    game_new(12);
    G.day = 100; memset(G.runs, 0, sizeof G.runs);
    RaceRun *run = game_race_run(0, 1);
    int sidx = 4;
    assign_ai_strats(run, sidx);
    sim_setup(&sim, sidx, run, 1);
    while (sim.t < 600) sim_step(&sim);
    float mp = 0, mv = 0, mr = 0; int n = 0;
    for (int i = 0; i < sim.n; i++) { SimRider *r = &sim.r[i]; mp += r->p_now; mv += r->v; mr += r->r_now; n++; }
    printf("mean P=%.0f W v=%.1f km/h ratio=%.2f perf0=%.3f  pullers:", mp / n, mv / n * 3.6f, mr / n, sim.r[0].perf);
    int pc = 0; for (int i = 0; i < sim.n; i++) if (sim.r[i].ai_pull || sim.r[i].order == ORD_TIRAR) pc++;
    printf(" %d grade=%.3f\n", pc, sim_grade_at(&sim, sim.leader_pos));
    return 0;
}
