$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$vs = 'C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvarsall.bat'
if (-not (Test-Path -LiteralPath $vs)) { throw "No se encontro Visual Studio Build Tools: $vs" }
New-Item -ItemType Directory -Force -Path "$root\build" | Out-Null
$srcs = 'src\main.c src\ui.c src\uirace.c src\game.c src\sim.c src\gfx.c src\save.c src\data_gen.c'
cmd.exe /c "call `"$vs`" x64 >nul && cd /d $root && cl /nologo /O2 /std:c11 /utf-8 /W3 /D_CRT_SECURE_NO_WARNINGS /Fobuild\ $srcs /Fe:ciclismo_manager.exe /link /SUBSYSTEM:WINDOWS user32.lib gdi32.lib"
if ($LASTEXITCODE -ne 0) { throw "La compilacion fallo" }
Write-Host "Compilado: $root\ciclismo_manager.exe"
