# -*- coding: utf-8 -*-
"""Genera src/data_gen.c a partir de las dos bases SQLite (ciclistas 2024 + rutas 2026).
Uso:  python tools/export_data.py
El resultado se compila dentro del .exe: el juego final no necesita SQLite ni ficheros externos.
"""
import sqlite3, unicodedata, random, math, datetime, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RIDER_DB = ROOT / 'ciclismo_para_C' / 'ciclismo_para_C.sqlite'
RACE_DB = ROOT / 'ciclismo_rutas_2026' / 'ciclismo_2026.sqlite'
OUT = ROOT / 'src' / 'data_gen.c'

KEEP = 'áéíóúñüÁÉÍÓÚÑ'
SPECIAL = {'ø': 'o', 'Ø': 'O', 'ł': 'l', 'Ł': 'L', 'đ': 'd', 'Đ': 'D', 'ß': 'ss', 'æ': 'ae', 'Æ': 'AE',
           'œ': 'oe', 'Œ': 'OE', 'ı': 'i', 'þ': 'th', '’': "'", '‘': "'", '–': '-', '—': '-', 'ð': 'd'}

def fold(s):
    if s is None:
        return ''
    out = []
    for ch in str(s):
        if ch in KEEP or ord(ch) < 128:
            out.append(ch)
        elif ch in SPECIAL:
            out.append(SPECIAL[ch])
        else:
            n = unicodedata.normalize('NFKD', ch)
            out.append(''.join(c for c in n if ord(c) < 128))
    return ''.join(out).replace('\n', ' ').strip()

def cstr(s):
    b = fold(s).encode('utf-8')
    res = []
    for c in b:
        if c == 34: res.append('\\"')
        elif c == 92: res.append('\\\\')
        elif c < 32: res.append(' ')
        elif c < 128: res.append(chr(c))
        else: res.append('\\%03o' % c)
    return '"' + ''.join(res) + '"'

# ----------------------------------------------------------------- equipos
TEAM_COLORS = [
    ('uae team emirates', (238, 238, 238), (205, 30, 45)),
    ('visma', (250, 214, 40), (35, 35, 35)),
    ('lidl', (205, 30, 45), (240, 240, 240)),
    ('ineos', (30, 30, 52), (205, 30, 45)),
    ('bora', (236, 236, 236), (30, 140, 62)),
    ('soudal', (40, 92, 205), (236, 236, 236)),
    ('ef education', (235, 70, 150), (40, 70, 160)),
    ('movistar', (22, 100, 205), (236, 236, 236)),
    ('decathlon', (120, 75, 42), (96, 150, 225)),
    ('jayco', (236, 236, 236), (30, 120, 200)),
    ('intermarch', (252, 220, 0), (40, 70, 160)),
    ('alpecin', (30, 80, 172), (205, 40, 50)),
    ('dsm', (22, 22, 22), (235, 60, 60)),
    ('groupama', (20, 60, 172), (236, 236, 236)),
    ('ark', (30, 60, 172), (90, 160, 235)),
    ('cofidis', (212, 30, 40), (236, 236, 236)),
    ('bahrain', (205, 30, 45), (240, 200, 60)),
    ('astana', (90, 175, 235), (236, 236, 236)),
    ('israel', (20, 30, 92), (236, 236, 236)),
    ('lotto', (205, 30, 45), (236, 236, 236)),
    ('uno-x', (240, 200, 40), (205, 40, 50)),
    ('totalenergies', (212, 30, 40), (236, 236, 236)),
    ('q36', (22, 22, 22), (236, 236, 236)),
    ('tudor', (205, 30, 45), (22, 22, 22)),
    ('polti', (30, 150, 70), (236, 236, 236)),
    ('bingoal', (240, 140, 30), (30, 40, 90)),
    ('bardiani', (30, 140, 70), (236, 236, 236)),
    ('caja rural', (30, 130, 70), (236, 236, 236)),
    ('burgos', (200, 30, 45), (236, 236, 236)),
    ('euskaltel', (240, 120, 30), (236, 236, 236)),
]

def team_colors(name):
    low = name.lower()
    for key, c1, c2 in TEAM_COLORS:
        if key in low:
            return c1, c2
    h = int(hashlib.md5(name.encode('utf-8')).hexdigest(), 16)
    hue = (h % 360) / 360.0
    import colorsys
    r, g, b = colorsys.hsv_to_rgb(hue, 0.65, 0.85)
    r2, g2, b2 = colorsys.hsv_to_rgb((hue + 0.5) % 1.0, 0.25, 0.95)
    return (int(r * 255), int(g * 255), int(b * 255)), (int(r2 * 255), int(g2 * 255), int(b2 * 255))

CAT_ORDER = {'WorldTour': 0, 'ProTeam': 1, 'Continental': 2, 'Sub-23': 3}
TYPE_ORDER = {'Rodador': 0, 'Esprinter': 1, 'Puncheur': 2, 'Contrarrelojista': 3, 'Escalador': 4, 'Clasicomano': 5, 'Vueltomano': 6}

# ----------------------------------------------------------------- carreras
# slug: (tier, plantilla, equipos, pais, fecha inicio (mes,dia) o None si viene de la BD, prestigio)
# tier: 0 Gran Vuelta, 1 Monumento, 2 WorldTour, 3 ProSeries
RACES = {
    'tour-de-france': (0, 8, 22, 'FRA', None),
    'giro-ditalia': (0, 8, 22, 'ITA', None),
    'vuelta-espana': (0, 8, 22, 'ESP', None),
    'tour-of-valencia': (3, 7, 20, 'ESP', (2, 4)),
    'uae-tour': (2, 7, 22, 'UAE', (2, 16)),
    'ruta-del-sol': (3, 7, 20, 'ESP', (2, 18)),
    'volta-ao-algarve': (3, 7, 20, 'POR', (2, 18)),
    'o-gran-camino': (3, 7, 20, 'ESP', (2, 26)),
    'omloop-het-nieuwsblad': (2, 7, 24, 'BEL', (2, 28)),
    'kuurne-brussels-kuurne': (3, 7, 24, 'BEL', (3, 1)),
    'strade-bianche': (2, 7, 24, 'ITA', (3, 7)),
    'paris-nice': (2, 7, 22, 'FRA', (3, 8)),
    'tirreno-adriatico': (2, 7, 22, 'ITA', (3, 9)),
    'milan-sanremo': (1, 7, 25, 'ITA', (3, 21)),
    'volta-a-catalunya': (2, 7, 22, 'ESP', (3, 23)),
    'e3-saxo-classic': (2, 7, 24, 'BEL', (3, 27)),
    'gent-wevelgem': (2, 7, 24, 'BEL', (3, 29)),
    'dwars-door-vlaanderen': (2, 7, 24, 'BEL', (4, 1)),
    'tour-of-flanders': (1, 7, 25, 'BEL', (4, 5)),
    'tour-of-the-basque-country': (2, 7, 22, 'ESP', (4, 6)),
    'paris-roubaix': (1, 7, 25, 'FRA', (4, 12)),
    'brabantse-pijl': (3, 7, 24, 'BEL', (4, 15)),
    'amstel-gold-race': (2, 7, 24, 'NED', (4, 19)),
    'tour-of-the-alps': (3, 7, 20, 'ITA', (4, 20)),
    'liege-bastogne-liege': (1, 7, 25, 'BEL', (4, 26)),
}
SKIP_WOMEN = {'strade-bianche-women', 'tour-of-flanders-women', 'paris-roubaix-women', 'amstel-gold-race-women'}

KIND = {'llana': 0, 'media montaña': 1, 'montaña': 2, 'CRI': 3, 'CRE': 4, 'clásica': 5}

def doy(m, d, year=2026):
    return (datetime.date(year, m, d) - datetime.date(year, 1, 1)).days

# ----------------------------------------------------------------- perfiles sintéticos
def synth_alt(seed, dist_km, dplus, kind, features=None, start_alt=60):
    rng = random.Random(seed)
    n = int(dist_km / 0.5) + 1
    alt = [0.0] * n
    # lista de ascensos [(km_ini, largo_km, pend%)]
    feats = []
    if features:
        feats = list(features)
    else:
        total = dplus
        if kind == 2:       # montaña: 3 puertos, final en alto
            lens = [random.Random(seed + 1).uniform(9, 16), rng.uniform(8, 14), rng.uniform(10, 18)]
            ends = [0.35, 0.62, 1.0]
        elif kind == 1:     # media montaña
            lens = [rng.uniform(5, 9), rng.uniform(4, 8), rng.uniform(5, 10), rng.uniform(3, 6)]
            ends = [0.25, 0.5, 0.75, 0.97]
        elif kind == 5:
            lens = [rng.uniform(1, 3) for _ in range(8)]
            ends = [0.15 + 0.1 * i for i in range(8)]
        else:
            lens = [rng.uniform(2, 4), rng.uniform(1.5, 3)]
            ends = [0.4, 0.7]
        base = sum(lens)
        for L, e in zip(lens, ends):
            share = total * (L / base) * 0.82
            g = min(12.0, max(1.5, share / (L * 10.0)))
            ke = max(L + 1, e * dist_km - (0 if e < 1.0 else 0.3))
            feats.append((max(0.0, ke - L), L, g))
    # construir: rodar con ondulación + ascensos
    cur = start_alt
    prof = [cur]
    step = 0.5
    # pendiente base: ligera ondulación
    undul = [0.0] * n
    ph = rng.uniform(0, 6.28)
    amp = max(3, dplus * 0.02 / 10)
    for i in range(n):
        undul[i] = amp * math.sin(i * 0.17 + ph) + amp * 0.5 * math.sin(i * 0.43 + ph * 2)
    grade = [0.0] * n
    for (k0, L, g) in feats:
        i0 = int(k0 / step); i1 = min(n - 1, int((k0 + L) / step))
        for i in range(i0, i1 + 1):
            grade[i] += g
        # descenso posterior
        d0 = i1 + 1; d1 = min(n - 1, d0 + int(max(2, L * 0.7 / step)))
        for i in range(d0, d1 + 1):
            grade[i] -= g * (L / max(1.0, (d1 - d0 + 1) * step)) * 0.9
    out = []
    cur = start_alt
    for i in range(n):
        out.append(cur + undul[i])
        cur += grade[i] * 5.0   # 0.5 km * 10 m/km per %
        if cur < 5: cur = 5
    return [int(round(x)) for x in out]

def smooth_alt(alt):
    n = len(alt)
    if n < 5:
        return alt
    med = [alt[0]] + [sorted(alt[i - 1:i + 2])[1] for i in range(1, n - 1)] + [alt[-1]]
    out = [med[0]] + [(med[i - 1] + med[i] + med[i + 1]) / 3.0 for i in range(1, n - 1)] + [med[-1]]
    return [int(round(x)) for x in out]

def synth_map(seed, dist_km, n):
    rng = random.Random(seed)
    lat, lon = 45.0 + rng.uniform(-3, 3), 4.0 + rng.uniform(-3, 3)
    ang = rng.uniform(0, 6.28)
    pts = []
    for i in range(n):
        pts.append((lat, lon))
        ang += rng.uniform(-0.25, 0.25)
        lat += math.sin(ang) * 0.5 / 111.0
        lon += math.cos(ang) * 0.5 / 78.0
    return pts

# ----------------------------------------------------------------- principal
def main():
    rc = sqlite3.connect(RIDER_DB)
    # equipos
    teams = rc.execute("SELECT id,nombre,abreviatura,pais_codigo,categoria FROM equipos").fetchall()
    team_rows = []
    for tid, nombre, abbr, pais, cat in teams:
        if cat not in CAT_ORDER:
            continue
        team_rows.append((CAT_ORDER[cat], fold(nombre), tid, fold(abbr or nombre[:3]).upper()[:4], pais or 'ESP'))
    team_rows.sort()
    team_index = {r[2]: i for i, r in enumerate(team_rows)}

    # ciclistas
    rows = rc.execute("""SELECT nombre_completo,pais_codigo,fecha_nacimiento,equipo_id,tipo_estimado,nivel_general,
        potencial_pcm,victorias_pcm,llano,montana,media_montana,descenso,paves,contrarreloj,prologo,esprint,
        aceleracion,fondo,resistencia,recuperacion,colinas,escapada FROM ciclistas""").fetchall()
    free_id = [t[0] for t in teams if t[4] == 'Libre'][0]
    riders = []
    free = []
    for r in rows:
        (nombre, pais, fnac, eq, tipo, nivel, pcm, wins, *attrs) = r
        try:
            y, m, d = [int(x) for x in fnac.split('-')]
        except Exception:
            y, m, d = 1998, 6, 15
        age = 2026 - y
        pot = nivel
        if age <= 27:
            pot = min(95, nivel + int(max(0.0, (pcm or 2) - 2.0) * 3.2 * (28 - age) / 8.0))
        item = dict(name=nombre, country=pais or 'ESP', y=y, m=m, d=d, team=eq, type=TYPE_ORDER.get(tipo, 0), level=nivel,
                    pot=pot, wins=wins or 0, attrs=[int(a or 50) for a in attrs])
        if eq == free_id:
            free.append(item)
        elif eq in team_index:
            riders.append(item)
    free.sort(key=lambda x: -x['level'])
    keep_free = free[:620]
    young = sorted([f for f in free[620:] if f['y'] >= 2003 and f['pot'] >= f['level'] + 4], key=lambda x: -x['pot'])[:220]
    for f in keep_free + young:
        f['team'] = -1
        riders.append(f)
    # orden: por equipo, nivel
    riders.sort(key=lambda x: (team_index.get(x['team'], 999), -x['level'], x['name']))

    # carreras y etapas
    cc = sqlite3.connect(RACE_DB)
    comps = cc.execute("SELECT id,slug,nombre FROM competiciones ORDER BY id").fetchall()
    race_rows = []
    stage_rows = []
    alt_all, lat_all, lon_all = [], [], []
    surf_all = []  # (stage_idx, km0*10, km1*10, tipo)
    for cid, slug, nombre in comps:
        if slug in SKIP_WOMEN or slug not in RACES:
            continue
        tier, squad, slots, country, start = RACES[slug]
        est = cc.execute("""SELECT id,numero,fecha,salida,meta,distancia_km,desnivel_positivo_m,tipo,puntos_con_altitud
            FROM etapas WHERE competicion_id=? ORDER BY numero""", (cid,)).fetchall()
        ridx = len(race_rows)
        first_stage = len(stage_rows)
        first_day = None
        for (eid, num, fecha, salida, meta, dist, dplus, tipo, pcount) in est:
            if fecha:
                y, m, d = [int(x) for x in fecha.split('-')]
                day = doy(m, d)
            else:
                day = doy(*start) + (num - 1)
            if first_day is None:
                first_day = day
            kind = KIND.get(tipo or '', None)
            prof = cc.execute("SELECT km,lat,lon,altitud_m FROM perfil WHERE etapa_id=? ORDER BY km", (eid,)).fetchall()
            alts = [p[3] for p in prof if p[3] is not None]
            est_prof = 0
            est_map = 0
            if dist is None:
                dist = {'gent-wevelgem': 250.0, 'milan-sanremo': 289.0}.get(slug, 180.0)
            if kind is None:
                kind = {'gent-wevelgem': 5, 'milan-sanremo': 0}.get(slug, 0)
            if not dplus:
                dplus = {'gent-wevelgem': 1700, 'milan-sanremo': 2100}.get(slug, 800)
            n = int(dist / 0.5) + 1
            if len(prof) >= 5 and len(alts) >= len(prof) * 0.9:
                # remuestrear a 0.5 km exactos
                a = []; la = []; lo = []
                j = 0
                for i in range(n):
                    km = i * 0.5
                    while j + 1 < len(prof) and prof[j + 1][0] <= km:
                        j += 1
                    p = prof[min(j, len(prof) - 1)]
                    a.append(p[3] if p[3] is not None else (a[-1] if a else 50))
                    la.append(p[1]); lo.append(p[2])
                alt = smooth_alt([int(round(x)) for x in a])
            else:
                est_prof = 1
                feats = None
                if slug == 'milan-sanremo':
                    feats = [(118, 12, 3.2), (218, 1.5, 4), (233, 1.5, 4), (252, 2.5, 3.2), (275.0, 5.6, 4.1), (285.5, 3.6, 3.7)]
                if slug == 'gent-wevelgem':
                    feats = [(120 + 12 * i, 0.9, 6) for i in range(7)] + [(190.5, 1.4, 9.5), (203.0, 1.3, 9.0), (225, 1.0, 5)]
                alt = synth_alt(eid * 17 + 3, dist, dplus, kind, feats, start_alt=40 if slug in ('milan-sanremo', 'gent-wevelgem') else 120)
                if slug == 'milan-sanremo':
                    alt = [max(0, a - 0) for a in alt]
                if len(prof) >= 5 and prof[0][1] is not None:
                    la = []; lo = []
                    j = 0
                    for i in range(n):
                        km = i * 0.5
                        while j + 1 < len(prof) and prof[j + 1][0] <= km:
                            j += 1
                        la.append(prof[min(j, len(prof) - 1)][1]); lo.append(prof[min(j, len(prof) - 1)][2])
                else:
                    est_map = 1
                    pts = synth_map(eid, dist, n)
                    la = [p[0] for p in pts]; lo = [p[1] for p in pts]
            if len(la) < n:
                est_map = 1
                pts = synth_map(eid, dist, n)
                la = [p[0] for p in pts]; lo = [p[1] for p in pts]
            alt = alt[:n]; la = la[:n]; lo = lo[:n]
            # el calculo real de D+ con la altimetria muestreada
            sidx = len(stage_rows)
            pt0 = len(alt_all)
            alt_all.extend(alt); lat_all.extend(la); lon_all.extend(lo)
            # superficies especiales
            surf0 = len(surf_all)
            if slug == 'paris-roubaix':
                rng = random.Random(77)
                k = 96.0
                cnt = 0
                while k < dist - 2 and cnt < 29:
                    L = rng.choice([1.0, 1.3, 1.5, 2.0, 2.2, 2.5, 3.0])
                    if abs(k - 163) < 4:
                        k = 163.0; L = 2.4
                    surf_all.append((sidx, int(k * 10), int((k + L) * 10), 1))
                    k += L + rng.uniform(1.8, 6.0)
                    cnt += 1
            elif slug in ('tour-of-flanders', 'e3-saxo-classic', 'dwars-door-vlaanderen', 'omloop-het-nieuwsblad', 'kuurne-brussels-kuurne', 'gent-wevelgem', 'brabantse-pijl'):
                # muros adoquinados: tramos con pendiente > 3.5% de menos de 2 km
                i = 0
                while i < n - 3:
                    if alt[min(n - 1, i + 2)] - alt[i] >= 14 and i * 0.5 > dist * 0.25:
                        j = i
                        while j + 1 < n and alt[min(n - 1, j + 1)] >= alt[j] - 1 and j - i < 4:
                            j += 1
                        surf_all.append((sidx, int(i * 5), int(j * 5), 1))
                        i = j + 6
                    else:
                        i += 1
            elif slug == 'strade-bianche':
                rng = random.Random(5)
                for ks in (12, 24, 33, 52, 70, 88, 101, 120, 143, 162, 178, 192):
                    L = rng.choice([1.5, 2.1, 2.8, 3.5, 4.4])
                    if ks + L < dist - 3:
                        surf_all.append((sidx, int(ks * 10), int((ks + L) * 10), 2))
            nsurf = len(surf_all) - surf0
            stage_rows.append((ridx, num, kind, day, fold(salida or ''), fold(meta or ''), float(dist), int(dplus), pt0, n, est_prof, est_map, surf0, nsurf))
        short = fold(nombre)
        race_rows.append((fold(slug), short, tier, squad, slots, country, len(est), first_stage, first_day))

    # ----- escribir
    L = []
    L.append('/* Generado por tools/export_data.py - NO editar a mano. */')
    L.append('#include "data.h"')
    L.append('')
    L.append('const TeamDef TEAMS[] = {')
    for cat, nombre, tid, abbr, pais in team_rows:
        c1, c2 = team_colors(nombre)
        L.append('    {%s, %s, "%s", %d, {%d,%d,%d}, {%d,%d,%d}},' % (cstr(nombre), cstr(abbr), pais[:3], cat, *c1, *c2))
    L.append('};')
    L.append('const int TEAM_COUNT = %d;' % len(team_rows))
    L.append('')
    L.append('const RiderDef RIDERS[] = {')
    for r in riders:
        ti = team_index.get(r['team'], -1) if r['team'] != -1 else -1
        L.append('    {%s, "%s", %d, %d, %d, %d, %d, %d, %d, {%s}},' % (cstr(r['name']), r['country'][:3], r['y'], r['m'], r['type'], r['level'], r['pot'], min(r['wins'], 250), ti, ','.join(str(a) for a in r['attrs'])))
    L.append('};')
    L.append('const int RIDER_COUNT = %d;' % len(riders))
    L.append('')
    L.append('const RaceDef RACES[] = {')
    for (slug, nombre, tier, squad, slots, country, ns, fs, fd) in race_rows:
        L.append('    {%s, %s, %d, %d, %d, "%s", %d, %d, %d},' % (cstr(slug), cstr(nombre), tier, squad, slots, country, ns, fs, fd))
    L.append('};')
    L.append('const int RACE_COUNT = %d;' % len(race_rows))
    L.append('')
    L.append('const StageDef STAGES[] = {')
    for (ridx, num, kind, day, salida, meta, dist, dplus, pt0, n, ep, em, s0, ns) in stage_rows:
        L.append('    {%d, %d, %d, %d, %s, %s, %.1ff, %d, %d, %d, %d, %d, %d, %d},' % (ridx, num, kind, day, cstr(salida), cstr(meta), dist, dplus, pt0, n, ep, em, s0, ns))
    L.append('};')
    L.append('const int STAGE_COUNT = %d;' % len(stage_rows))
    L.append('')
    L.append('const SurfDef SURFS[] = {')
    if not surf_all:
        L.append('    {0,0,0,0},')
    for (si, a, b, t) in surf_all:
        L.append('    {%d,%d,%d,%d},' % (si, a, b, t))
    L.append('};')
    L.append('const int SURF_COUNT = %d;' % len(surf_all))
    L.append('')
    def arr(name, typ, vals, fmt, per=24):
        L.append('const %s %s[] = {' % (typ, name))
        for i in range(0, len(vals), per):
            L.append('    ' + ','.join(fmt % v for v in vals[i:i + per]) + ',')
        L.append('};')
        L.append('const int %s_COUNT = %d;' % (name, len(vals)))
    arr('PT_ALT', 'short', alt_all, '%d')
    arr('PT_LAT', 'float', lat_all, '%.4ff', 12)
    arr('PT_LON', 'float', lon_all, '%.4ff', 12)
    OUT.write_text('\n'.join(L) + '\n', encoding='ascii')
    print('equipos', len(team_rows), 'ciclistas', len(riders), 'carreras', len(race_rows), 'etapas', len(stage_rows), 'puntos', len(alt_all), 'superficies', len(surf_all))

if __name__ == '__main__':
    main()
