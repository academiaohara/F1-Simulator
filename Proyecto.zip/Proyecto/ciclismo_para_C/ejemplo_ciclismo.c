#include <stdio.h>
#include <stdlib.h>
#include <sqlite3.h>

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Uso: %s ciclismo_para_C.sqlite\n", argv[0]);
        return 1;
    }

    sqlite3 *db = NULL;
    sqlite3_stmt *stmt = NULL;
    int rc = sqlite3_open_v2(argv[1], &db, SQLITE_OPEN_READONLY, NULL);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "Error al abrir SQLite: %s\n", db ? sqlite3_errmsg(db) : "sin conexion");
        if (db) sqlite3_close(db);
        return 1;
    }

    const char *sql =
        "SELECT nombre_completo, equipo_nombre, pais_codigo, tipo_estimado, "
        "nivel_general, montana, esprint, contrarreloj "
        "FROM ciclistas ORDER BY nivel_general DESC, nombre_completo LIMIT 15";

    rc = sqlite3_prepare_v2(db, sql, -1, &stmt, NULL);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "Error de consulta: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }

    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        const char *nombre = (const char *)sqlite3_column_text(stmt, 0);
        const char *equipo = (const char *)sqlite3_column_text(stmt, 1);
        const char *pais = (const char *)sqlite3_column_text(stmt, 2);
        const char *tipo = (const char *)sqlite3_column_text(stmt, 3);
        int nivel = sqlite3_column_int(stmt, 4);
        int montana = sqlite3_column_int(stmt, 5);
        int esprint = sqlite3_column_int(stmt, 6);
        int crono = sqlite3_column_int(stmt, 7);
        printf("%-26s | %-30s | %s | %-18s | NIV %2d | MON %2d ESP %2d CRI %2d\n",
               nombre ? nombre : "", equipo ? equipo : "", pais ? pais : "", 
               tipo ? tipo : "", nivel, montana, esprint, crono);
    }
    if (rc != SQLITE_DONE) {
        fprintf(stderr, "Error al leer resultados: %s\n", sqlite3_errmsg(db));
    }
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return rc == SQLITE_DONE ? 0 : 1;
}
