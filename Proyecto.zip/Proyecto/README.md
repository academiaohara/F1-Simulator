# Ciclismo Manager

Juego de gestión de equipos ciclistas profesionales, escrito en C, con interfaz **pixel art** (resolución interna 640×360 escalada a la ventana). Es un único `.exe` portable: **no necesita instalador ni permisos de administrador**. Copia `ciclismo_manager.exe` a cualquier carpeta (escritorio, USB…) y ábrelo. La partida se guarda como `partida.sav` junto al ejecutable.

## Qué incluye

**Gestión (estilo Football Manager)**
- 212 equipos reales (WorldTour, ProTeam, Continental, Sub-23) y ~3.800 ciclistas con 14 atributos cada uno.
- **Reputación** de ciclistas y de equipos: un ciclista famoso puede rechazar fichar por un equipo pequeño; la reputación sube con victorias y podios.
- **Contratos**: negociación de salario, años, rol prometido, traspaso al club de origen y promesas (p. ej. plaza en Gran Vuelta; si no se cumple, la moral cae). Renovaciones, liberar corredores con indemnización, tope salarial de la directiva.
- **Ojeo**: los atributos de ciclistas ajenos son estimaciones; ojeadores y ojeos pagados mejoran la precisión.
- **Personal técnico**: entrenador, médico, nutricionista, mecánicos, ojeador y director deportivo (mejoran forma, recuperación, avituallamiento, caídas/pinchazos…).
- **Finanzas**: patrocinio, nóminas, personal, costes de viaje por corredor y día, premios por carrera.
- **Directiva**: objetivos de temporada (ranking y victorias) que suben o bajan tu patrocinio.
- Entrenamiento semanal por corredor, forma y fatiga, lesiones, progresión y retirada por edad, nuevos profesionales cada año.

**Calendario con requisitos reales (referencia: el progreso de Virtua Tennis / World Tour)**
- 25 carreras de 2026 (Tour, Giro, Vuelta, semanas ProSeries/WorldTour y clásicas) con **135 etapas** y perfiles de altimetría/mapa reales (GPX).
- Los equipos WorldTour están **obligados** a correr las carreras WT; los ProTeam y Continental necesitan **invitación**: hay plazas limitadas, un puesto estimado (reputación + ser equipo local + solicitud) y fecha de anuncio.
- Tamaño de equipo por carrera (8 en Grandes Vueltas, 7 en el resto), selección y roles por carrera, carreras simultáneas con plantillas disjuntas.

**Carrera en vivo (la parte jugable)**
- Escena lateral pixel art con el grupo que sigues, ciclistas con el color del equipo, relieve de la carretera, lluvia, meta…
- Ventanas: **perfil de altura** coloreado por pendiente con los grupos marcados, **mapa** con el trazado y los grupos, lista de **grupos y diferencias de tiempo**, radio carrera, orden de carrera y tu equipo (energía, reserva anaeróbica, estado, ritmo).
- Órdenes por corredor: **Atacar, Escapada, Tirar, Proteger, Bidones (avituallamiento), Ahorrar, Auto**, con intensidad suave/media/máxima, y **táctica de equipo** (controlar, esprint, general, cazar etapa, conservar).
- **Roles** que cambian el comportamiento: Líder, Esprínter, Lanzador, Gregario, Rodador, Escapadista.
- Motor físico: potencia (W/kg) según atributos y terreno, rebufo, pendiente, descensos, pavés/sterrato, fatiga y pájaras, reserva anaeróbica, caídas, pinchazos (un protector cede la rueda), escapadas, persecuciones de los equipos de esprint, tirones de gregarios en puerto, ataques de líderes, tren de lanzamiento y **sprint final con temporización** (pulsa ESPACIO en la zona verde), contrarrelojes individuales y por equipos, clasificaciones general/puntos/montaña, bonificaciones, fuera de control.

## Controles

| Acción | Tecla / ratón |
|---|---|
| Moverse por menús | Ratón (clic, rueda) |
| Avanzar día | `Espacio` o botón |
| Pantalla completa | `F11` |
| Carrera: elegir corredor | `↑` `↓` o clic en la tabla |
| Carrera: órdenes | `A` atacar · `E` escapada · `T` tirar · `P` proteger · `B` bidones · `R` ahorrar · `X` auto |
| Carrera: intensidad | `1` suave · `2` media · `3` máxima |
| Carrera: táctica de equipo | `Z` |
| Carrera: velocidad | `←` `→` (la pausa es el primer botón) · `Espacio` pausa / lanzar esprint |
| Clic en un grupo | Cambia la cámara a ese grupo |

El juego baja la velocidad solo cuando hay incidentes y en los últimos 5 km.

## Datos y limitaciones (honestidad sobre las fuentes)

- Ciclistas, atributos y equipos proceden de la base **2024** suministrada (no es una plantilla 2026). `tipo` y `nivel` son estimaciones de esa base.
- Las rutas son las de la base 2026 con GPX (muestreadas cada 500 m y suavizadas). **6 etapas no tienen GPX** y llevan un perfil sintético marcado como *(perfil estimado)*: Tour etapas 3–5, UAE etapa 7, Gent-Wevelgem y Milán-San Remo; el mapa de algunas es *trazado estimado*.
- Fechas: las de las Grandes Vueltas vienen de la base; las demás son aproximadas del calendario 2026. El calendario se repite cada temporada.
- Los puertos no tienen nombre en la base: se detectan automáticamente y se clasifican por dificultad (HC, C1…C4). Los sectores de pavé/sterrato de Roubaix y Strade Bianche son aproximados.
- Las 4 carreras femeninas de la base no se incluyen (la base de ciclistas es masculina).
- Salarios, patrocinios, premios y reputaciones son valores del juego calibrados, no datos reales.

## Compilar

Requiere Visual Studio Build Tools (MSVC) y Python 3 solo para regenerar los datos.

```powershell
python tools\export_data.py      # (opcional) regenera src\data_gen.c desde los SQLite
.\build_windows.ps1              # compila ciclismo_manager.exe
.\package_windows.ps1            # crea release\ciclismo_manager\
```

Herramientas de desarrollo: `build_tests.ps1` compila `tests\headless.c` (simula una temporada completa) y `tests\stagetest.c` (estadísticas de una etapa). `ciclismo_manager.exe --shot salida.png escenario [frames]` genera capturas sin abrir ventana (escenarios: `menu`, `teamsel`, `hub0`..`hub6`, `neg`, `squadm`, `prep`, `race`, `result`).

## Estructura

- `src/gfx.c` — framebuffer, fuente 5×7 con acentos, formas, PNG.
- `src/sim.c` — motor de carrera. `src/game.c` — gestión del mundo. `src/ui.c`, `src/uirace.c` — pantallas. `src/main.c` — ventana Win32 (GDI, sin dependencias).
- `src/data_gen.c` — datos incrustados generados por `tools/export_data.py`.
