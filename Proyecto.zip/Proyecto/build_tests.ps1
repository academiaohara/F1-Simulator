$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$vs = 'C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvarsall.bat'
$flags = '/nologo /O2 /std:c11 /utf-8 /W3 /D_CRT_SECURE_NO_WARNINGS /Fobuild\'
$core = 'src\game.c src\sim.c src\gfx.c src\data_gen.c'
cmd.exe /c "call `"$vs`" x64 >nul && cd /d $root && cl $flags tests\headless.c $core /Fe:build\headless.exe && cl $flags tests\stagetest.c $core /Fe:build\stagetest.exe"
cmd.exe /c "call `"$vs`" x64 >nul && cd /d $root && cl $flags tests\dbg.c $core /Fe:build\dbg.exe"
cmd.exe /c "call `"$vs`" x64 >nul && cd /d $root && cl $flags tests\dbg2.c $core /Fe:build\dbg2.exe"
cmd.exe /c "call `"$vs`" x64 >nul && cd /d $root && cl $flags tests\savetest.c src\game.c src\sim.c src\gfx.c src\save.c src\data_gen.c /Fe:build\savetest.exe"
